# WordPress MySQL database migration
#
# Generated: Wednesday 20. August 2014 18:57 UTC
# Hostname: localhost
# Database: `wp_bronsonrock`
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Mr WordPress', '', 'http://wordpress.org/', '', '2014-02-24 13:54:52', '2014-02-24 13:54:52', 'Hi, this is a comment.\nTo delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, '1', '', '', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=1409 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://nick.bronsonrocktx.com', 'yes'),
(2, 'blogname', 'Bronson Rock', 'yes'),
(3, 'blogdescription', 'Wood-Fired Grill &amp; Bar', 'yes'),
(4, 'users_can_register', '0', 'yes'),
(5, 'admin_email', 'ty@paradoxsites.com', 'yes'),
(6, 'start_of_week', '1', 'yes'),
(7, 'use_balanceTags', '0', 'yes'),
(8, 'use_smilies', '1', 'yes'),
(9, 'require_name_email', '1', 'yes'),
(10, 'comments_notify', '1', 'yes'),
(11, 'posts_per_rss', '10', 'yes'),
(12, 'rss_use_excerpt', '0', 'yes'),
(13, 'mailserver_url', 'mail.example.com', 'yes'),
(14, 'mailserver_login', 'login@example.com', 'yes'),
(15, 'mailserver_pass', 'password', 'yes'),
(16, 'mailserver_port', '110', 'yes'),
(17, 'default_category', '1', 'yes'),
(18, 'default_comment_status', 'open', 'yes'),
(19, 'default_ping_status', 'open', 'yes'),
(20, 'default_pingback_flag', '1', 'yes'),
(21, 'posts_per_page', '10', 'yes'),
(22, 'date_format', 'F j, Y', 'yes'),
(23, 'time_format', 'g:i a', 'yes'),
(24, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(28, 'comment_moderation', '0', 'yes'),
(29, 'moderation_notify', '1', 'yes'),
(30, 'permalink_structure', '/%postname%/', 'yes'),
(31, 'gzipcompression', '0', 'yes'),
(32, 'hack_file', '0', 'yes'),
(33, 'blog_charset', 'UTF-8', 'yes'),
(34, 'moderation_keys', '', 'no'),
(35, 'active_plugins', 'a:8:{i:0;s:29:"gravityforms/gravityforms.php";i:1;s:30:"advanced-custom-fields/acf.php";i:2;s:39:"bulk-page-creator/bulk-page-creator.php";i:3;s:43:"custom-post-type-ui/custom-post-type-ui.php";i:4;s:56:"gravity-forms-placeholders/gravityforms-placeholders.php";i:5;s:29:"image-widget/image-widget.php";i:6;s:39:"wp-migrate-db-pro/wp-migrate-db-pro.php";i:7;s:27:"wp-pagenavi/wp-pagenavi.php";}', 'yes'),
(36, 'home', 'http://nick.bronsonrocktx.com', 'yes'),
(37, 'category_base', '', 'yes'),
(38, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(39, 'advanced_edit', '0', 'yes'),
(40, 'comment_max_links', '2', 'yes'),
(41, 'gmt_offset', '-6', 'yes'),
(42, 'default_email_category', '1', 'yes'),
(43, 'recently_edited', '', 'no'),
(44, 'template', 'Paradox', 'yes'),
(45, 'stylesheet', 'Paradox', 'yes'),
(46, 'comment_whitelist', '1', 'yes'),
(47, 'blacklist_keys', '', 'no'),
(48, 'comment_registration', '0', 'yes'),
(49, 'html_type', 'text/html', 'yes'),
(50, 'use_trackback', '0', 'yes'),
(51, 'default_role', 'subscriber', 'yes'),
(52, 'db_version', '27916', 'yes'),
(53, 'uploads_use_yearmonth_folders', '1', 'yes'),
(54, 'upload_path', '', 'yes'),
(55, 'blog_public', '0', 'yes'),
(56, 'default_link_category', '2', 'yes'),
(57, 'show_on_front', 'page', 'yes'),
(58, 'tag_base', '', 'yes'),
(59, 'show_avatars', '1', 'yes'),
(60, 'avatar_rating', 'G', 'yes'),
(61, 'upload_url_path', '', 'yes'),
(62, 'thumbnail_size_w', '100', 'yes'),
(63, 'thumbnail_size_h', '100', 'yes'),
(64, 'thumbnail_crop', '1', 'yes'),
(65, 'medium_size_w', '300', 'yes'),
(66, 'medium_size_h', '300', 'yes'),
(67, 'avatar_default', 'mystery', 'yes'),
(68, 'large_size_w', '1024', 'yes'),
(69, 'large_size_h', '1024', 'yes'),
(70, 'image_default_link_type', '', 'yes'),
(71, 'image_default_size', '', 'yes'),
(72, 'image_default_align', '', 'yes'),
(73, 'close_comments_for_old_posts', '0', 'yes'),
(74, 'close_comments_days_old', '14', 'yes'),
(75, 'thread_comments', '1', 'yes'),
(76, 'thread_comments_depth', '5', 'yes'),
(77, 'page_comments', '0', 'yes'),
(78, 'comments_per_page', '50', 'yes'),
(79, 'default_comments_page', 'newest', 'yes'),
(80, 'comment_order', 'asc', 'yes'),
(81, 'sticky_posts', 'a:0:{}', 'yes'),
(82, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(83, 'widget_text', 'a:2:{i:2;a:3:{s:5:"title";s:13:"Shelly Morgan";s:4:"text";s:159:"Professional Real Estate Inspector #6196,\r\nCertified Pest Control Applicator #0561139,\r\nFEMA Certified Disaster Housing Inspector #15007\r\nCommercial Specialist";s:6:"filter";b:1;}s:12:"_multiwidget";i:1;}', 'yes'),
(84, 'widget_rss', 'a:0:{}', 'yes'),
(85, 'uninstall_plugins', 'a:1:{s:27:"wp-pagenavi/wp-pagenavi.php";s:14:"__return_false";}', 'no'),
(86, 'timezone_string', '', 'yes'),
(87, 'page_for_posts', '0', 'yes'),
(88, 'page_on_front', '4', 'yes'),
(89, 'default_post_format', '0', 'yes'),
(90, 'link_manager_enabled', '0', 'yes'),
(91, 'initial_db_version', '26691', 'yes'),
(92, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(93, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(94, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'sidebars_widgets', 'a:10:{s:18:"orphaned_widgets_1";a:7:{i:0;s:10:"nav_menu-3";i:1;s:8:"search-2";i:2;s:14:"recent-posts-2";i:3;s:17:"recent-comments-2";i:4;s:10:"archives-2";i:5;s:12:"categories-2";i:6;s:6:"meta-2";}s:18:"orphaned_widgets_2";a:1:{i:0;s:6:"text-2";}s:19:"wp_inactive_widgets";a:1:{i:0;s:7:"pages-2";}s:12:"header-right";a:0:{}s:12:"navbar-right";a:0:{}s:15:"sidebar-default";a:0:{}s:11:"footer-left";a:1:{i:0;s:10:"nav_menu-2";}s:12:"footer-right";a:1:{i:0;s:10:"nav_menu-4";}s:14:"footer-credits";a:1:{i:0;s:10:"nav_menu-5";}s:13:"array_version";i:3;}', 'yes'),
(99, 'cron', 'a:5:{i:1408585140;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1408586116;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1408629333;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1408646510;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(102, 'auth_key', 'Nsc~V?bZ2Q}]a9xfQHq%|hfMaAC%d#Zl@WT$5~}+wCE;51tqkm/`w/L=lLoW.R,j', 'yes'),
(103, 'auth_salt', 'fr>aKtWD%$:;{Y+dD[nFPXt6;!YN,P,WwhFCI1@#`CSKoz[@Fs4:g__XGRkNrR/T', 'yes'),
(104, 'logged_in_key', '%mU7mOix)6;}Ld:v4;V9D&P ~kRu$H!L- (~J=`LD8}4mXklbyWH--Xt%U<VZvAn', 'yes'),
(105, 'logged_in_salt', 'xJe6(#bgAF4jO/cmj^nAF))@|x6Gl>a%gB{(*q1`KthTv%gw)@jpUYE5|lt&bD=-', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(106, 'nonce_key', '}wj`xlT#G>hxES4X/@<N?g+swQmb`Y(P(.):E+`^2OoyWUS6O)t K5[beJ/oVXU-', 'yes'),
(107, 'nonce_salt', '0[={FxqRYDzcTS=rW`>Hh2O^-W+9nwAwD~E~?WxaUtN,MMf(OKOdL^z2+GYTcd[<', 'yes'),
(135, 'current_theme', 'Paradox', 'yes'),
(136, 'theme_mods_xstream', 'a:107:{i:0;b:0;s:9:"custom_bg";s:54:"[site_url]/wp-content/themes/xstream/images/bg/bg0.png";s:7:"backups";N;s:9:"smof_init";s:31:"Mon, 24 Feb 2014 18:52:28 +0000";s:17:"custom_login_logo";s:0:"";s:24:"custom_login_logo_height";s:4:"67px";s:14:"custom_favicon";s:0:"";s:26:"enable_disable_breadcrumbs";s:1:"1";s:20:"disable_fixed_navbar";s:1:"2";s:22:"disable_inverse_navbar";s:1:"2";s:11:"custom_logo";s:0:"";s:10:"subheading";s:40:"<h3 style="margin: 0;">Blog Archive</h3>";s:21:"enable_disable_search";s:1:"1";s:14:"disable_social";s:1:"2";s:10:"bootswatch";s:17:"bootstrap.min.css";s:15:"main_text_color";s:7:"#333333";s:15:"main_link_color";s:7:"#428bca";s:21:"main_link_hover_color";s:7:"#2a6496";s:12:"navbar_color";s:7:"#eeeeee";s:18:"navbar_brand_color";s:7:"#777777";s:24:"navbar_brand_color_hover";s:7:"#5e5e5e";s:17:"navbar_menu_links";s:7:"#777777";s:23:"navbar_menu_links_hover";s:7:"#333333";s:19:"navbar_menu_link_bg";s:7:"#d5d5d5";s:14:"navbar_dd_link";s:7:"#333333";s:20:"navbar_dd_hover_link";s:7:"#FFFFFF";s:20:"navbar_bg_hover_link";s:7:"#357ebd";s:12:"jumbotron_bg";s:7:"#eeeeee";s:20:"jumbotron_text_color";s:7:"#333333";s:22:"jumbotron_button_color";s:7:"#474949";s:28:"jumbotron_button_hover_color";s:7:"#3a3c3c";s:19:"home_widget_heading";s:7:"#333333";s:16:"home_widget_text";s:7:"#333333";s:22:"read_more_button_color";s:7:"#474949";s:28:"read_more_button_hover_color";s:7:"#3a3c3c";s:13:"breadcrumb_bg";s:7:"#f5f5f5";s:15:"breadcrumb_link";s:7:"#428bca";s:17:"breadcrumb_active";s:7:"#999999";s:14:"breadcrumb_sep";s:7:"#cccccc";s:10:"sidebar_bg";s:7:"#f5f5f5";s:14:"sidebar_border";s:7:"#e3e3e3";s:15:"sidebar_heading";s:7:"#333333";s:12:"sidebar_text";s:7:"#333333";s:12:"sidebar_link";s:7:"#428bca";s:18:"sidebar_link_hover";s:7:"#2a6496";s:11:"social_link";s:7:"#428bca";s:17:"social_link_hover";s:7:"#2a6496";s:19:"filter_button_color";s:7:"#474949";s:25:"filter_button_hover_color";s:7:"#3a3c3c";s:22:"portfolio_button_color";s:7:"#474949";s:28:"portfolio_button_hover_color";s:7:"#3a3c3c";s:10:"body_gfont";s:7:"default";s:14:"headings_gfont";s:7:"default";s:12:"navbar_brand";s:7:"default";s:15:"brand_font_size";s:4:"13px";s:16:"brand_font_style";s:6:"normal";s:16:"navigation_gfont";s:7:"default";s:20:"navigation_font_size";s:4:"13px";s:21:"navigation_font_style";s:6:"normal";s:10:"hero_radio";s:8:"featured";s:16:"featured_heading";s:11:"Responsive!";s:16:"home_subheadline";s:25:"Bootstrap WordPress Theme";s:17:"home_content_area";s:172:"A responsive WordPress theme with all the Twitter Bootstrap goodies. Check out the page layouts, features, and shortcodes this theme has to offer. Feel free to look around.";s:14:"display_button";s:1:"1";s:8:"cta_text";s:14:"Call to Action";s:7:"cta_url";s:7:"http://";s:12:"button_block";s:1:"1";s:8:"cta_size";s:7:"Default";s:16:"featured_content";s:113:"<img class="aligncenter" src="/wp-content/themes/strappress/images/featured-image.png" width="440" height="300"/>";s:19:"enable_disable_meta";s:1:"1";s:14:"read_more_text";s:9:"Read More";s:15:"read_more_block";s:1:"1";s:14:"read_more_size";s:7:"Default";s:26:"enable_disable_meta_single";s:1:"1";s:19:"enable_disable_tags";s:1:"1";s:27:"enable_disable_archive_tags";s:1:"1";s:16:"portfolio_column";s:5:"three";s:11:"filter_btns";s:1:"1";s:10:"f_btn_size";s:7:"Default";s:12:"project_btns";s:1:"1";s:10:"p_btn_size";s:7:"Default";s:14:"p_button_block";s:1:"1";s:13:"p_button_text";s:12:"View Project";s:13:"project_title";s:1:"1";s:12:"social_style";s:3:"one";s:7:"twitter";s:1:"#";s:6:"tumblr";s:1:"#";s:6:"github";s:1:"#";s:9:"instagram";s:1:"#";s:9:"pinterest";s:1:"#";s:8:"dribbble";s:1:"#";s:6:"flickr";s:1:"#";s:11:"google-plus";s:1:"#";s:8:"facebook";s:1:"#";s:8:"linkedin";s:1:"#";s:7:"youtube";s:1:"#";s:3:"rss";s:1:"#";s:21:"disable_social_footer";s:1:"1";s:16:"custom_copyright";s:0:"";s:12:"custom_power";s:0:"";s:15:"tracking_header";s:0:"";s:15:"tracking_footer";s:0:"";s:14:"custom_css_box";s:0:"";s:9:"of_backup";s:0:"";s:11:"of_transfer";s:0:"";s:18:"nav_menu_locations";a:1:{s:7:"top-bar";i:2;}s:16:"sidebars_widgets";a:2:{s:4:"time";i:1393269722;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:1:{i:0;s:7:"pages-2";}s:18:"orphaned_widgets_1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(137, 'theme_switched', '', 'yes'),
(138, 'recently_activated', 'a:0:{}', 'yes'),
(142, 'theme_mods__s', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1393254409;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(147, 'theme_mods_thematic', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1393255958;s:4:"data";a:14:{s:19:"wp_inactive_widgets";a:2:{i:0;s:7:"pages-2";i:1;s:11:"rss-links-2";}s:13:"primary-aside";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:15:"secondary-aside";a:0:{}s:20:"1st-subsidiary-aside";a:0:{}s:20:"2nd-subsidiary-aside";N;s:20:"3rd-subsidiary-aside";N;s:9:"index-top";N;s:12:"index-insert";N;s:12:"index-bottom";N;s:10:"single-top";N;s:13:"single-insert";N;s:13:"single-bottom";N;s:8:"page-top";N;s:11:"page-bottom";N;}}}', 'yes'),
(149, 'widget_pages', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(150, 'widget_links', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(151, 'widget_rss-links', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(152, 'thematic_theme_opt', 'a:4:{s:12:"index_insert";i:2;s:11:"author_info";i:0;s:10:"footer_txt";s:48:"Powered by [wp-link]. Built on the [theme-link].";s:14:"del_legacy_opt";i:0;}', 'yes'),
(155, 'optionsframework', 'a:2:{s:2:"id";s:24:"optionsframework_xstream";s:12:"knownoptions";a:1:{i:0;s:24:"optionsframework_xstream";}}', 'yes'),
(156, 'optionsframework_xstream', 'a:25:{s:18:"heading_typography";a:4:{s:4:"size";a:63:{i:0;i:9;i:1;i:10;i:2;i:11;i:3;i:12;i:4;i:13;i:5;i:14;i:6;i:15;i:7;i:16;i:8;i:17;i:9;i:18;i:10;i:19;i:11;i:20;i:12;i:21;i:13;i:22;i:14;i:23;i:15;i:24;i:16;i:25;i:17;i:26;i:18;i:27;i:19;i:28;i:20;i:29;i:21;i:30;i:22;i:31;i:23;i:32;i:24;i:33;i:25;i:34;i:26;i:35;i:27;i:36;i:28;i:37;i:29;i:38;i:30;i:39;i:31;i:40;i:32;i:41;i:33;i:42;i:34;i:43;i:35;i:44;i:36;i:45;i:37;i:46;i:38;i:47;i:39;i:48;i:40;i:49;i:41;i:50;i:42;i:51;i:43;i:52;i:44;i:53;i:45;i:54;i:46;i:55;i:47;i:56;i:48;i:57;i:49;i:58;i:50;i:59;i:51;i:60;i:52;i:61;i:53;i:62;i:54;i:63;i:55;i:64;i:56;i:65;i:57;i:66;i:58;i:67;i:59;i:68;i:60;i:69;i:61;i:70;i:62;i:71;}s:4:"face";s:5:"Arial";s:5:"style";s:6:"Normal";s:5:"color";s:0:"";}s:20:"main_body_typography";a:4:{s:4:"size";a:63:{i:0;i:9;i:1;i:10;i:2;i:11;i:3;i:12;i:4;i:13;i:5;i:14;i:6;i:15;i:7;i:16;i:8;i:17;i:9;i:18;i:10;i:19;i:11;i:20;i:12;i:21;i:13;i:22;i:14;i:23;i:15;i:24;i:16;i:25;i:17;i:26;i:18;i:27;i:19;i:28;i:20;i:29;i:21;i:30;i:22;i:31;i:23;i:32;i:24;i:33;i:25;i:34;i:26;i:35;i:27;i:36;i:28;i:37;i:29;i:38;i:30;i:39;i:31;i:40;i:32;i:41;i:33;i:42;i:34;i:43;i:35;i:44;i:36;i:45;i:37;i:46;i:38;i:47;i:39;i:48;i:40;i:49;i:41;i:50;i:42;i:51;i:43;i:52;i:44;i:53;i:45;i:54;i:46;i:55;i:47;i:56;i:48;i:57;i:49;i:58;i:50;i:59;i:51;i:60;i:52;i:61;i:53;i:62;i:54;i:63;i:55;i:64;i:56;i:65;i:57;i:66;i:58;i:67;i:59;i:68;i:60;i:69;i:61;i:70;i:62;i:71;}s:4:"face";s:5:"Arial";s:5:"style";s:6:"Normal";s:5:"color";s:0:"";}s:10:"link_color";s:0:"";s:16:"link_hover_color";s:0:"";s:17:"link_active_color";s:0:"";s:12:"nav_position";s:0:"";s:16:"top_nav_bg_color";s:0:"";s:19:"showhidden_gradient";b:0;s:29:"top_nav_bottom_gradient_color";s:0:"";s:18:"top_nav_link_color";s:0:"";s:24:"top_nav_link_hover_color";s:0:"";s:21:"top_nav_dropdown_item";s:0:"";s:25:"top_nav_dropdown_hover_bg";s:0:"";s:10:"search_bar";b:0;s:13:"branding_logo";s:0:"";s:9:"site_name";s:1:"1";s:17:"showhidden_themes";b:0;s:10:"wpbs_theme";s:7:"default";s:24:"showhidden_slideroptions";b:0;s:14:"slider_options";s:1:"5";s:18:"hero_unit_bg_color";s:0:"";s:25:"suppress_comments_message";s:1:"1";s:9:"blog_hero";s:1:"1";s:11:"favicon_url";s:0:"";s:8:"wpbs_css";s:0:"";}', 'yes'),
(169, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(171, 'theme_mods_paradox', 'a:13:{i:0;b:0;s:9:"custom_bg";s:54:"[site_url]/wp-content/themes/paradox/images/bg/bg0.png";s:7:"backups";N;s:9:"smof_init";s:31:"Mon, 24 Feb 2014 19:22:06 +0000";s:17:"custom_login_logo";s:0:"";s:24:"custom_login_logo_height";s:4:"67px";s:14:"custom_favicon";s:0:"";s:26:"enable_disable_breadcrumbs";s:1:"1";s:20:"disable_fixed_navbar";s:1:"2";s:22:"disable_inverse_navbar";s:1:"2";s:11:"custom_logo";s:0:"";s:10:"subheading";s:40:"<h3 style="margin: 0;">Blog Archive</h3>";s:18:"nav_menu_locations";a:1:{s:7:"primary";i:2;}}', 'yes'),
(176, 'theme_mods_twentyfourteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1393270077;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:1:{i:0;s:7:"pages-2";}s:18:"orphaned_widgets_1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:18:"orphaned_widgets_2";a:0:{}s:18:"orphaned_widgets_3";a:0:{}}}}', 'yes'),
(177, 'category_children', 'a:0:{}', 'yes'),
(225, '_image_widget_version', '4.1', 'yes'),
(226, 'widget_widget_sp_image', 'a:3:{i:2;a:12:{s:5:"title";s:0:"";s:11:"description";s:0:"";s:4:"link";s:0:"";s:10:"linktarget";s:5:"_self";s:5:"width";i:564;s:6:"height";i:589;s:4:"size";s:5:"large";s:5:"align";s:4:"none";s:3:"alt";s:104:"Shelly Morgan Xstream Inspections Home and Residential Real Estate Inspections 972-492-7920 214-390-2050";s:8:"imageurl";s:92:"http://nick.bronsonrocktx.com/wp-content/uploads/2014/02/MORGAN-089-large-72dpi-file.jpg";s:12:"aspect_ratio";d:0.95755517826825132;s:13:"attachment_id";i:76;}i:3;a:12:{s:5:"title";s:0:"";s:11:"description";s:0:"";s:4:"link";s:0:"";s:10:"linktarget";s:5:"_self";s:5:"width";i:564;s:6:"height";i:589;s:4:"size";s:4:"full";s:5:"align";s:4:"none";s:3:"alt";s:104:"Shelly Morgan Xstream Inspections Home and Residential Real Estate Inspections 972-492-7920 214-390-2050";s:8:"imageurl";s:92:"http://nick.bronsonrocktx.com/wp-content/uploads/2014/02/MORGAN-089-large-72dpi-file.jpg";s:12:"aspect_ratio";d:0.95755517826825132;s:13:"attachment_id";i:76;}s:12:"_multiwidget";i:1;}', 'yes'),
(227, 'widget_bootstrapbasic_search_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(228, 'widget_nav_menu', 'a:5:{i:2;a:2:{s:5:"title";s:0:"";s:8:"nav_menu";i:5;}i:3;a:2:{s:5:"title";s:0:"";s:8:"nav_menu";i:4;}i:4;a:2:{s:5:"title";s:0:"";s:8:"nav_menu";i:6;}i:5;a:2:{s:5:"title";s:0:"";s:8:"nav_menu";i:7;}s:12:"_multiwidget";i:1;}', 'yes'),
(229, 'gravityformsaddon_gravityformswebapi_version', '1.0', 'yes'),
(230, 'rg_form_version', '1.8.9', 'yes'),
(235, 'rg_gforms_key', '099c03f26e64e93459a2cf51dc992f60', 'yes'),
(236, 'rg_gforms_disable_css', '1', 'yes'),
(237, 'rg_gforms_enable_html5', '1', 'yes'),
(238, 'gform_enable_noconflict', '0', 'yes'),
(239, 'rg_gforms_enable_akismet', '', 'yes'),
(240, 'rg_gforms_captcha_public_key', 'Ty Richards', 'yes'),
(241, 'rg_gforms_captcha_private_key', 'Ty Richards', 'yes'),
(242, 'rg_gforms_currency', 'USD', 'yes'),
(243, 'rg_gforms_message', '<!--GFM-->', 'yes'),
(469, 'widget_gform_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(575, 'db_upgraded', '', 'yes'),
(578, 'dashboard_widget_options', 'a:4:{s:25:"dashboard_recent_comments";a:1:{s:5:"items";i:5;}s:24:"dashboard_incoming_links";a:5:{s:4:"home";s:33:"http://nick.bronsonrocktx.com";s:4:"link";s:109:"http://blogsearch.google.com/blogsearch?scoring=d&partner=wordpress&q=link:http://nick.bronsonrocktx.com/";s:3:"url";s:142:"http://blogsearch.google.com/blogsearch_feeds?scoring=d&ie=utf-8&num=10&output=rss&partner=wordpress&q=link:http://nick.bronsonrocktx.com/";s:5:"items";i:10;s:9:"show_date";b:0;}s:17:"dashboard_primary";a:7:{s:4:"link";s:26:"http://wordpress.org/news/";s:3:"url";s:31:"http://wordpress.org/news/feed/";s:5:"title";s:14:"WordPress Blog";s:5:"items";i:2;s:12:"show_summary";i:1;s:11:"show_author";i:0;s:9:"show_date";i:1;}s:19:"dashboard_secondary";a:7:{s:4:"link";s:28:"http://planet.wordpress.org/";s:3:"url";s:33:"http://planet.wordpress.org/feed/";s:5:"title";s:20:"Other WordPress News";s:5:"items";i:5;s:12:"show_summary";i:0;s:11:"show_author";i:0;s:9:"show_date";i:0;}}', 'yes'),
(811, 'gform_email_count', '1', 'yes'),
(1051, 'auto_core_update_notified', 'a:4:{s:4:"type";s:6:"manual";s:5:"email";s:19:"ty@paradoxsites.com";s:7:"version";s:5:"3.8.2";s:9:"timestamp";i:1399409601;}', 'yes'),
(1067, 'wpmdb_error_log', '********************************************\n******  Log date: 2014/03/20 17:48:17 ******\n********************************************\n\nWPMDB Error: Unable to connect to the remote server, please check the connection details - 404 Not Found (#129 - scope: ajax_verify_connection_to_remote_site)\n\nAttempted to connect to: http://nick.bronsonrocktx.com/wp-admin/admin-ajax.php\n\nArray\n(\n    [headers] => Array\n        (\n            [date] => Thu, 20 Mar 2014 17:48:17 GMT\n            [server] => Apache\n            [x-host] => app-64-8.intern.weebly.net\n            [x-ua-compatible] => IE=edge,chrome=1\n            [content-length] => 1513\n            [connection] => close\n            [content-type] => text/html; charset=UTF-8\n        )\n\n    [body] => <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">\n<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">\n<head>\n	<title>404 - Page Not Found</title>\n	<meta http-equiv="content-type" content="text/html; charset=UTF-8" />\n	<meta name="robots" content="noarchive" />\n	<link rel="shortcut icon" href="http://cdn1.editmysite.com/developer/none.ico" />\n\n	<style type="text/css">\n	body {\n		background: url(http://cdn1.editmysite.com/images/404background.jpg);\n		font-family: Helvetica, arial, sans-serif;\n		color: #ccc;\n	}\n	.alert-container {\n		background: url(http://cdn1.editmysite.com/images/404_textbox.png);\n		width: 918px;\n		height: 142px;\n		margin: 82px auto 0px;\n	}\n	.alert-inner {\n		padding: 24px 0px 0px 209px;\n	}\n	.alert-heading {\n		font-size: 50px;\n		font-weight: bold;\n		line-height: 50px;\n	}\n	.alert-subheading {\n		margin-top: 8px;\n		font-size: 28px;\n		line-height: 28px;\n	}\n	.redirect {\n		width: 918px;\n		margin: 24px auto 0px;\n		font-size: 14px;\n		line-height: 14px;\n		text-align: center;\n	}\n	.redirect a {\n		color: #ffb300;\n		text-decoration: none;\n	}\n	</style>\n</head>\n<body>\n	<div class="alert-container">\n		<div class="alert-inner">\n			<div class="alert-heading">404 - Page Not Found</div>\n			<div class="alert-subheading">Sorry, the page you are looking for does not exist</div>\n		</div>\n	</div>\n	<div class="redirect">Please check the URL.  Otherwise, <a href=\'/\'>click here</a> to be redirected to the homepage.</div>\n</body>\n</html>\n\n    [response] => Array\n        (\n            [code] => 404\n            [message] => Not Found\n        )\n\n    [cookies] => Array\n        (\n        )\n\n    [filename] => \n)\n\n\n********************************************\n******  Log date: 2014/03/21 15:48:14 ******\n********************************************\n\nWPMDB Error: Unable to connect to the remote server, please check the connection details - 404 Not Found (#129 - scope: ajax_verify_connection_to_remote_site)\n\nAttempted to connect to: http://nick.bronsonrocktx.com/wp-admin/admin-ajax.php\n\nArray\n(\n    [headers] => Array\n        (\n            [date] => Fri, 21 Mar 2014 15:48:13 GMT\n            [server] => Apache\n            [x-host] => app-64-12.intern.weebly.net\n            [x-ua-compatible] => IE=edge,chrome=1\n            [content-length] => 1513\n            [connection] => close\n            [content-type] => text/html; charset=UTF-8\n        )\n\n    [body] => <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">\n<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">\n<head>\n	<title>404 - Page Not Found</title>\n	<meta http-equiv="content-type" content="text/html; charset=UTF-8" />\n	<meta name="robots" content="noarchive" />\n	<link rel="shortcut icon" href="http://cdn1.editmysite.com/developer/none.ico" />\n\n	<style type="text/css">\n	body {\n		background: url(http://cdn1.editmysite.com/images/404background.jpg);\n		font-family: Helvetica, arial, sans-serif;\n		color: #ccc;\n	}\n	.alert-container {\n		background: url(http://cdn1.editmysite.com/images/404_textbox.png);\n		width: 918px;\n		height: 142px;\n		margin: 82px auto 0px;\n	}\n	.alert-inner {\n		padding: 24px 0px 0px 209px;\n	}\n	.alert-heading {\n		font-size: 50px;\n		font-weight: bold;\n		line-height: 50px;\n	}\n	.alert-subheading {\n		margin-top: 8px;\n		font-size: 28px;\n		line-height: 28px;\n	}\n	.redirect {\n		width: 918px;\n		margin: 24px auto 0px;\n		font-size: 14px;\n		line-height: 14px;\n		text-align: center;\n	}\n	.redirect a {\n		color: #ffb300;\n		text-decoration: none;\n	}\n	</style>\n</head>\n<body>\n	<div class="alert-container">\n		<div class="alert-inner">\n			<div class="alert-heading">404 - Page Not Found</div>\n			<div class="alert-subheading">Sorry, the page you are looking for does not exist</div>\n		</div>\n	</div>\n	<div class="redirect">Please check the URL.  Otherwise, <a href=\'/\'>click here</a> to be redirected to the homepage.</div>\n</body>\n</html>\n\n    [response] => Array\n        (\n            [code] => 404\n            [message] => Not Found\n        )\n\n    [cookies] => Array\n        (\n        )\n\n    [filename] => \n)\n\n\n********************************************\n******  Log date: 2014/03/21 16:03:38 ******\n********************************************\n\nWPMDB Error: Unable to connect to the remote server, please check the connection details - 404 Not Found (#129 - scope: ajax_verify_connection_to_remote_site)\n\nAttempted to connect to: http://nick.bronsonrocktx.com/wp-admin/admin-ajax.php\n\nArray\n(\n    [headers] => Array\n        (\n            [date] => Fri, 21 Mar 2014 16:03:38 GMT\n            [server] => Apache\n            [x-host] => app-64-47.intern.weebly.net\n            [x-ua-compatible] => IE=edge,chrome=1\n            [content-length] => 1513\n            [connection] => close\n            [content-type] => text/html; charset=UTF-8\n        )\n\n    [body] => <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">\n<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">\n<head>\n	<title>404 - Page Not Found</title>\n	<meta http-equiv="content-type" content="text/html; charset=UTF-8" />\n	<meta name="robots" content="noarchive" />\n	<link rel="shortcut icon" href="http://cdn1.editmysite.com/developer/none.ico" />\n\n	<style type="text/css">\n	body {\n		background: url(http://cdn1.editmysite.com/images/404background.jpg);\n		font-family: Helvetica, arial, sans-serif;\n		color: #ccc;\n	}\n	.alert-container {\n		background: url(http://cdn1.editmysite.com/images/404_textbox.png);\n		width: 918px;\n		height: 142px;\n		margin: 82px auto 0px;\n	}\n	.alert-inner {\n		padding: 24px 0px 0px 209px;\n	}\n	.alert-heading {\n		font-size: 50px;\n		font-weight: bold;\n		line-height: 50px;\n	}\n	.alert-subheading {\n		margin-top: 8px;\n		font-size: 28px;\n		line-height: 28px;\n	}\n	.redirect {\n		width: 918px;\n		margin: 24px auto 0px;\n		font-size: 14px;\n		line-height: 14px;\n		text-align: center;\n	}\n	.redirect a {\n		color: #ffb300;\n		text-decoration: none;\n	}\n	</style>\n</head>\n<body>\n	<div class="alert-container">\n		<div class="alert-inner">\n			<div class="alert-heading">404 - Page Not Found</div>\n			<div class="alert-subheading">Sorry, the page you are looking for does not exist</div>\n		</div>\n	</div>\n	<div class="redirect">Please check the URL.  Otherwise, <a href=\'/\'>click here</a> to be redirected to the homepage.</div>\n</body>\n</html>\n\n    [response] => Array\n        (\n            [code] => 404\n            [message] => Not Found\n        )\n\n    [cookies] => Array\n        (\n        )\n\n    [filename] => \n)\n\n\n', 'yes'),
(1068, 'wpmdb_settings', 'a:8:{s:11:"max_request";i:1048576;s:3:"key";s:32:"Bb2KbLZLF21FWHrtML31O5CEUl2Jb6hC";s:10:"allow_pull";b:0;s:10:"allow_push";b:0;s:8:"profiles";a:3:{i:0;a:18:{s:13:"save_computer";s:1:"1";s:9:"gzip_file";s:1:"1";s:13:"replace_guids";s:1:"1";s:12:"exclude_spam";s:1:"0";s:19:"keep_active_plugins";s:1:"0";s:13:"create_backup";s:1:"1";s:18:"exclude_post_types";s:1:"0";s:6:"action";s:4:"push";s:15:"connection_info";s:63:"http://br.paradoxcreative.com\r\nbynVrZ13aQZMylCFqukbFNpEhoyep/jq";s:11:"replace_old";a:2:{i:1;s:24:"//nick.bronsonrocktx.com";i:2;s:49:"/Users/nickmeagher/Sites/Bronson Rock/public_html";}s:11:"replace_new";a:2:{i:1;s:24:"//br.paradoxcreative.com";i:2;s:33:"/var/www/bronson_rock/public_html";}s:20:"table_migrate_option";s:24:"migrate_only_with_prefix";s:18:"exclude_transients";s:1:"1";s:13:"backup_option";s:23:"backup_only_with_prefix";s:22:"save_migration_profile";s:1:"1";s:29:"save_migration_profile_option";s:1:"0";s:18:"create_new_profile";s:22:"br.paradoxcreative.com";s:4:"name";s:21:"Push: Local > Staging";}i:1;a:17:{s:13:"save_computer";s:1:"1";s:9:"gzip_file";s:1:"1";s:13:"replace_guids";s:1:"1";s:12:"exclude_spam";s:1:"0";s:19:"keep_active_plugins";s:1:"0";s:13:"create_backup";s:1:"1";s:6:"action";s:4:"pull";s:15:"connection_info";s:63:"http://br.paradoxcreative.com\r\nbynVrZ13aQZMylCFqukbFNpEhoyep/jq";s:11:"replace_old";a:2:{i:1;s:24:"//br.paradoxcreative.com";i:2;s:33:"/var/www/bronson_rock/public_html";}s:11:"replace_new";a:2:{i:1;s:24:"//nick.bronsonrocktx.com";i:2;s:49:"/Users/nickmeagher/Sites/Bronson Rock/public_html";}s:20:"table_migrate_option";s:24:"migrate_only_with_prefix";s:24:"post_type_migrate_option";s:22:"migrate_all_post_types";s:13:"backup_option";s:23:"backup_only_with_prefix";s:22:"save_migration_profile";s:1:"1";s:29:"save_migration_profile_option";s:3:"new";s:18:"create_new_profile";s:21:"Pull: Staging > Local";s:4:"name";s:21:"Pull: Staging > Local";}i:2;a:18:{s:13:"save_computer";s:1:"0";s:9:"gzip_file";s:1:"1";s:13:"replace_guids";s:1:"1";s:12:"exclude_spam";s:1:"0";s:19:"keep_active_plugins";s:1:"0";s:13:"create_backup";s:1:"0";s:18:"exclude_post_types";s:1:"0";s:6:"action";s:8:"savefile";s:15:"connection_info";s:0:"";s:11:"replace_old";a:2:{i:1;s:24:"//nick.bronsonrocktx.com";i:2;s:49:"/Users/nickmeagher/Sites/Bronson Rock/public_html";}s:11:"replace_new";a:2:{i:1;s:24:"//nick.bronsonrocktx.com";i:2;s:49:"/Users/nickmeagher/Sites/Bronson Rock/public_html";}s:20:"table_migrate_option";s:24:"migrate_only_with_prefix";s:18:"exclude_transients";s:1:"1";s:13:"backup_option";s:23:"backup_only_with_prefix";s:22:"save_migration_profile";s:1:"1";s:29:"save_migration_profile_option";s:1:"2";s:18:"create_new_profile";s:0:"";s:4:"name";s:24:"Backup to uploads folder";}}s:7:"licence";s:36:"4451cb15-9ae0-4ba0-a513-46ce44235bc9";s:10:"verify_ssl";b:0;s:17:"blacklist_plugins";a:0:{}}', 'yes'),
(1105, 'can_compress_scripts', '1', 'yes'),
(1287, 'acf_version', '4.3.8', 'yes'),
(1294, 'cpt_custom_post_types', 'a:1:{i:0;a:21:{s:4:"name";s:5:"event";s:5:"label";s:6:"Events";s:14:"singular_label";s:5:"Event";s:11:"description";s:0:"";s:6:"public";s:1:"1";s:7:"show_ui";s:1:"1";s:11:"has_archive";s:1:"1";s:19:"exclude_from_search";s:1:"0";s:15:"capability_type";s:4:"post";s:12:"hierarchical";s:1:"1";s:7:"rewrite";s:1:"1";s:12:"rewrite_slug";s:6:"events";s:17:"rewrite_withfront";s:1:"1";s:9:"query_var";s:1:"1";s:13:"menu_position";s:1:"2";s:12:"show_in_menu";s:1:"1";s:19:"show_in_menu_string";s:0:"";s:9:"menu_icon";s:0:"";i:0;a:2:{i:0;s:5:"title";i:1;s:9:"revisions";}i:1;N;i:2;a:12:{s:9:"menu_name";s:11:"Live Events";s:7:"add_new";s:0:"";s:12:"add_new_item";s:0:"";s:4:"edit";s:0:"";s:9:"edit_item";s:0:"";s:8:"new_item";s:0:"";s:4:"view";s:0:"";s:9:"view_item";s:0:"";s:12:"search_items";s:0:"";s:9:"not_found";s:0:"";s:18:"not_found_in_trash";s:0:"";s:6:"parent";s:0:"";}}}', 'yes'),
(1365, 'rewrite_rules', 'a:84:{s:9:"events/?$";s:25:"index.php?post_type=event";s:39:"events/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?post_type=event&feed=$matches[1]";s:34:"events/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?post_type=event&feed=$matches[1]";s:26:"events/page/([0-9]{1,})/?$";s:43:"index.php?post_type=event&paged=$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:32:"events/.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:42:"events/.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:62:"events/.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"events/.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"events/.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:25:"events/(.+?)/trackback/?$";s:32:"index.php?event=$matches[1]&tb=1";s:45:"events/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?event=$matches[1]&feed=$matches[2]";s:40:"events/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?event=$matches[1]&feed=$matches[2]";s:33:"events/(.+?)/page/?([0-9]{1,})/?$";s:45:"index.php?event=$matches[1]&paged=$matches[2]";s:40:"events/(.+?)/comment-page-([0-9]{1,})/?$";s:45:"index.php?event=$matches[1]&cpage=$matches[2]";s:25:"events/(.+?)(/[0-9]+)?/?$";s:44:"index.php?event=$matches[1]&page=$matches[2]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=4&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)(/[0-9]+)?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";}', 'yes'),
(1371, 'pagenavi_options', 'a:15:{s:10:"pages_text";s:0:"";s:12:"current_text";s:13:"%PAGE_NUMBER%";s:9:"page_text";s:13:"%PAGE_NUMBER%";s:10:"first_text";s:8:"« First";s:9:"last_text";s:7:"Last »";s:9:"prev_text";s:2:"«";s:9:"next_text";s:2:"»";s:12:"dotleft_text";s:3:"...";s:13:"dotright_text";s:3:"...";s:9:"num_pages";i:5;s:23:"num_larger_page_numbers";i:3;s:28:"larger_page_numbers_multiple";i:10;s:11:"always_show";i:0;s:16:"use_pagenavi_css";i:0;s:5:"style";i:1;}', 'yes') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=1227 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(2, 4, '_edit_last', '2'),
(3, 4, '_edit_lock', '1408303735:2'),
(176, 54, '_menu_item_type', 'post_type'),
(177, 54, '_menu_item_menu_item_parent', '0'),
(178, 54, '_menu_item_object_id', '4'),
(179, 54, '_menu_item_object', 'page'),
(180, 54, '_menu_item_target', ''),
(181, 54, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(182, 54, '_menu_item_xfn', ''),
(183, 54, '_menu_item_url', ''),
(212, 58, '_menu_item_type', 'post_type'),
(213, 58, '_menu_item_menu_item_parent', '0'),
(214, 58, '_menu_item_object_id', '10'),
(215, 58, '_menu_item_object', 'page'),
(216, 58, '_menu_item_target', ''),
(217, 58, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(218, 58, '_menu_item_xfn', ''),
(219, 58, '_menu_item_url', ''),
(230, 60, '_menu_item_type', 'post_type'),
(231, 60, '_menu_item_menu_item_parent', '59'),
(232, 60, '_menu_item_object_id', '12'),
(233, 60, '_menu_item_object', 'page'),
(234, 60, '_menu_item_target', ''),
(235, 60, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(236, 60, '_menu_item_xfn', ''),
(237, 60, '_menu_item_url', ''),
(239, 61, '_menu_item_type', 'post_type'),
(240, 61, '_menu_item_menu_item_parent', '59'),
(241, 61, '_menu_item_object_id', '13'),
(242, 61, '_menu_item_object', 'page'),
(243, 61, '_menu_item_target', ''),
(244, 61, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(245, 61, '_menu_item_xfn', ''),
(246, 61, '_menu_item_url', ''),
(248, 62, '_menu_item_type', 'post_type'),
(249, 62, '_menu_item_menu_item_parent', '0'),
(250, 62, '_menu_item_object_id', '14'),
(251, 62, '_menu_item_object', 'page'),
(252, 62, '_menu_item_target', ''),
(253, 62, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(254, 62, '_menu_item_xfn', ''),
(255, 62, '_menu_item_url', ''),
(257, 63, '_menu_item_type', 'post_type'),
(258, 63, '_menu_item_menu_item_parent', '0'),
(259, 63, '_menu_item_object_id', '15'),
(260, 63, '_menu_item_object', 'page'),
(261, 63, '_menu_item_target', ''),
(262, 63, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(263, 63, '_menu_item_xfn', ''),
(264, 63, '_menu_item_url', ''),
(275, 65, '_menu_item_type', 'post_type'),
(276, 65, '_menu_item_menu_item_parent', '0'),
(277, 65, '_menu_item_object_id', '17'),
(278, 65, '_menu_item_object', 'page'),
(279, 65, '_menu_item_target', ''),
(280, 65, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(281, 65, '_menu_item_xfn', ''),
(282, 65, '_menu_item_url', ''),
(293, 67, '_menu_item_type', 'post_type'),
(294, 67, '_menu_item_menu_item_parent', '65'),
(295, 67, '_menu_item_object_id', '19'),
(296, 67, '_menu_item_object', 'page'),
(297, 67, '_menu_item_target', ''),
(298, 67, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(299, 67, '_menu_item_xfn', ''),
(300, 67, '_menu_item_url', ''),
(302, 68, '_menu_item_type', 'post_type'),
(303, 68, '_menu_item_menu_item_parent', '0'),
(304, 68, '_menu_item_object_id', '20'),
(305, 68, '_menu_item_object', 'page'),
(306, 68, '_menu_item_target', ''),
(307, 68, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(308, 68, '_menu_item_xfn', ''),
(309, 68, '_menu_item_url', ''),
(311, 69, '_menu_item_type', 'post_type'),
(312, 69, '_menu_item_menu_item_parent', '0'),
(313, 69, '_menu_item_object_id', '21'),
(314, 69, '_menu_item_object', 'page'),
(315, 69, '_menu_item_target', ''),
(316, 69, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(317, 69, '_menu_item_xfn', ''),
(318, 69, '_menu_item_url', ''),
(350, 17, '_edit_lock', '1399584612:1'),
(351, 17, '_edit_last', '1'),
(356, 20, '_edit_lock', '1399584581:1'),
(357, 20, '_edit_last', '1'),
(359, 4, '_wp_page_template', 'page-home.php'),
(363, 112, '_menu_item_type', 'post_type'),
(364, 112, '_menu_item_menu_item_parent', '0'),
(365, 112, '_menu_item_object_id', '4'),
(366, 112, '_menu_item_object', 'page'),
(367, 112, '_menu_item_target', ''),
(368, 112, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(369, 112, '_menu_item_xfn', ''),
(370, 112, '_menu_item_url', ''),
(417, 118, '_menu_item_type', 'post_type'),
(418, 118, '_menu_item_menu_item_parent', '0'),
(419, 118, '_menu_item_object_id', '12'),
(420, 118, '_menu_item_object', 'page'),
(421, 118, '_menu_item_target', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(422, 118, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(423, 118, '_menu_item_xfn', ''),
(424, 118, '_menu_item_url', ''),
(426, 119, '_menu_item_type', 'post_type'),
(427, 119, '_menu_item_menu_item_parent', '0'),
(428, 119, '_menu_item_object_id', '13'),
(429, 119, '_menu_item_object', 'page'),
(430, 119, '_menu_item_target', ''),
(431, 119, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(432, 119, '_menu_item_xfn', ''),
(433, 119, '_menu_item_url', ''),
(435, 120, '_menu_item_type', 'post_type'),
(436, 120, '_menu_item_menu_item_parent', '0'),
(437, 120, '_menu_item_object_id', '14'),
(438, 120, '_menu_item_object', 'page'),
(439, 120, '_menu_item_target', ''),
(440, 120, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(441, 120, '_menu_item_xfn', ''),
(442, 120, '_menu_item_url', ''),
(606, 139, '_menu_item_type', 'post_type'),
(607, 139, '_menu_item_menu_item_parent', '0'),
(608, 139, '_menu_item_object_id', '17'),
(609, 139, '_menu_item_object', 'page'),
(610, 139, '_menu_item_target', ''),
(611, 139, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(612, 139, '_menu_item_xfn', ''),
(613, 139, '_menu_item_url', ''),
(624, 141, '_menu_item_type', 'post_type'),
(625, 141, '_menu_item_menu_item_parent', '0'),
(626, 141, '_menu_item_object_id', '19'),
(627, 141, '_menu_item_object', 'page'),
(628, 141, '_menu_item_target', ''),
(629, 141, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(630, 141, '_menu_item_xfn', ''),
(631, 141, '_menu_item_url', ''),
(651, 144, '_menu_item_type', 'post_type'),
(652, 144, '_menu_item_menu_item_parent', '0'),
(653, 144, '_menu_item_object_id', '21'),
(654, 144, '_menu_item_object', 'page'),
(655, 144, '_menu_item_target', ''),
(656, 144, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(657, 144, '_menu_item_xfn', ''),
(658, 144, '_menu_item_url', ''),
(660, 145, '_menu_item_type', 'post_type'),
(661, 145, '_menu_item_menu_item_parent', '0'),
(662, 145, '_menu_item_object_id', '20'),
(663, 145, '_menu_item_object', 'page'),
(664, 145, '_menu_item_target', ''),
(665, 145, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(666, 145, '_menu_item_xfn', ''),
(667, 145, '_menu_item_url', ''),
(687, 207, '_menu_item_type', 'post_type'),
(688, 207, '_menu_item_menu_item_parent', '0'),
(689, 207, '_menu_item_object_id', '10'),
(690, 207, '_menu_item_object', 'page'),
(691, 207, '_menu_item_target', ''),
(692, 207, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(693, 207, '_menu_item_xfn', ''),
(694, 207, '_menu_item_url', ''),
(705, 17, '_wp_page_template', 'default'),
(770, 255, '_menu_item_type', 'post_type'),
(771, 255, '_menu_item_menu_item_parent', '0'),
(772, 255, '_menu_item_object_id', '15'),
(773, 255, '_menu_item_object', 'page'),
(774, 255, '_menu_item_target', ''),
(775, 255, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(776, 255, '_menu_item_xfn', ''),
(777, 255, '_menu_item_url', ''),
(779, 256, '_menu_item_type', 'post_type'),
(780, 256, '_menu_item_menu_item_parent', '0'),
(781, 256, '_menu_item_object_id', '252'),
(782, 256, '_menu_item_object', 'page'),
(783, 256, '_menu_item_target', ''),
(784, 256, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(785, 256, '_menu_item_xfn', ''),
(786, 256, '_menu_item_url', ''),
(965, 355, '_menu_item_type', 'post_type'),
(966, 355, '_menu_item_menu_item_parent', '0'),
(967, 355, '_menu_item_object_id', '4'),
(968, 355, '_menu_item_object', 'page'),
(969, 355, '_menu_item_target', ''),
(970, 355, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(971, 355, '_menu_item_xfn', ''),
(972, 355, '_menu_item_url', ''),
(974, 356, '_menu_item_type', 'post_type'),
(975, 356, '_menu_item_menu_item_parent', '0'),
(976, 356, '_menu_item_object_id', '4'),
(977, 356, '_menu_item_object', 'page'),
(978, 356, '_menu_item_target', ''),
(979, 356, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(980, 356, '_menu_item_xfn', ''),
(981, 356, '_menu_item_url', ''),
(982, 356, '_menu_item_orphaned', '1399494236'),
(983, 357, '_menu_item_type', 'post_type'),
(984, 357, '_menu_item_menu_item_parent', '0'),
(985, 357, '_menu_item_object_id', '17'),
(986, 357, '_menu_item_object', 'page'),
(987, 357, '_menu_item_target', ''),
(988, 357, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(989, 357, '_menu_item_xfn', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(990, 357, '_menu_item_url', ''),
(1010, 360, '_menu_item_type', 'post_type'),
(1011, 360, '_menu_item_menu_item_parent', '0'),
(1012, 360, '_menu_item_object_id', '349'),
(1013, 360, '_menu_item_object', 'page'),
(1014, 360, '_menu_item_target', ''),
(1015, 360, '_menu_item_classes', 'a:1:{i:0;s:12:"feature-item";}'),
(1016, 360, '_menu_item_xfn', ''),
(1017, 360, '_menu_item_url', ''),
(1019, 361, '_menu_item_type', 'post_type'),
(1020, 361, '_menu_item_menu_item_parent', '0'),
(1021, 361, '_menu_item_object_id', '350'),
(1022, 361, '_menu_item_object', 'page'),
(1023, 361, '_menu_item_target', ''),
(1024, 361, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1025, 361, '_menu_item_xfn', ''),
(1026, 361, '_menu_item_url', ''),
(1028, 362, '_menu_item_type', 'post_type'),
(1029, 362, '_menu_item_menu_item_parent', '0'),
(1030, 362, '_menu_item_object_id', '351'),
(1031, 362, '_menu_item_object', 'page'),
(1032, 362, '_menu_item_target', ''),
(1033, 362, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1034, 362, '_menu_item_xfn', ''),
(1035, 362, '_menu_item_url', ''),
(1037, 363, '_menu_item_type', 'post_type'),
(1038, 363, '_menu_item_menu_item_parent', '0'),
(1039, 363, '_menu_item_object_id', '352'),
(1040, 363, '_menu_item_object', 'page'),
(1041, 363, '_menu_item_target', ''),
(1042, 363, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1043, 363, '_menu_item_xfn', ''),
(1044, 363, '_menu_item_url', ''),
(1046, 364, '_menu_item_type', 'post_type'),
(1047, 364, '_menu_item_menu_item_parent', '0'),
(1048, 364, '_menu_item_object_id', '353'),
(1049, 364, '_menu_item_object', 'page'),
(1050, 364, '_menu_item_target', ''),
(1051, 364, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1052, 364, '_menu_item_xfn', ''),
(1053, 364, '_menu_item_url', ''),
(1055, 365, '_menu_item_type', 'post_type'),
(1056, 365, '_menu_item_menu_item_parent', '0'),
(1057, 365, '_menu_item_object_id', '354'),
(1058, 365, '_menu_item_object', 'page'),
(1059, 365, '_menu_item_target', ''),
(1060, 365, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1061, 365, '_menu_item_xfn', ''),
(1062, 365, '_menu_item_url', ''),
(1063, 20, '_wp_page_template', 'default'),
(1064, 21, '_edit_lock', '1399584681:1'),
(1065, 351, '_edit_lock', '1400883571:1'),
(1066, 21, '_edit_last', '1'),
(1067, 21, '_wp_page_template', 'default'),
(1068, 20, '_oembed_e54b63b268ce419143d62b6339a7536f', '{{unknown}}'),
(1069, 351, '_edit_last', '1'),
(1070, 351, '_wp_page_template', 'page-menu.php'),
(1071, 349, '_edit_last', '1'),
(1072, 349, '_wp_page_template', 'archive-event.php'),
(1073, 349, '_edit_lock', '1408304362:2'),
(1074, 387, '_edit_lock', '1408306459:2'),
(1075, 387, '_edit_last', '2'),
(1076, 387, 'field_53f0ff9cea560', 'a:14:{s:3:"key";s:19:"field_53f0ff9cea560";s:5:"label";s:5:"Title";s:4:"name";s:11:"event_title";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"none";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(1077, 387, 'field_53f0ffadea561', 'a:11:{s:3:"key";s:19:"field_53f0ffadea561";s:5:"label";s:10:"Event Date";s:4:"name";s:10:"event_date";s:4:"type";s:11:"date_picker";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:11:"date_format";s:6:"yymmdd";s:14:"display_format";s:8:"mm/dd/yy";s:9:"first_day";s:1:"1";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:19:"field_53f10001ea562";s:8:"operator";s:2:"==";s:5:"value";s:1:"5";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}'),
(1078, 387, 'field_53f10001ea562', 'a:12:{s:3:"key";s:19:"field_53f10001ea562";s:5:"label";s:10:"Event Time";s:4:"name";s:10:"event_time";s:4:"type";s:6:"select";s:12:"instructions";s:0:"";s:8:"required";s:1:"1";s:7:"choices";a:13:{s:6:"5:00PM";s:6:"5:00PM";s:6:"5:30PM";s:6:"5:30PM";s:6:"6:00PM";s:6:"6:00PM";s:6:"6:30PM";s:6:"6:30PM";s:6:"7:00PM";s:6:"7:00PM";s:6:"7:30PM";s:6:"7:30PM";s:6:"8:00PM";s:6:"8:00PM";s:6:"8:30PM";s:6:"8:30PM";s:6:"9:00PM";s:6:"9:00PM";s:6:"9:30PM";s:6:"9:30PM";s:7:"10:00PM";s:7:"10:00PM";s:7:"10:30PM";s:7:"10:30PM";s:7:"11:00PM";s:7:"11:00PM";}s:13:"default_value";s:0:"";s:10:"allow_null";s:1:"0";s:8:"multiple";s:1:"0";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:2;}'),
(1079, 387, 'field_53f10091ea563', 'a:14:{s:3:"key";s:19:"field_53f10091ea563";s:5:"label";s:3:"URL";s:4:"name";s:3:"url";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:7:"http://";s:6:"append";s:0:"";s:10:"formatting";s:4:"none";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:19:"field_53f10001ea562";s:8:"operator";s:2:"==";s:5:"value";s:1:"5";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:3;}'),
(1081, 387, 'position', 'normal'),
(1082, 387, 'layout', 'default'),
(1083, 387, 'hide_on_screen', ''),
(1084, 388, '_edit_lock', '1408303269:2'),
(1085, 388, '_edit_last', '2'),
(1086, 389, 'event_title', 'Metal Band'),
(1087, 389, '_event_title', 'field_53f0ff9cea560'),
(1088, 389, 'event_date', '20140809'),
(1089, 389, '_event_date', 'field_53f0ffadea561'),
(1090, 389, 'event_time', '8:00PM'),
(1091, 389, '_event_time', 'field_53f10001ea562'),
(1092, 389, 'url', 'www.nickmeagher.com'),
(1093, 389, '_url', 'field_53f10091ea563'),
(1094, 388, 'event_title', 'Metal Band'),
(1095, 388, '_event_title', 'field_53f0ff9cea560'),
(1096, 388, 'event_date', '20140809'),
(1097, 388, '_event_date', 'field_53f0ffadea561'),
(1098, 388, 'event_time', '8:00PM'),
(1099, 388, '_event_time', 'field_53f10001ea562'),
(1100, 388, 'url', 'www.nickmeagher.com'),
(1101, 388, '_url', 'field_53f10091ea563'),
(1102, 390, '_edit_lock', '1408303677:2'),
(1103, 390, '_edit_last', '2'),
(1104, 391, 'event_title', 'Punk Band'),
(1105, 391, '_event_title', 'field_53f0ff9cea560'),
(1106, 391, 'event_date', '20140819'),
(1107, 391, '_event_date', 'field_53f0ffadea561'),
(1108, 391, 'event_time', '7:00PM'),
(1109, 391, '_event_time', 'field_53f10001ea562'),
(1110, 391, 'url', 'www.facebook.com'),
(1111, 391, '_url', 'field_53f10091ea563'),
(1112, 390, 'event_title', 'Punk Band'),
(1113, 390, '_event_title', 'field_53f0ff9cea560'),
(1114, 390, 'event_date', '20140819') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1115, 390, '_event_date', 'field_53f0ffadea561'),
(1116, 390, 'event_time', '7:00PM'),
(1117, 390, '_event_time', 'field_53f10001ea562'),
(1118, 390, 'url', 'www.facebook.com'),
(1119, 390, '_url', 'field_53f10091ea563'),
(1120, 392, '_edit_lock', '1408304258:2'),
(1121, 392, '_edit_last', '2'),
(1122, 393, 'event_title', 'Jazz Band'),
(1123, 393, '_event_title', 'field_53f0ff9cea560'),
(1124, 393, 'event_date', '20140821'),
(1125, 393, '_event_date', 'field_53f0ffadea561'),
(1126, 393, 'event_time', '10:00PM'),
(1127, 393, '_event_time', 'field_53f10001ea562'),
(1128, 393, 'url', 'www.google.com'),
(1129, 393, '_url', 'field_53f10091ea563'),
(1130, 392, 'event_title', 'Jazz Band'),
(1131, 392, '_event_title', 'field_53f0ff9cea560'),
(1132, 392, 'event_date', '20140821'),
(1133, 392, '_event_date', 'field_53f0ffadea561'),
(1134, 392, 'event_time', '10:00PM'),
(1135, 392, '_event_time', 'field_53f10001ea562'),
(1136, 392, 'url', 'www.google.com'),
(1137, 392, '_url', 'field_53f10091ea563'),
(1138, 394, '_edit_lock', '1408304301:2'),
(1139, 394, '_edit_last', '2'),
(1140, 395, 'event_title', 'Rock Band'),
(1141, 395, '_event_title', 'field_53f0ff9cea560'),
(1142, 395, 'event_date', '20140827'),
(1143, 395, '_event_date', 'field_53f0ffadea561'),
(1144, 395, 'event_time', '8:30PM'),
(1145, 395, '_event_time', 'field_53f10001ea562'),
(1146, 395, 'url', 'www.yahoo.com'),
(1147, 395, '_url', 'field_53f10091ea563'),
(1148, 394, 'event_title', 'Rock Band'),
(1149, 394, '_event_title', 'field_53f0ff9cea560'),
(1150, 394, 'event_date', '20140827'),
(1151, 394, '_event_date', 'field_53f0ffadea561'),
(1152, 394, 'event_time', '8:30PM'),
(1153, 394, '_event_time', 'field_53f10001ea562'),
(1154, 394, 'url', 'www.yahoo.com'),
(1155, 394, '_url', 'field_53f10091ea563'),
(1156, 396, '_edit_lock', '1408305247:2'),
(1157, 396, '_edit_last', '2'),
(1158, 397, 'event_title', 'Techno Band'),
(1159, 397, '_event_title', 'field_53f0ff9cea560'),
(1160, 397, 'event_date', '20140830'),
(1161, 397, '_event_date', 'field_53f0ffadea561'),
(1162, 397, 'event_time', '8:00PM'),
(1163, 397, '_event_time', 'field_53f10001ea562'),
(1164, 397, 'url', 'www.paradoxcreative.com'),
(1165, 397, '_url', 'field_53f10091ea563'),
(1166, 396, 'event_title', 'Techno Band'),
(1167, 396, '_event_title', 'field_53f0ff9cea560'),
(1168, 396, 'event_date', '20140830'),
(1169, 396, '_event_date', 'field_53f0ffadea561'),
(1170, 396, 'event_time', '8:00PM'),
(1171, 396, '_event_time', 'field_53f10001ea562'),
(1172, 396, 'url', 'www.paradoxcreative.com'),
(1173, 396, '_url', 'field_53f10091ea563'),
(1174, 387, 'rule', 'a:5:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:5:"event";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
(1175, 398, '_edit_lock', '1408560276:1'),
(1176, 398, '_edit_last', '1'),
(1177, 399, 'event_title', 'Fake Band'),
(1178, 399, '_event_title', 'field_53f0ff9cea560'),
(1179, 399, 'event_date', '20140813'),
(1180, 399, '_event_date', 'field_53f0ffadea561'),
(1181, 399, 'event_time', '7:30PM'),
(1182, 399, '_event_time', 'field_53f10001ea562'),
(1183, 399, 'url', 'www.icepick.co'),
(1184, 399, '_url', 'field_53f10091ea563'),
(1185, 398, 'event_title', 'Test Band'),
(1186, 398, '_event_title', 'field_53f0ff9cea560'),
(1187, 398, 'event_date', '20140805'),
(1188, 398, '_event_date', 'field_53f0ffadea561'),
(1189, 398, 'event_time', '7:30PM'),
(1190, 398, '_event_time', 'field_53f10001ea562'),
(1191, 398, 'url', 'google.com'),
(1192, 398, '_url', 'field_53f10091ea563'),
(1193, 400, '_edit_lock', '1408309523:2'),
(1194, 400, '_edit_last', '2'),
(1195, 401, 'event_title', 'Fake Band #2'),
(1196, 401, '_event_title', 'field_53f0ff9cea560'),
(1197, 401, 'event_date', '20140822'),
(1198, 401, '_event_date', 'field_53f0ffadea561'),
(1199, 401, 'event_time', '8:00PM'),
(1200, 401, '_event_time', 'field_53f10001ea562'),
(1201, 401, 'url', 'www.fakewebsite.com'),
(1202, 401, '_url', 'field_53f10091ea563'),
(1203, 400, 'event_title', 'Fake Band #2'),
(1204, 400, '_event_title', 'field_53f0ff9cea560'),
(1205, 400, 'event_date', '20140822'),
(1206, 400, '_event_date', 'field_53f0ffadea561'),
(1207, 400, 'event_time', '8:00PM'),
(1208, 400, '_event_time', 'field_53f10001ea562'),
(1209, 400, 'url', 'www.fakewebsite.com'),
(1210, 400, '_url', 'field_53f10091ea563'),
(1211, 403, 'event_title', 'Fake Band'),
(1212, 403, '_event_title', 'field_53f0ff9cea560'),
(1213, 403, 'event_date', '20140805'),
(1214, 403, '_event_date', 'field_53f0ffadea561') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1215, 403, 'event_time', '7:30PM'),
(1216, 403, '_event_time', 'field_53f10001ea562'),
(1217, 403, 'url', 'google.com'),
(1218, 403, '_url', 'field_53f10091ea563'),
(1219, 404, 'event_title', 'Test Band'),
(1220, 404, '_event_title', 'field_53f0ff9cea560'),
(1221, 404, 'event_date', '20140805'),
(1222, 404, '_event_date', 'field_53f0ffadea561'),
(1223, 404, 'event_time', '7:30PM'),
(1224, 404, '_event_time', 'field_53f10001ea562'),
(1225, 404, 'url', 'google.com'),
(1226, 404, '_url', 'field_53f10091ea563') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=405 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2014-02-24 13:54:52', '2014-02-24 13:54:52', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2014-02-24 13:54:52', '2014-02-24 13:54:52', '', 0, 'http://nick.bronsonrocktx.com/?p=1', 0, 'post', '', 1),
(4, 1, '2014-02-24 18:42:06', '2014-02-24 18:42:06', '<h1>Commercial &amp; Residential Property Inspections</h1>\r\n<strong><em><span style="color: #f00c0c;">X</span><span style="color: #0a72b4;">stream </span><span style="color: #f00909;">Inspections </span></em></strong>is a <strong>“Woman Owned Business”</strong> that offers a comprehensive, in-depth detailed inspection that goes <strong>beyond</strong> what is required by the minimum standards required by the Texas Real Estate Commission.  <strong>Our 200 point, 50-100 digitally documented inspection</strong> gives you the comfort of knowing that your real estate purchase, sale or lease is being tested, inspected and analyzed by the best in the business.  Our Team of <strong>Licensed Specialists </strong>is available for telephone consultation during your structural and mechanical inspection and if needed an appointment can be made for a specialty inspection if discovery is needed.\r\n\r\nOur 34 years of construction/industry experience and Professionally Licensed Team of Specialists gives us the upper hand on the competition. We have performed over 6000 inspections and take pride our ability to multi-task, accompanied with our detailed skill set to ensure that your inspection needs are proficiently documented.', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2014-08-17 13:31:16', '2014-08-17 19:31:16', '', 0, 'http://nick.bronsonrocktx.com/?page_id=4', 0, 'page', '', 0),
(5, 1, '2014-02-24 18:42:06', '2014-02-24 18:42:06', 'Test', 'Home', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-02-24 18:42:06', '2014-02-24 18:42:06', '', 4, 'http://nick.bronsonrocktx.com/?p=5', 0, 'revision', '', 0),
(8, 1, '2014-02-25 13:46:06', '2014-02-25 13:46:06', '<p style="text-align: right;">Test</p>', 'Home', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-02-25 13:46:06', '2014-02-25 13:46:06', '', 4, 'http://nick.bronsonrocktx.com/?p=8', 0, 'revision', '', 0),
(17, 1, '2014-02-25 13:54:21', '2014-02-25 13:54:21', 'Content coming soon. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam ac hendrerit massa, in lacinia tellus. Pellentesque volutpat enim bibendum nisl rutrum eleifend. Curabitur eleifend accumsan libero a hendrerit. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aliquam placerat quam ac turpis tempor interdum. Nam dignissim augue non malesuada bibendum. Donec vitae orci erat. Sed congue ligula sed quam hendrerit iaculis. Nulla fringilla est volutpat sem tempor, at sagittis dui fringilla. In hac habitasse platea dictumst. Donec porttitor iaculis sapien eu sagittis. Vivamus sem neque, porttitor eu enim in, lacinia porta lectus.\r\n\r\nAenean fermentum mauris a nunc consectetur, vitae viverra eros imperdiet. Etiam vulputate nisl sed elementum rhoncus. Vestibulum varius, tortor blandit feugiat porttitor, mauris diam lobortis arcu, ultricies consequat nisl massa eget purus. Sed nec massa eu orci consequat egestas. Sed nec fringilla diam. Nunc fringilla, nulla venenatis congue facilisis, nisl sapien pharetra magna, quis tempus arcu libero consectetur leo. Duis volutpat in purus id vehicula. Mauris sed dui ut elit fringilla mattis. Cras vel enim quam. Nullam dapibus blandit lorem, sit amet fermentum felis hendrerit at. Vivamus porttitor leo mauris, ut laoreet felis varius posuere. Donec pharetra risus ac felis feugiat, eget vulputate elit ullamcorper. Curabitur sodales suscipit sem nec varius. Pellentesque libero lectus, luctus at justo vel, laoreet ullamcorper lacus. Duis vestibulum hendrerit ipsum, in lacinia turpis venenatis sit amet.', ' Contact Us', '', 'publish', 'closed', 'open', '', 'contact-us', '', '', '2014-05-08 15:32:34', '2014-05-08 21:32:34', '', 0, 'http://nick.bronsonrocktx.com/?page_id=17', 9, 'page', '', 0),
(20, 1, '2014-02-25 13:54:21', '2014-02-25 13:54:21', '<h3>What information do we collect?</h3>\r\n<div>\r\n\r\nWe collect information from you when you register on our site, place an order, subscribe to our newsletter, respond to a survey, fill out a form or send band information.\r\n\r\nWhen ordering or registering on our site, as appropriate, you may be asked to enter your: name, e-mail address, mailing address or phone number. You may, however, visit our site anonymously.\r\n<h3>What do we use your information for?</h3>\r\nAny of the information we collect from you may be used in one of the following ways:\r\n\r\n; To personalize your experience\r\n(your information helps us to better respond to your individual needs)\r\n\r\n; To improve our website\r\n(we continually strive to improve our website offerings based on the information and feedback we receive from you)\r\n\r\n; To improve customer service\r\n(your information helps us to more effectively respond to your customer service requests and support needs)\r\n\r\n; To administer a contest, promotion, survey or other site feature\r\n\r\n; To send periodic emails\r\n<blockquote>The email address you provide for order processing, may be used to send you information and updates pertaining to your order, in addition to receiving occasional company news, updates, related product or service information, etc.</blockquote>\r\nNote: If at any time you would like to unsubscribe from receiving future emails, we include detailed unsubscribe instructions at the bottom of each email.\r\n<h3>How do we protect your information?</h3>\r\nWe implement a variety of security measures to maintain the safety of your personal information when you place an order or enter, submit, or access your personal information.\r\n\r\nWe offer the use of a secure server. All supplied sensitive/credit information is transmitted via Secure Socket Layer (SSL) technology and then encrypted into our Payment gateway providers database only to be accessible by those authorized with special access rights to such systems, and are required to?keep the information confidential.\r\n\r\nAfter a transaction, your private information (credit cards, social security numbers, financials, etc.) will not be stored on our servers.\r\n<h3>Do we use cookies?</h3>\r\nYes (Cookies are small files that a site or its service provider transfers to your computers hard drive through your Web browser (if you allow) that enables the sites or service providers systems to recognize your browser and capture and remember certain information\r\n\r\nWe use cookies to understand and save your preferences for future visits, keep track of advertisements and compile aggregate data about site traffic and site interaction so that we can offer better site experiences and tools in the future. We may contract with third-party service providers to assist us in better understanding our site visitors. These service providers are not permitted to use the information collected on our behalf except to help us conduct and improve our business.\r\n\r\nIf you prefer, you can choose to have your computer warn you each time a cookie is being sent, or you can choose to turn off all cookies via your browser settings. Like most websites, if you turn your cookies off, some of our services may not function properly. However, you can still place orders over the telephone or by contacting customer service.\r\n<h3>Do we disclose any information to outside parties?</h3>\r\nWe do not sell, trade, or otherwise transfer to outside parties your personally identifiable information. This does not include trusted third parties who assist us in operating our website, conducting our business, or servicing you, so long as those parties agree to keep this information confidential. We may also release your information when we believe release is appropriate to comply with the law, enforce our site policies, or protect ours or others rights, property, or safety. However, non-personally identifiable visitor information may be provided to other parties for marketing, advertising, or other uses.\r\n<h3>Third party links</h3>\r\nOccasionally, at our discretion, we may include or offer third party products or services on our website. These third party sites have separate and independent privacy policies. We therefore have no responsibility or liability for the content and activities of these linked sites. Nonetheless, we seek to protect the integrity of our site and welcome any feedback about these sites.\r\n<h3>California Online Privacy Protection Act Compliance</h3>\r\nBecause we value your privacy we have taken the necessary precautions to be in compliance with the California Online Privacy Protection Act. We therefore will not distribute your personal information to outside parties without your consent.\r\n<h3>Childrens Online Privacy Protection Act Compliance</h3>\r\nWe are in compliance with the requirements of COPPA (Childrens Online Privacy Protection Act), we do not collect any information from anyone under 13 years of age. Our website, products and services are all directed to people who are at least 13 years old or older.\r\n<h3>Online Privacy Policy Only</h3>\r\nThis online privacy policy applies only to information collected through our website and not to information collected offline.\r\n<h3>Your Consent</h3>\r\nBy using our site, you consent to our web site privacy policy.\r\n<h3>Changes to our Privacy Policy</h3>\r\nIf we decide to change our privacy policy, we will post those changes on this page, and/or update the Privacy Policy modification date below.\r\n\r\nThis policy was last modified on 2/25/2014\r\n<h3>Contacting Us</h3>\r\nIf there are any questions regarding this privacy policy you may contact us using the information below.\r\n\r\nhttp://nick.bronsonrocktx.com\r\n\r\nBronson Rock\r\ninfo@dev.bronsonrocktx.com\r\n\r\n</div>', ' Privacy Policy', '', 'publish', 'closed', 'open', '', 'privacy', '', '', '2014-05-08 15:32:03', '2014-05-08 21:32:03', '', 0, 'http://nick.bronsonrocktx.com/?page_id=20', 12, 'page', '', 0),
(21, 1, '2014-02-25 13:54:21', '2014-02-25 13:54:21', 'Content coming soon. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam ac hendrerit massa, in lacinia tellus. Pellentesque volutpat enim bibendum nisl rutrum eleifend. Curabitur eleifend accumsan libero a hendrerit. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aliquam placerat quam ac turpis tempor interdum. Nam dignissim augue non malesuada bibendum. Donec vitae orci erat. Sed congue ligula sed quam hendrerit iaculis. Nulla fringilla est volutpat sem tempor, at sagittis dui fringilla. In hac habitasse platea dictumst. Donec porttitor iaculis sapien eu sagittis. Vivamus sem neque, porttitor eu enim in, lacinia porta lectus.\r\n\r\nAenean fermentum mauris a nunc consectetur, vitae viverra eros imperdiet. Etiam vulputate nisl sed elementum rhoncus. Vestibulum varius, tortor blandit feugiat porttitor, mauris diam lobortis arcu, ultricies consequat nisl massa eget purus. Sed nec massa eu orci consequat egestas. Sed nec fringilla diam. Nunc fringilla, nulla venenatis congue facilisis, nisl sapien pharetra magna, quis tempus arcu libero consectetur leo. Duis volutpat in purus id vehicula. Mauris sed dui ut elit fringilla mattis. Cras vel enim quam. Nullam dapibus blandit lorem, sit amet fermentum felis hendrerit at. Vivamus porttitor leo mauris, ut laoreet felis varius posuere. Donec pharetra risus ac felis feugiat, eget vulputate elit ullamcorper. Curabitur sodales suscipit sem nec varius. Pellentesque libero lectus, luctus at justo vel, laoreet ullamcorper lacus. Duis vestibulum hendrerit ipsum, in lacinia turpis venenatis sit amet.', ' Sitemap', '', 'publish', 'closed', 'open', '', 'sitemap', '', '', '2014-05-08 15:33:39', '2014-05-08 21:33:39', '', 0, 'http://nick.bronsonrocktx.com/?page_id=21', 13, 'page', '', 0),
(31, 1, '2014-02-25 13:55:02', '2014-02-25 13:55:02', '<h1> Contact Us\r</h1>Header Text<h1> Contact Us\r</h1>\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus viverra lorem id justo pellentesque accumsan. Aliquam in pretium enim, id rutrum enim. Aliquam non urna posuere, blandit nunc sit amet, cursus urna. Aliquam a turpis nec ligula accumsan rhoncus vitae sed turpis. In imperdiet auctor eros. Aliquam erat volutpat. Mauris scelerisque accumsan blandit. Praesent dui justo, sollicitudin ut dictum nec, consectetur eu massa. Vivamus pellentesque aliquet lacus consequat porttitor. Sed quis rutrum diam. Integer et lorem lorem. Sed volutpat purus quis massa suscipit, id rhoncus ligula faucibus. Etiam vitae leo eu neque ornare ornare sed vel dui. In hac habitasse platea dictumst. In dolor mi, auctor id tempor eget, porttitor nec diam.\r\n\r\nFusce lobortis metus quis arcu facilisis ullamcorper. Maecenas quis eros sed dui placerat scelerisque. Curabitur vulputate non enim vel scelerisque. Praesent elementum quam turpis. Duis id auctor elit, eu sollicitudin nisl. Nullam quis orci non magna mollis tincidunt vel quis enim. Sed non eleifend lectus. Sed sodales turpis sit amet leo lobortis semper. Phasellus egestas euismod lorem quis posuere. Aenean quis augue ac purus blandit semper. Curabitur sed eros dictum, condimentum mauris eu, scelerisque libero. Ut nec scelerisque risus. Nunc tincidunt enim sit amet velit faucibus, id molestie ligula iaculis.\r\n\r\nMorbi risus turpis, sagittis nec fringilla laoreet, placerat eget diam. Vivamus lacinia turpis sit amet justo pellentesque dignissim. In tempor nulla egestas sapien gravida fermentum. Donec ullamcorper, lectus a pellentesque commodo, dolor augue aliquet justo, vitae blandit sem libero et augue. Phasellus gravida vel libero vitae lacinia. Integer quis sollicitudin odio, in feugiat quam. Maecenas vel lectus nec dolor laoreet commodo in porttitor elit. Etiam erat lacus, molestie vel ligula sed, ultrices convallis arcu.', ' Contact Us', '', 'inherit', 'open', 'open', '', '17-revision-v1', '', '', '2014-02-25 13:55:02', '2014-02-25 13:55:02', '', 17, 'http://nick.bronsonrocktx.com/?p=31', 0, 'revision', '', 0),
(34, 1, '2014-02-25 13:55:03', '2014-02-25 13:55:03', '<h1> Privacy Policy\r</h1>Header Text<h1> Privacy Policy\r</h1>\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus viverra lorem id justo pellentesque accumsan. Aliquam in pretium enim, id rutrum enim. Aliquam non urna posuere, blandit nunc sit amet, cursus urna. Aliquam a turpis nec ligula accumsan rhoncus vitae sed turpis. In imperdiet auctor eros. Aliquam erat volutpat. Mauris scelerisque accumsan blandit. Praesent dui justo, sollicitudin ut dictum nec, consectetur eu massa. Vivamus pellentesque aliquet lacus consequat porttitor. Sed quis rutrum diam. Integer et lorem lorem. Sed volutpat purus quis massa suscipit, id rhoncus ligula faucibus. Etiam vitae leo eu neque ornare ornare sed vel dui. In hac habitasse platea dictumst. In dolor mi, auctor id tempor eget, porttitor nec diam.\r\n\r\nFusce lobortis metus quis arcu facilisis ullamcorper. Maecenas quis eros sed dui placerat scelerisque. Curabitur vulputate non enim vel scelerisque. Praesent elementum quam turpis. Duis id auctor elit, eu sollicitudin nisl. Nullam quis orci non magna mollis tincidunt vel quis enim. Sed non eleifend lectus. Sed sodales turpis sit amet leo lobortis semper. Phasellus egestas euismod lorem quis posuere. Aenean quis augue ac purus blandit semper. Curabitur sed eros dictum, condimentum mauris eu, scelerisque libero. Ut nec scelerisque risus. Nunc tincidunt enim sit amet velit faucibus, id molestie ligula iaculis.\r\n\r\nMorbi risus turpis, sagittis nec fringilla laoreet, placerat eget diam. Vivamus lacinia turpis sit amet justo pellentesque dignissim. In tempor nulla egestas sapien gravida fermentum. Donec ullamcorper, lectus a pellentesque commodo, dolor augue aliquet justo, vitae blandit sem libero et augue. Phasellus gravida vel libero vitae lacinia. Integer quis sollicitudin odio, in feugiat quam. Maecenas vel lectus nec dolor laoreet commodo in porttitor elit. Etiam erat lacus, molestie vel ligula sed, ultrices convallis arcu.', ' Privacy Policy', '', 'inherit', 'open', 'open', '', '20-revision-v1', '', '', '2014-02-25 13:55:03', '2014-02-25 13:55:03', '', 20, 'http://nick.bronsonrocktx.com/?p=34', 0, 'revision', '', 0),
(35, 1, '2014-02-25 13:55:03', '2014-02-25 13:55:03', '<h1> Sitemap\r</h1>Header Text<h1> Sitemap\r</h1>\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus viverra lorem id justo pellentesque accumsan. Aliquam in pretium enim, id rutrum enim. Aliquam non urna posuere, blandit nunc sit amet, cursus urna. Aliquam a turpis nec ligula accumsan rhoncus vitae sed turpis. In imperdiet auctor eros. Aliquam erat volutpat. Mauris scelerisque accumsan blandit. Praesent dui justo, sollicitudin ut dictum nec, consectetur eu massa. Vivamus pellentesque aliquet lacus consequat porttitor. Sed quis rutrum diam. Integer et lorem lorem. Sed volutpat purus quis massa suscipit, id rhoncus ligula faucibus. Etiam vitae leo eu neque ornare ornare sed vel dui. In hac habitasse platea dictumst. In dolor mi, auctor id tempor eget, porttitor nec diam.\r\n\r\nFusce lobortis metus quis arcu facilisis ullamcorper. Maecenas quis eros sed dui placerat scelerisque. Curabitur vulputate non enim vel scelerisque. Praesent elementum quam turpis. Duis id auctor elit, eu sollicitudin nisl. Nullam quis orci non magna mollis tincidunt vel quis enim. Sed non eleifend lectus. Sed sodales turpis sit amet leo lobortis semper. Phasellus egestas euismod lorem quis posuere. Aenean quis augue ac purus blandit semper. Curabitur sed eros dictum, condimentum mauris eu, scelerisque libero. Ut nec scelerisque risus. Nunc tincidunt enim sit amet velit faucibus, id molestie ligula iaculis.\r\n\r\nMorbi risus turpis, sagittis nec fringilla laoreet, placerat eget diam. Vivamus lacinia turpis sit amet justo pellentesque dignissim. In tempor nulla egestas sapien gravida fermentum. Donec ullamcorper, lectus a pellentesque commodo, dolor augue aliquet justo, vitae blandit sem libero et augue. Phasellus gravida vel libero vitae lacinia. Integer quis sollicitudin odio, in feugiat quam. Maecenas vel lectus nec dolor laoreet commodo in porttitor elit. Etiam erat lacus, molestie vel ligula sed, ultrices convallis arcu.', ' Sitemap', '', 'inherit', 'open', 'open', '', '21-revision-v1', '', '', '2014-02-25 13:55:03', '2014-02-25 13:55:03', '', 21, 'http://nick.bronsonrocktx.com/?p=35', 0, 'revision', '', 0),
(53, 1, '2014-02-25 14:00:32', '2014-02-25 14:00:32', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus viverra lorem id justo pellentesque accumsan. Aliquam in pretium enim, id rutrum enim. Aliquam non urna posuere, blandit nunc sit amet, cursus urna. Aliquam a turpis nec ligula accumsan rhoncus vitae sed turpis. In imperdiet auctor eros. Aliquam erat volutpat. Mauris scelerisque accumsan blandit. Praesent dui justo, sollicitudin ut dictum nec, consectetur eu massa. Vivamus pellentesque aliquet lacus consequat porttitor. Sed quis rutrum diam. Integer et lorem lorem. Sed volutpat purus quis massa suscipit, id rhoncus ligula faucibus. Etiam vitae leo eu neque ornare ornare sed vel dui. In hac habitasse platea dictumst. In dolor mi, auctor id tempor eget, porttitor nec diam.\r\n\r\nFusce lobortis metus quis arcu facilisis ullamcorper. Maecenas quis eros sed dui placerat scelerisque. Curabitur vulputate non enim vel scelerisque. Praesent elementum quam turpis. Duis id auctor elit, eu sollicitudin nisl. Nullam quis orci non magna mollis tincidunt vel quis enim. Sed non eleifend lectus. Sed sodales turpis sit amet leo lobortis semper. Phasellus egestas euismod lorem quis posuere. Aenean quis augue ac purus blandit semper. Curabitur sed eros dictum, condimentum mauris eu, scelerisque libero. Ut nec scelerisque risus. Nunc tincidunt enim sit amet velit faucibus, id molestie ligula iaculis.\r\n\r\nMorbi risus turpis, sagittis nec fringilla laoreet, placerat eget diam. Vivamus lacinia turpis sit amet justo pellentesque dignissim. In tempor nulla egestas sapien gravida fermentum. Donec ullamcorper, lectus a pellentesque commodo, dolor augue aliquet justo, vitae blandit sem libero et augue. Phasellus gravida vel libero vitae lacinia. Integer quis sollicitudin odio, in feugiat quam. Maecenas vel lectus nec dolor laoreet commodo in porttitor elit. Etiam erat lacus, molestie vel ligula sed, ultrices convallis arcu.\r\n\r\n&nbsp;', 'Home', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-02-25 14:00:32', '2014-02-25 14:00:32', '', 4, 'http://nick.bronsonrocktx.com/?p=53', 0, 'revision', '', 0),
(54, 1, '2014-02-25 08:42:24', '2014-02-25 14:42:24', ' ', '', '', 'publish', 'open', 'open', '', '54', '', '', '2014-02-25 08:46:30', '2014-02-25 14:46:30', '', 0, 'http://nick.bronsonrocktx.com/?p=54', 1, 'nav_menu_item', '', 0),
(58, 1, '2014-02-25 08:42:24', '2014-02-25 14:42:24', ' ', '', '', 'publish', 'open', 'open', '', '58', '', '', '2014-02-25 08:46:30', '2014-02-25 14:46:30', '', 0, 'http://nick.bronsonrocktx.com/?p=58', 3, 'nav_menu_item', '', 0),
(60, 1, '2014-02-25 08:42:24', '2014-02-25 14:42:24', ' ', '', '', 'publish', 'open', 'open', '', '60', '', '', '2014-02-25 08:46:30', '2014-02-25 14:46:30', '', 0, 'http://nick.bronsonrocktx.com/?p=60', 5, 'nav_menu_item', '', 0),
(61, 1, '2014-02-25 08:42:24', '2014-02-25 14:42:24', ' ', '', '', 'publish', 'open', 'open', '', '61', '', '', '2014-02-25 08:46:30', '2014-02-25 14:46:30', '', 0, 'http://nick.bronsonrocktx.com/?p=61', 6, 'nav_menu_item', '', 0),
(62, 1, '2014-02-25 08:42:24', '2014-02-25 14:42:24', ' ', '', '', 'publish', 'open', 'open', '', '62', '', '', '2014-02-25 08:46:30', '2014-02-25 14:46:30', '', 0, 'http://nick.bronsonrocktx.com/?p=62', 7, 'nav_menu_item', '', 0),
(63, 1, '2014-02-25 08:42:24', '2014-02-25 14:42:24', ' ', '', '', 'publish', 'open', 'open', '', '63', '', '', '2014-02-25 08:46:30', '2014-02-25 14:46:30', '', 0, 'http://nick.bronsonrocktx.com/?p=63', 8, 'nav_menu_item', '', 0),
(65, 1, '2014-02-25 08:42:24', '2014-02-25 14:42:24', ' ', '', '', 'publish', 'open', 'open', '', '65', '', '', '2014-02-25 08:46:30', '2014-02-25 14:46:30', '', 0, 'http://nick.bronsonrocktx.com/?p=65', 10, 'nav_menu_item', '', 0),
(67, 1, '2014-02-25 08:42:24', '2014-02-25 14:42:24', ' ', '', '', 'publish', 'open', 'open', '', '67', '', '', '2014-02-25 08:46:30', '2014-02-25 14:46:30', '', 0, 'http://nick.bronsonrocktx.com/?p=67', 12, 'nav_menu_item', '', 0),
(68, 1, '2014-02-25 08:42:24', '2014-02-25 14:42:24', ' ', '', '', 'publish', 'open', 'open', '', '68', '', '', '2014-02-25 08:46:30', '2014-02-25 14:46:30', '', 0, 'http://nick.bronsonrocktx.com/?p=68', 13, 'nav_menu_item', '', 0),
(69, 1, '2014-02-25 08:42:24', '2014-02-25 14:42:24', ' ', '', '', 'publish', 'open', 'open', '', '69', '', '', '2014-02-25 08:46:30', '2014-02-25 14:46:30', '', 0, 'http://nick.bronsonrocktx.com/?p=69', 14, 'nav_menu_item', '', 0),
(70, 1, '2014-03-20 12:32:05', '2014-03-20 18:32:05', '<h2>Commercial &amp; Residential Property Inspections</h2>\n<strong><em><span style="color: #f00c0c;">X</span><span style="color: #0a72b4;">stream </span><span style="color: #f00909;">Inspections </span></em></strong>is a <strong>“Woman Owned Business”</strong> that offers a comprehensive, in-depth detailed inspection that goes <strong>beyond</strong> what is required by the minimum standards required by the Texas Real Estate Commission.  <strong>Our 200 point, 50-100 digitally documented inspection</strong> gives you the comfort of knowing that your real estate purchase, sale or lease is being tested, inspected and analyzed by the best in the business.  Our Team of <strong>Licensed Specialists </strong>is available for telephone consultation during your structural and mechanical inspection and if needed an appointment can be made for a specialty inspection if discovery is needed.\n\nOur 34 years of construction/industry experience and Professionally Licensed Team of Specialists gives us the upper hand on the competition. We have performed over 6000 inspections and take pride our ability to multi-task, accompanied with our detailed skill set to ensure that your inspection needs are proficiently documented.\n\nOur <strong>duly licensed Inspectors</strong> can perform Structural and Mechanical Inspections, Wood Destroying Inspections’ (Termite/Carpenter Ants), Pool Inspections, Sprinkler System Inspections, and gas line tests.\n\nOur <strong>computer generated reports</strong> are <strong>completed on-site</strong> and are printed and emailed at the time of the inspection.  Our Inspectors take the time to verbally go over the written report and provide an on-site walk-thru to ensure that you have a complete understanding of the inspection findings.  We are available for follow-up telephone consultations at no extra cost to you.\n\nWhether you are buying your first home, listing a home, or adding to your real estate portfolio, it pays to have a professional inspect your investment.  Older homes require specialty inspections, as their sewer lines, electrical systems and/or heating and cooling systems can house costly deficiencies.\n\n<strong><em>Xstream Inspections</em></strong> has a Professional Team of Specialists available to ensure that you are completely protected when purchasing one of the largest investments of your life.', 'Home', '', 'inherit', 'open', 'open', '', '4-autosave-v1', '', '', '2014-03-20 12:32:05', '2014-03-20 18:32:05', '', 4, 'http://nick.bronsonrocktx.com/4-autosave-v1/', 0, 'revision', '', 0),
(71, 1, '2014-02-25 08:51:37', '2014-02-25 14:51:37', 'Residential &amp; Commercial\r\nServing North Texas Since 2001\r\n<h2>Shelly Morgan</h2>\r\nProfessional Real Estate Inspector #6196,\r\nCertified Pest Control Applicator #0561139,\r\nFEMA Certified Disaster Housing Inspector #15007,\r\nCommercial Specialist\r\n\r\n<strong><em><span style="color: #f00c0c; font-size: x-large;">X</span><span style="color: #0a72b4; font-size: medium;">stream </span><span style="color: #f00909; font-size: medium;">Inspections </span></em></strong><span style="color: #2a2a2a; font-size: medium;">is a “<strong>Woman Owned Business</strong>” that offers a comprehensive, in-depth detailed inspection that goes <strong>beyond</strong> what is required by the <em>minimum standards</em> required by the Texas Real Estate Commission.  <strong><em>Our 200 point, 50-100 digitally documented inspection</em></strong> gives you the comfort of knowing that your real estate purchase, sale or lease is being tested, inspected and analyzed by the best in the business.  Our <strong>Team</strong> of <strong>Licensed Specialists</strong> is available for telephone consultation during your structural and mechanical inspection and if needed an appointment can be made for a specialty inspection if discovery is needed.</span>\r\n\r\nOur 34 years of construction/industry experience and Professionally Licensed Team of Specialists gives us the upper hand on the competition. We have performed over 6000 inspections and take pride our ability to multi-task, accompanied with our detailed skill set to ensure that your inspection needs are proficiently documented.\r\n\r\nOur <strong>duly licensed Inspectors</strong> can perform Structural and Mechanical Inspections, Wood Destroying Inspections’ (Termite/Carpenter Ants), Pool Inspections, Sprinkler System Inspections, and gas line tests.\r\n\r\nOur <strong>computer generated reports</strong> are <strong>completed on-site</strong> and are printed and emailed at the time of the inspection.  <em>Our Inspectors take the time to verbally go over the written report and provide an on-site walk-thru to ensure that you have a complete understanding of the inspection findings.</em>  We are available for follow-up telephone consultations at no extra cost to you.\r\n\r\nWhether you are buying your first home, listing a home, or adding to your real estate portfolio, it pays to have a professional inspect your investment.  Older homes require specialty inspections, as their sewer lines, electrical systems and/or heating and cooling systems can house costly deficiencies.\r\n\r\n<strong><em><span style="color: #f30a0a; font-size: x-large;">X</span><span style="color: #14668b;">stream</span><span style="font-size: medium;"> </span><span style="color: #ee0d0d;">Inspections </span></em></strong><span style="color: #2a2a2a; font-size: medium;">has a Professional Team of Specialists available to ensure that you are completely protected when purchasing one of the largest investments of your life.</span>', 'Home', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-02-25 08:51:37', '2014-02-25 14:51:37', '', 4, 'http://nick.bronsonrocktx.com/4-revision-v1/', 0, 'revision', '', 0),
(72, 1, '2014-02-25 08:54:56', '2014-02-25 14:54:56', 'Residential &amp; Commercial\r\nServing North Texas Since 2001\r\n<h2>Shelly Morgan</h2>\r\nProfessional Real Estate Inspector #6196,\r\nCertified Pest Control Applicator #0561139,\r\nFEMA Certified Disaster Housing Inspector #15007,\r\nCommercial Specialist\r\n\r\n<strong><em><span style="color: #f00c0c; font-size: x-large;">X</span><span style="color: #0a72b4; font-size: medium;">stream </span><span style="color: #f00909; font-size: medium;">Inspections </span></em></strong>is a <strong>“Woman Owned Business”</strong> that offers a comprehensive, in-depth detailed inspection that goes <strong>beyond</strong> what is required by the minimum standards required by the Texas Real Estate Commission.  <strong>Our 200 point, 50-100 digitally documented inspection</strong> gives you the comfort of knowing that your real estate purchase, sale or lease is being tested, inspected and analyzed by the best in the business.  Our Team of <strong>Licensed Specialists </strong>is available for telephone consultation during your structural and mechanical inspection and if needed an appointment can be made for a specialty inspection if discovery is needed.\r\n\r\nOur 34 years of construction/industry experience and Professionally Licensed Team of Specialists gives us the upper hand on the competition. We have performed over 6000 inspections and take pride our ability to multi-task, accompanied with our detailed skill set to ensure that your inspection needs are proficiently documented.\r\n\r\nOur <strong>duly licensed Inspectors</strong> can perform Structural and Mechanical Inspections, Wood Destroying Inspections’ (Termite/Carpenter Ants), Pool Inspections, Sprinkler System Inspections, and gas line tests.\r\n\r\nOur <strong>computer generated reports</strong> are <strong>completed on-site</strong> and are printed and emailed at the time of the inspection.  Our Inspectors take the time to verbally go over the written report and provide an on-site walk-thru to ensure that you have a complete understanding of the inspection findings.  We are available for follow-up telephone consultations at no extra cost to you.\r\n\r\nWhether you are buying your first home, listing a home, or adding to your real estate portfolio, it pays to have a professional inspect your investment.  Older homes require specialty inspections, as their sewer lines, electrical systems and/or heating and cooling systems can house costly deficiencies.\r\n\r\n<strong><em><span style="color: #f30a0a; font-size: x-large;">X</span><span style="color: #14668b;">stream</span><span style="font-size: medium;"> </span><span style="color: #ee0d0d;">Inspections </span></em></strong>has a Professional Team of Specialists available to ensure that you are completely protected when purchasing one of the largest investments of your life.', 'Home', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-02-25 08:54:56', '2014-02-25 14:54:56', '', 4, 'http://nick.bronsonrocktx.com/4-revision-v1/', 0, 'revision', '', 0),
(73, 1, '2014-02-25 08:57:17', '2014-02-25 14:57:17', '<strong><em><span style="color: #f00c0c;">X</span><span style="color: #0a72b4;">stream </span><span style="color: #f00909; font-size: medium;">Inspections </span></em></strong>is a <strong>“Woman Owned Business”</strong> that offers a comprehensive, in-depth detailed inspection that goes <strong>beyond</strong> what is required by the minimum standards required by the Texas Real Estate Commission.  <strong>Our 200 point, 50-100 digitally documented inspection</strong> gives you the comfort of knowing that your real estate purchase, sale or lease is being tested, inspected and analyzed by the best in the business.  Our Team of <strong>Licensed Specialists </strong>is available for telephone consultation during your structural and mechanical inspection and if needed an appointment can be made for a specialty inspection if discovery is needed.\r\n\r\nOur 34 years of construction/industry experience and Professionally Licensed Team of Specialists gives us the upper hand on the competition. We have performed over 6000 inspections and take pride our ability to multi-task, accompanied with our detailed skill set to ensure that your inspection needs are proficiently documented.\r\n\r\nOur <strong>duly licensed Inspectors</strong> can perform Structural and Mechanical Inspections, Wood Destroying Inspections’ (Termite/Carpenter Ants), Pool Inspections, Sprinkler System Inspections, and gas line tests.\r\n\r\nOur <strong>computer generated reports</strong> are <strong>completed on-site</strong> and are printed and emailed at the time of the inspection.  Our Inspectors take the time to verbally go over the written report and provide an on-site walk-thru to ensure that you have a complete understanding of the inspection findings.  We are available for follow-up telephone consultations at no extra cost to you.\r\n\r\nWhether you are buying your first home, listing a home, or adding to your real estate portfolio, it pays to have a professional inspect your investment.  Older homes require specialty inspections, as their sewer lines, electrical systems and/or heating and cooling systems can house costly deficiencies.\r\n\r\n<strong><em><span style="color: #f30a0a;">X</span><span style="color: #14668b;">stream</span><span style="color: #ee0d0d;">Inspections </span></em></strong>has a Professional Team of Specialists available to ensure that you are completely protected when purchasing one of the largest investments of your life.', 'Home', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-02-25 08:57:17', '2014-02-25 14:57:17', '', 4, 'http://nick.bronsonrocktx.com/4-revision-v1/', 0, 'revision', '', 0),
(74, 1, '2014-02-25 08:58:01', '2014-02-25 14:58:01', '<strong><em><span style="color: #f00c0c;">X</span><span style="color: #0a72b4;">stream </span><span style="color: #f00909;">Inspections </span></em></strong>is a <strong>“Woman Owned Business”</strong> that offers a comprehensive, in-depth detailed inspection that goes <strong>beyond</strong> what is required by the minimum standards required by the Texas Real Estate Commission.  <strong>Our 200 point, 50-100 digitally documented inspection</strong> gives you the comfort of knowing that your real estate purchase, sale or lease is being tested, inspected and analyzed by the best in the business.  Our Team of <strong>Licensed Specialists </strong>is available for telephone consultation during your structural and mechanical inspection and if needed an appointment can be made for a specialty inspection if discovery is needed.\r\n\r\nOur 34 years of construction/industry experience and Professionally Licensed Team of Specialists gives us the upper hand on the competition. We have performed over 6000 inspections and take pride our ability to multi-task, accompanied with our detailed skill set to ensure that your inspection needs are proficiently documented.\r\n\r\nOur <strong>duly licensed Inspectors</strong> can perform Structural and Mechanical Inspections, Wood Destroying Inspections’ (Termite/Carpenter Ants), Pool Inspections, Sprinkler System Inspections, and gas line tests.\r\n\r\nOur <strong>computer generated reports</strong> are <strong>completed on-site</strong> and are printed and emailed at the time of the inspection.  Our Inspectors take the time to verbally go over the written report and provide an on-site walk-thru to ensure that you have a complete understanding of the inspection findings.  We are available for follow-up telephone consultations at no extra cost to you.\r\n\r\nWhether you are buying your first home, listing a home, or adding to your real estate portfolio, it pays to have a professional inspect your investment.  Older homes require specialty inspections, as their sewer lines, electrical systems and/or heating and cooling systems can house costly deficiencies.\r\n\r\n<strong><em><span style="color: #f30a0a;">X</span><span style="color: #14668b;">stream</span><span style="color: #ee0d0d;"> Inspections</span></em></strong>has a Professional Team of Specialists available to ensure that you are completely protected when purchasing one of the largest investments of your life.', 'Home', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-02-25 08:58:01', '2014-02-25 14:58:01', '', 4, 'http://nick.bronsonrocktx.com/4-revision-v1/', 0, 'revision', '', 0),
(75, 1, '2014-02-25 08:58:19', '2014-02-25 14:58:19', '<strong><em><span style="color: #f00c0c;">X</span><span style="color: #0a72b4;">stream </span><span style="color: #f00909;">Inspections </span></em></strong>is a <strong>“Woman Owned Business”</strong> that offers a comprehensive, in-depth detailed inspection that goes <strong>beyond</strong> what is required by the minimum standards required by the Texas Real Estate Commission.  <strong>Our 200 point, 50-100 digitally documented inspection</strong> gives you the comfort of knowing that your real estate purchase, sale or lease is being tested, inspected and analyzed by the best in the business.  Our Team of <strong>Licensed Specialists </strong>is available for telephone consultation during your structural and mechanical inspection and if needed an appointment can be made for a specialty inspection if discovery is needed.\r\n\r\nOur 34 years of construction/industry experience and Professionally Licensed Team of Specialists gives us the upper hand on the competition. We have performed over 6000 inspections and take pride our ability to multi-task, accompanied with our detailed skill set to ensure that your inspection needs are proficiently documented.\r\n\r\nOur <strong>duly licensed Inspectors</strong> can perform Structural and Mechanical Inspections, Wood Destroying Inspections’ (Termite/Carpenter Ants), Pool Inspections, Sprinkler System Inspections, and gas line tests.\r\n\r\nOur <strong>computer generated reports</strong> are <strong>completed on-site</strong> and are printed and emailed at the time of the inspection.  Our Inspectors take the time to verbally go over the written report and provide an on-site walk-thru to ensure that you have a complete understanding of the inspection findings.  We are available for follow-up telephone consultations at no extra cost to you.\r\n\r\nWhether you are buying your first home, listing a home, or adding to your real estate portfolio, it pays to have a professional inspect your investment.  Older homes require specialty inspections, as their sewer lines, electrical systems and/or heating and cooling systems can house costly deficiencies.\r\n\r\n<strong><em><span style="color: #f30a0a;">X</span><span style="color: #14668b;">stream</span><span style="color: #ee0d0d;"> Inspections</span></em></strong> has a Professional Team of Specialists available to ensure that you are completely protected when purchasing one of the largest investments of your life.', 'Home', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-02-25 08:58:19', '2014-02-25 14:58:19', '', 4, 'http://nick.bronsonrocktx.com/4-revision-v1/', 0, 'revision', '', 0),
(102, 1, '2014-02-25 12:50:32', '2014-02-25 18:50:32', '[gravityform id="1" name="Contact Us" ajax="true"]', ' Contact Us', '', 'inherit', 'open', 'open', '', '17-revision-v1', '', '', '2014-02-25 12:50:32', '2014-02-25 18:50:32', '', 17, 'http://nick.bronsonrocktx.com/17-revision-v1/', 0, 'revision', '', 0),
(105, 1, '2014-02-25 12:54:33', '2014-02-25 18:54:33', '<h3>What information do we collect?</h3>\n<div>\n\nWe collect information from you when you register on our site, place an order, subscribe to our newsletter, respond to a survey, fill out a form or send band information.\n\nWhen ordering or registering on our site, as appropriate, you may be asked to enter your: name, e-mail address, mailing address or phone number. You may, however, visit our site anonymously.\n<h3>What do we use your information for?</h3>\nAny of the information we collect from you may be used in one of the following ways:\n\n; To personalize your experience\n(your information helps us to better respond to your individual needs)\n\n; To improve our website\n(we continually strive to improve our website offerings based on the information and feedback we receive from you)\n\n; To improve customer service\n(your information helps us to more effectively respond to your customer service requests and support needs)\n\n; To administer a contest, promotion, survey or other site feature\n\n; To send periodic emails\n<blockquote>The email address you provide for order processing, may be used to send you information and updates pertaining to your order, in addition to receiving occasional company news, updates, related product or service information, etc.</blockquote>\nNote: If at any time you would like to unsubscribe from receiving future emails, we include detailed unsubscribe instructions at the bottom of each email.\n<h3>How do we protect your information?</h3>\nWe implement a variety of security measures to maintain the safety of your personal information when you place an order or enter, submit, or access your personal information.\n\nWe offer the use of a secure server. All supplied sensitive/credit information is transmitted via Secure Socket Layer (SSL) technology and then encrypted into our Payment gateway providers database only to be accessible by those authorized with special access rights to such systems, and are required to?keep the information confidential.\n\nAfter a transaction, your private information (credit cards, social security numbers, financials, etc.) will not be stored on our servers.\n<h3>Do we use cookies?</h3>\nYes (Cookies are small files that a site or its service provider transfers to your computers hard drive through your Web browser (if you allow) that enables the sites or service providers systems to recognize your browser and capture and remember certain information\n\nWe use cookies to understand and save your preferences for future visits, keep track of advertisements and compile aggregate data about site traffic and site interaction so that we can offer better site experiences and tools in the future. We may contract with third-party service providers to assist us in better understanding our site visitors. These service providers are not permitted to use the information collected on our behalf except to help us conduct and improve our business.\n\nIf you prefer, you can choose to have your computer warn you each time a cookie is being sent, or you can choose to turn off all cookies via your browser settings. Like most websites, if you turn your cookies off, some of our services may not function properly. However, you can still place orders over the telephone or by contacting customer service.\n<h3>Do we disclose any information to outside parties?</h3>\nWe do not sell, trade, or otherwise transfer to outside parties your personally identifiable information. This does not include trusted third parties who assist us in operating our website, conducting our business, or servicing you, so long as those parties agree to keep this information confidential. We may also release your information when we believe release is appropriate to comply with the law, enforce our site policies, or protect ours or others rights, property, or safety. However, non-personally identifiable visitor information may be provided to other parties for marketing, advertising, or other uses.\n<h3>Third party links</h3>\nOccasionally, at our discretion, we may include or offer third party products or services on our website. These third party sites have separate and independent privacy policies. We therefore have no responsibility or liability for the content and activities of these linked sites. Nonetheless, we seek to protect the integrity of our site and welcome any feedback about these sites.\n<h3>California Online Privacy Protection Act Compliance</h3>\nBecause we value your privacy we have taken the necessary precautions to be in compliance with the California Online Privacy Protection Act. We therefore will not distribute your personal information to outside parties without your consent.\n<h3>Childrens Online Privacy Protection Act Compliance</h3>\nWe are in compliance with the requirements of COPPA (Childrens Online Privacy Protection Act), we do not collect any information from anyone under 13 years of age. Our website, products and services are all directed to people who are at least 13 years old or older.\n<h3>Online Privacy Policy Only</h3>\nThis online privacy policy applies only to information collected through our website and not to information collected offline.\n<h3>Your Consent</h3>\nBy using our site, you consent to our web site privacy policy.\n<h3>Changes to our Privacy Policy</h3>\nIf we decide to change our privacy policy, we will post those changes on this page, and/or update the Privacy Policy modification date below.\n\nThis policy was last modified on 2/25/2013\n<h3>Contacting Us</h3>\nIf there are any questions regarding this privacy policy you may contact us using the information below.\n\nhttp://vicfuel.com\n\nVicNRG\n1670 Keller Pkwy.\nSuites 246 &amp; 247\nKeller , TX 76248\ntel. 817-431-9894\n<a>admin@vicfuel.com</a>\n\n</div>', ' Privacy Policy', '', 'inherit', 'open', 'open', '', '20-autosave-v1', '', '', '2014-02-25 12:54:33', '2014-02-25 18:54:33', '', 20, 'http://nick.bronsonrocktx.com/20-autosave-v1/', 0, 'revision', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(106, 1, '2014-02-25 12:55:16', '2014-02-25 18:55:16', '<h3>What information do we collect?</h3>\r\n<div>\r\n\r\nWe collect information from you when you register on our site, place an order, subscribe to our newsletter, respond to a survey, fill out a form or send band information.\r\n\r\nWhen ordering or registering on our site, as appropriate, you may be asked to enter your: name, e-mail address, mailing address or phone number. You may, however, visit our site anonymously.\r\n<h3>What do we use your information for?</h3>\r\nAny of the information we collect from you may be used in one of the following ways:\r\n\r\n; To personalize your experience\r\n(your information helps us to better respond to your individual needs)\r\n\r\n; To improve our website\r\n(we continually strive to improve our website offerings based on the information and feedback we receive from you)\r\n\r\n; To improve customer service\r\n(your information helps us to more effectively respond to your customer service requests and support needs)\r\n\r\n; To administer a contest, promotion, survey or other site feature\r\n\r\n; To send periodic emails\r\n<blockquote>The email address you provide for order processing, may be used to send you information and updates pertaining to your order, in addition to receiving occasional company news, updates, related product or service information, etc.</blockquote>\r\nNote: If at any time you would like to unsubscribe from receiving future emails, we include detailed unsubscribe instructions at the bottom of each email.\r\n<h3>How do we protect your information?</h3>\r\nWe implement a variety of security measures to maintain the safety of your personal information when you place an order or enter, submit, or access your personal information.\r\n\r\nWe offer the use of a secure server. All supplied sensitive/credit information is transmitted via Secure Socket Layer (SSL) technology and then encrypted into our Payment gateway providers database only to be accessible by those authorized with special access rights to such systems, and are required to?keep the information confidential.\r\n\r\nAfter a transaction, your private information (credit cards, social security numbers, financials, etc.) will not be stored on our servers.\r\n<h3>Do we use cookies?</h3>\r\nYes (Cookies are small files that a site or its service provider transfers to your computers hard drive through your Web browser (if you allow) that enables the sites or service providers systems to recognize your browser and capture and remember certain information\r\n\r\nWe use cookies to understand and save your preferences for future visits, keep track of advertisements and compile aggregate data about site traffic and site interaction so that we can offer better site experiences and tools in the future. We may contract with third-party service providers to assist us in better understanding our site visitors. These service providers are not permitted to use the information collected on our behalf except to help us conduct and improve our business.\r\n\r\nIf you prefer, you can choose to have your computer warn you each time a cookie is being sent, or you can choose to turn off all cookies via your browser settings. Like most websites, if you turn your cookies off, some of our services may not function properly. However, you can still place orders over the telephone or by contacting customer service.\r\n<h3>Do we disclose any information to outside parties?</h3>\r\nWe do not sell, trade, or otherwise transfer to outside parties your personally identifiable information. This does not include trusted third parties who assist us in operating our website, conducting our business, or servicing you, so long as those parties agree to keep this information confidential. We may also release your information when we believe release is appropriate to comply with the law, enforce our site policies, or protect ours or others rights, property, or safety. However, non-personally identifiable visitor information may be provided to other parties for marketing, advertising, or other uses.\r\n<h3>Third party links</h3>\r\nOccasionally, at our discretion, we may include or offer third party products or services on our website. These third party sites have separate and independent privacy policies. We therefore have no responsibility or liability for the content and activities of these linked sites. Nonetheless, we seek to protect the integrity of our site and welcome any feedback about these sites.\r\n<h3>California Online Privacy Protection Act Compliance</h3>\r\nBecause we value your privacy we have taken the necessary precautions to be in compliance with the California Online Privacy Protection Act. We therefore will not distribute your personal information to outside parties without your consent.\r\n<h3>Childrens Online Privacy Protection Act Compliance</h3>\r\nWe are in compliance with the requirements of COPPA (Childrens Online Privacy Protection Act), we do not collect any information from anyone under 13 years of age. Our website, products and services are all directed to people who are at least 13 years old or older.\r\n<h3>Online Privacy Policy Only</h3>\r\nThis online privacy policy applies only to information collected through our website and not to information collected offline.\r\n<h3>Your Consent</h3>\r\nBy using our site, you consent to our web site privacy policy.\r\n<h3>Changes to our Privacy Policy</h3>\r\nIf we decide to change our privacy policy, we will post those changes on this page, and/or update the Privacy Policy modification date below.\r\n\r\nThis policy was last modified on 2/25/2014\r\n<h3>Contacting Us</h3>\r\nIf there are any questions regarding this privacy policy you may contact us using the information below.\r\n\r\nhttp://nick.bronsonrocktx.com\r\n\r\nXstream Inspections\r\nshelly@dev.bronsonrocktx.com\r\n\r\n</div>', ' Privacy Policy', '', 'inherit', 'open', 'open', '', '20-revision-v1', '', '', '2014-02-25 12:55:16', '2014-02-25 18:55:16', '', 20, 'http://nick.bronsonrocktx.com/20-revision-v1/', 0, 'revision', '', 0),
(107, 1, '2014-02-25 12:55:26', '2014-02-25 18:55:26', '<h3>What information do we collect?</h3>\r\n<div>\r\n\r\nWe collect information from you when you register on our site, place an order, subscribe to our newsletter, respond to a survey, fill out a form or send band information.\r\n\r\nWhen ordering or registering on our site, as appropriate, you may be asked to enter your: name, e-mail address, mailing address or phone number. You may, however, visit our site anonymously.\r\n<h3>What do we use your information for?</h3>\r\nAny of the information we collect from you may be used in one of the following ways:\r\n\r\n; To personalize your experience\r\n(your information helps us to better respond to your individual needs)\r\n\r\n; To improve our website\r\n(we continually strive to improve our website offerings based on the information and feedback we receive from you)\r\n\r\n; To improve customer service\r\n(your information helps us to more effectively respond to your customer service requests and support needs)\r\n\r\n; To administer a contest, promotion, survey or other site feature\r\n\r\n; To send periodic emails\r\n<blockquote>The email address you provide for order processing, may be used to send you information and updates pertaining to your order, in addition to receiving occasional company news, updates, related product or service information, etc.</blockquote>\r\nNote: If at any time you would like to unsubscribe from receiving future emails, we include detailed unsubscribe instructions at the bottom of each email.\r\n<h3>How do we protect your information?</h3>\r\nWe implement a variety of security measures to maintain the safety of your personal information when you place an order or enter, submit, or access your personal information.\r\n\r\nWe offer the use of a secure server. All supplied sensitive/credit information is transmitted via Secure Socket Layer (SSL) technology and then encrypted into our Payment gateway providers database only to be accessible by those authorized with special access rights to such systems, and are required to?keep the information confidential.\r\n\r\nAfter a transaction, your private information (credit cards, social security numbers, financials, etc.) will not be stored on our servers.\r\n<h3>Do we use cookies?</h3>\r\nYes (Cookies are small files that a site or its service provider transfers to your computers hard drive through your Web browser (if you allow) that enables the sites or service providers systems to recognize your browser and capture and remember certain information\r\n\r\nWe use cookies to understand and save your preferences for future visits, keep track of advertisements and compile aggregate data about site traffic and site interaction so that we can offer better site experiences and tools in the future. We may contract with third-party service providers to assist us in better understanding our site visitors. These service providers are not permitted to use the information collected on our behalf except to help us conduct and improve our business.\r\n\r\nIf you prefer, you can choose to have your computer warn you each time a cookie is being sent, or you can choose to turn off all cookies via your browser settings. Like most websites, if you turn your cookies off, some of our services may not function properly. However, you can still place orders over the telephone or by contacting customer service.\r\n<h3>Do we disclose any information to outside parties?</h3>\r\nWe do not sell, trade, or otherwise transfer to outside parties your personally identifiable information. This does not include trusted third parties who assist us in operating our website, conducting our business, or servicing you, so long as those parties agree to keep this information confidential. We may also release your information when we believe release is appropriate to comply with the law, enforce our site policies, or protect ours or others rights, property, or safety. However, non-personally identifiable visitor information may be provided to other parties for marketing, advertising, or other uses.\r\n<h3>Third party links</h3>\r\nOccasionally, at our discretion, we may include or offer third party products or services on our website. These third party sites have separate and independent privacy policies. We therefore have no responsibility or liability for the content and activities of these linked sites. Nonetheless, we seek to protect the integrity of our site and welcome any feedback about these sites.\r\n<h3>California Online Privacy Protection Act Compliance</h3>\r\nBecause we value your privacy we have taken the necessary precautions to be in compliance with the California Online Privacy Protection Act. We therefore will not distribute your personal information to outside parties without your consent.\r\n<h3>Childrens Online Privacy Protection Act Compliance</h3>\r\nWe are in compliance with the requirements of COPPA (Childrens Online Privacy Protection Act), we do not collect any information from anyone under 13 years of age. Our website, products and services are all directed to people who are at least 13 years old or older.\r\n<h3>Online Privacy Policy Only</h3>\r\nThis online privacy policy applies only to information collected through our website and not to information collected offline.\r\n<h3>Your Consent</h3>\r\nBy using our site, you consent to our web site privacy policy.\r\n<h3>Changes to our Privacy Policy</h3>\r\nIf we decide to change our privacy policy, we will post those changes on this page, and/or update the Privacy Policy modification date below.\r\n\r\nThis policy was last modified on 2/25/2014\r\n<h3>Contacting Us</h3>\r\nIf there are any questions regarding this privacy policy you may contact us using the information below.\r\n\r\nhttp://nick.bronsonrocktx.com\r\n\r\nXstream Inspections\r\nshelly@dev.bronsonrocktx.com\r\n\r\n</div>', ' Privacy Policy', '', 'inherit', 'open', 'open', '', '20-revision-v1', '', '', '2014-02-25 12:55:26', '2014-02-25 18:55:26', '', 20, 'http://nick.bronsonrocktx.com/20-revision-v1/', 0, 'revision', '', 0),
(108, 1, '2014-02-25 16:50:32', '2014-02-25 22:50:32', '<strong><em><span style="color: #f00c0c;">X</span><span style="color: #0a72b4;">stream </span><span style="color: #f00909;">Inspections </span></em></strong>is a <strong>“Woman Owned Business”</strong> that offers a comprehensive, in-depth detailed inspection that goes <strong>beyond</strong> what is required by the minimum standards required by the Texas Real Estate Commission.  <strong>Our 200 point, 50-100 digitally documented inspection</strong> gives you the comfort of knowing that your real estate purchase, sale or lease is being tested, inspected and analyzed by the best in the business.  Our Team of <strong>Licensed Specialists </strong>is available for telephone consultation during your structural and mechanical inspection and if needed an appointment can be made for a specialty inspection if discovery is needed.\r\n\r\n<i class="fa fa-bolt"></i> \r\n\r\nOur 34 years of construction/industry experience and Professionally Licensed Team of Specialists gives us the upper hand on the competition. We have performed over 6000 inspections and take pride our ability to multi-task, accompanied with our detailed skill set to ensure that your inspection needs are proficiently documented.\r\n\r\nOur <strong>duly licensed Inspectors</strong> can perform Structural and Mechanical Inspections, Wood Destroying Inspections’ (Termite/Carpenter Ants), Pool Inspections, Sprinkler System Inspections, and gas line tests.\r\n\r\nOur <strong>computer generated reports</strong> are <strong>completed on-site</strong> and are printed and emailed at the time of the inspection.  Our Inspectors take the time to verbally go over the written report and provide an on-site walk-thru to ensure that you have a complete understanding of the inspection findings.  We are available for follow-up telephone consultations at no extra cost to you.\r\n\r\nWhether you are buying your first home, listing a home, or adding to your real estate portfolio, it pays to have a professional inspect your investment.  Older homes require specialty inspections, as their sewer lines, electrical systems and/or heating and cooling systems can house costly deficiencies.\r\n\r\n<strong><em><span style="color: #f30a0a;">X</span><span style="color: #14668b;">stream</span><span style="color: #ee0d0d;"> Inspections</span></em></strong> has a Professional Team of Specialists available to ensure that you are completely protected when purchasing one of the largest investments of your life.', 'Home', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-02-25 16:50:32', '2014-02-25 22:50:32', '', 4, 'http://nick.bronsonrocktx.com/4-revision-v1/', 0, 'revision', '', 0),
(109, 1, '2014-02-26 22:48:42', '2014-02-27 04:48:42', '<strong><em><span style="color: #f00c0c;">X</span><span style="color: #0a72b4;">stream </span><span style="color: #f00909;">Inspections </span></em></strong>is a <strong>“Woman Owned Business”</strong> that offers a comprehensive, in-depth detailed inspection that goes <strong>beyond</strong> what is required by the minimum standards required by the Texas Real Estate Commission.  <strong>Our 200 point, 50-100 digitally documented inspection</strong> gives you the comfort of knowing that your real estate purchase, sale or lease is being tested, inspected and analyzed by the best in the business.  Our Team of <strong>Licensed Specialists </strong>is available for telephone consultation during your structural and mechanical inspection and if needed an appointment can be made for a specialty inspection if discovery is needed.\r\n\r\n&nbsp;\r\n\r\nOur 34 years of construction/industry experience and Professionally Licensed Team of Specialists gives us the upper hand on the competition. We have performed over 6000 inspections and take pride our ability to multi-task, accompanied with our detailed skill set to ensure that your inspection needs are proficiently documented.\r\n\r\nOur <strong>duly licensed Inspectors</strong> can perform Structural and Mechanical Inspections, Wood Destroying Inspections’ (Termite/Carpenter Ants), Pool Inspections, Sprinkler System Inspections, and gas line tests.\r\n\r\nOur <strong>computer generated reports</strong> are <strong>completed on-site</strong> and are printed and emailed at the time of the inspection.  Our Inspectors take the time to verbally go over the written report and provide an on-site walk-thru to ensure that you have a complete understanding of the inspection findings.  We are available for follow-up telephone consultations at no extra cost to you.\r\n\r\nWhether you are buying your first home, listing a home, or adding to your real estate portfolio, it pays to have a professional inspect your investment.  Older homes require specialty inspections, as their sewer lines, electrical systems and/or heating and cooling systems can house costly deficiencies.\r\n\r\n<strong><em><span style="color: #f30a0a;">X</span><span style="color: #14668b;">stream</span><span style="color: #ee0d0d;"> Inspections</span></em></strong> has a Professional Team of Specialists available to ensure that you are completely protected when purchasing one of the largest investments of your life.', 'Home', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-02-26 22:48:42', '2014-02-27 04:48:42', '', 4, 'http://nick.bronsonrocktx.com/4-revision-v1/', 0, 'revision', '', 0),
(112, 1, '2014-02-27 17:03:39', '2014-02-27 23:03:39', ' ', '', '', 'publish', 'open', 'open', '', '112', '', '', '2014-03-24 20:50:56', '2014-03-25 02:50:56', '', 0, 'http://nick.bronsonrocktx.com/?p=112', 1, 'nav_menu_item', '', 0),
(118, 1, '2014-02-27 17:03:39', '2014-02-27 23:03:39', ' ', '', '', 'publish', 'open', 'open', '', '118', '', '', '2014-03-24 20:50:56', '2014-03-25 02:50:56', '', 0, 'http://nick.bronsonrocktx.com/?p=118', 4, 'nav_menu_item', '', 0),
(119, 1, '2014-02-27 17:03:39', '2014-02-27 23:03:39', ' ', '', '', 'publish', 'open', 'open', '', '119', '', '', '2014-03-24 20:50:56', '2014-03-25 02:50:56', '', 0, 'http://nick.bronsonrocktx.com/?p=119', 5, 'nav_menu_item', '', 0),
(120, 1, '2014-02-27 17:03:39', '2014-02-27 23:03:39', ' ', '', '', 'publish', 'open', 'open', '', '120', '', '', '2014-03-24 20:50:56', '2014-03-25 02:50:56', '', 0, 'http://nick.bronsonrocktx.com/?p=120', 6, 'nav_menu_item', '', 0),
(139, 1, '2014-02-27 17:04:48', '2014-02-27 23:04:48', ' ', '', '', 'publish', 'open', 'open', '', '139', '', '', '2014-03-24 20:51:09', '2014-03-25 02:51:09', '', 0, 'http://nick.bronsonrocktx.com/?p=139', 4, 'nav_menu_item', '', 0),
(141, 1, '2014-02-27 17:04:48', '2014-02-27 23:04:48', ' ', '', '', 'publish', 'open', 'open', '', '141', '', '', '2014-03-24 20:51:09', '2014-03-25 02:51:09', '', 0, 'http://nick.bronsonrocktx.com/?p=141', 6, 'nav_menu_item', '', 0),
(144, 1, '2014-02-27 17:05:43', '2014-02-27 23:05:43', ' ', '', '', 'publish', 'open', 'open', '', '144', '', '', '2014-03-03 00:50:07', '2014-03-03 06:50:07', '', 0, 'http://nick.bronsonrocktx.com/?p=144', 1, 'nav_menu_item', '', 0),
(145, 1, '2014-02-27 17:05:43', '2014-02-27 23:05:43', ' ', '', '', 'publish', 'open', 'open', '', '145', '', '', '2014-03-03 00:50:07', '2014-03-03 06:50:07', '', 0, 'http://nick.bronsonrocktx.com/?p=145', 2, 'nav_menu_item', '', 0),
(146, 1, '2014-02-28 14:53:22', '2014-02-28 20:53:22', '<h1>Header 1</h1>\r\n<h2>Header 2</h2>\r\n<h3>Header 3</h3>\r\n<h4>Header 4</h4>\r\n<h5>Header 5</h5>\r\n<h6>Header 6</h6>\r\n<blockquote>"This is a quote. Our 34 years of construction/industry experience and Professionally Licensed Team of Specialists gives us the upper hand on the competition."</blockquote>\r\n<ul>\r\n	<li>List Item</li>\r\n	<li>List Item</li>\r\n	<li>List Item</li>\r\n	<li>List Item</li>\r\n	<li>List Item</li>\r\n</ul>\r\n<ol>\r\n	<li>List Item</li>\r\n	<li>List Item</li>\r\n	<li>List Item</li>\r\n	<li>List Item</li>\r\n	<li>List Item</li>\r\n</ol>\r\n<strong><em><span style="color: #f00c0c;">X</span><span style="color: #0a72b4;">stream </span><span style="color: #f00909;">Inspections </span></em></strong>is a <strong>“Woman Owned Business”</strong> that offers a comprehensive, in-depth detailed inspection that goes <strong>beyond</strong> what is required by the minimum standards required by the Texas Real Estate Commission.  <strong>Our 200 point, 50-100 digitally documented inspection</strong> gives you the comfort of knowing that your real estate purchase, sale or lease is being tested, inspected and analyzed by the best in the business.  Our Team of <strong>Licensed Specialists </strong>is available for telephone consultation during your structural and mechanical inspection and if needed an appointment can be made for a specialty inspection if discovery is needed.\r\n\r\n&nbsp;\r\n\r\nOur 34 years of construction/industry experience and Professionally Licensed Team of Specialists gives us the upper hand on the competition. We have performed over 6000 inspections and take pride our ability to multi-task, accompanied with our detailed skill set to ensure that your inspection needs are proficiently documented.\r\n\r\nOur <strong>duly licensed Inspectors</strong> can perform Structural and Mechanical Inspections, Wood Destroying Inspections’ (Termite/Carpenter Ants), Pool Inspections, Sprinkler System Inspections, and gas line tests.\r\n\r\nOur <strong>computer generated reports</strong> are <strong>completed on-site</strong> and are printed and emailed at the time of the inspection.  Our Inspectors take the time to verbally go over the written report and provide an on-site walk-thru to ensure that you have a complete understanding of the inspection findings.  We are available for follow-up telephone consultations at no extra cost to you.\r\n\r\nWhether you are buying your first home, listing a home, or adding to your real estate portfolio, it pays to have a professional inspect your investment.  Older homes require specialty inspections, as their sewer lines, electrical systems and/or heating and cooling systems can house costly deficiencies.\r\n\r\n<strong><em><span style="color: #f30a0a;">X</span><span style="color: #14668b;">stream</span><span style="color: #ee0d0d;"> Inspections</span></em></strong> has a Professional Team of Specialists available to ensure that you are completely protected when purchasing one of the largest investments of your life.', 'Home', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-02-28 14:53:22', '2014-02-28 20:53:22', '', 4, 'http://nick.bronsonrocktx.com/4-revision-v1/', 0, 'revision', '', 0),
(147, 1, '2014-02-28 16:42:35', '2014-02-28 22:42:35', '<h1>Header 1</h1>\r\n<h2>Header 2</h2>\r\n<h3>Header 3</h3>\r\n<h4>Header 4</h4>\r\n<h5>Header 5</h5>\r\n<h6>Header 6</h6>\r\n\r\n<a class="btn btn-primary btn-xs" href="#">Button</a>\r\n<a class="btn btn-primary btn-sm" href="#">Button</a>\r\n<a class="btn btn-primary" href="#">Button</a>\r\n<a class="btn btn-primary btn-lg" href="#">Button</a>\r\n\r\n<blockquote>"This is a quote. Our 34 years of construction/industry experience and Professionally Licensed Team of Specialists gives us the upper hand on the competition."</blockquote>\r\n<ul>\r\n	<li>List Item</li>\r\n	<li>List Item</li>\r\n	<li>List Item</li>\r\n	<li>List Item</li>\r\n	<li>List Item</li>\r\n</ul>\r\n<ol>\r\n	<li>List Item</li>\r\n	<li>List Item</li>\r\n	<li>List Item</li>\r\n	<li>List Item</li>\r\n	<li>List Item</li>\r\n</ol>\r\n<strong><em><span style="color: #f00c0c;">X</span><span style="color: #0a72b4;">stream </span><span style="color: #f00909;">Inspections </span></em></strong>is a <strong>“Woman Owned Business”</strong> that offers a comprehensive, in-depth detailed inspection that goes <strong>beyond</strong> what is required by the minimum standards required by the Texas Real Estate Commission.  <strong>Our 200 point, 50-100 digitally documented inspection</strong> gives you the comfort of knowing that your real estate purchase, sale or lease is being tested, inspected and analyzed by the best in the business.  Our Team of <strong>Licensed Specialists </strong>is available for telephone consultation during your structural and mechanical inspection and if needed an appointment can be made for a specialty inspection if discovery is needed.\r\n\r\n&nbsp;\r\n\r\nOur 34 years of construction/industry experience and Professionally Licensed Team of Specialists gives us the upper hand on the competition. We have performed over 6000 inspections and take pride our ability to multi-task, accompanied with our detailed skill set to ensure that your inspection needs are proficiently documented.\r\n\r\nOur <strong>duly licensed Inspectors</strong> can perform Structural and Mechanical Inspections, Wood Destroying Inspections’ (Termite/Carpenter Ants), Pool Inspections, Sprinkler System Inspections, and gas line tests.\r\n\r\nOur <strong>computer generated reports</strong> are <strong>completed on-site</strong> and are printed and emailed at the time of the inspection.  Our Inspectors take the time to verbally go over the written report and provide an on-site walk-thru to ensure that you have a complete understanding of the inspection findings.  We are available for follow-up telephone consultations at no extra cost to you.\r\n\r\nWhether you are buying your first home, listing a home, or adding to your real estate portfolio, it pays to have a professional inspect your investment.  Older homes require specialty inspections, as their sewer lines, electrical systems and/or heating and cooling systems can house costly deficiencies.\r\n\r\n<strong><em><span style="color: #f30a0a;">X</span><span style="color: #14668b;">stream</span><span style="color: #ee0d0d;"> Inspections</span></em></strong> has a Professional Team of Specialists available to ensure that you are completely protected when purchasing one of the largest investments of your life.', 'Home', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-02-28 16:42:35', '2014-02-28 22:42:35', '', 4, 'http://nick.bronsonrocktx.com/4-revision-v1/', 0, 'revision', '', 0),
(148, 1, '2014-02-28 16:43:44', '2014-02-28 22:43:44', '<h1>Header 1</h1>\r\n<h2>Header 2</h2>\r\n<h3>Header 3</h3>\r\n<h4>Header 4</h4>\r\n<h5>Header 5</h5>\r\n<h6>Header 6</h6>\r\n\r\n<p>\r\n  <button type="button" class="btn btn-primary btn-lg">Large button</button>\r\n  <button type="button" class="btn btn-default btn-lg">Large button</button>\r\n</p>\r\n<p>\r\n  <button type="button" class="btn btn-primary">Default button</button>\r\n  <button type="button" class="btn btn-default">Default button</button>\r\n</p>\r\n<p>\r\n  <button type="button" class="btn btn-primary btn-sm">Small button</button>\r\n  <button type="button" class="btn btn-default btn-sm">Small button</button>\r\n</p>\r\n<p>\r\n  <button type="button" class="btn btn-primary btn-xs">Extra small button</button>\r\n  <button type="button" class="btn btn-default btn-xs">Extra small button</button>\r\n</p>\r\n\r\n<blockquote>"This is a quote. Our 34 years of construction/industry experience and Professionally Licensed Team of Specialists gives us the upper hand on the competition."</blockquote>\r\n<ul>\r\n	<li>List Item</li>\r\n	<li>List Item</li>\r\n	<li>List Item</li>\r\n	<li>List Item</li>\r\n	<li>List Item</li>\r\n</ul>\r\n<ol>\r\n	<li>List Item</li>\r\n	<li>List Item</li>\r\n	<li>List Item</li>\r\n	<li>List Item</li>\r\n	<li>List Item</li>\r\n</ol>\r\n<strong><em><span style="color: #f00c0c;">X</span><span style="color: #0a72b4;">stream </span><span style="color: #f00909;">Inspections </span></em></strong>is a <strong>“Woman Owned Business”</strong> that offers a comprehensive, in-depth detailed inspection that goes <strong>beyond</strong> what is required by the minimum standards required by the Texas Real Estate Commission.  <strong>Our 200 point, 50-100 digitally documented inspection</strong> gives you the comfort of knowing that your real estate purchase, sale or lease is being tested, inspected and analyzed by the best in the business.  Our Team of <strong>Licensed Specialists </strong>is available for telephone consultation during your structural and mechanical inspection and if needed an appointment can be made for a specialty inspection if discovery is needed.\r\n\r\n&nbsp;\r\n\r\nOur 34 years of construction/industry experience and Professionally Licensed Team of Specialists gives us the upper hand on the competition. We have performed over 6000 inspections and take pride our ability to multi-task, accompanied with our detailed skill set to ensure that your inspection needs are proficiently documented.\r\n\r\nOur <strong>duly licensed Inspectors</strong> can perform Structural and Mechanical Inspections, Wood Destroying Inspections’ (Termite/Carpenter Ants), Pool Inspections, Sprinkler System Inspections, and gas line tests.\r\n\r\nOur <strong>computer generated reports</strong> are <strong>completed on-site</strong> and are printed and emailed at the time of the inspection.  Our Inspectors take the time to verbally go over the written report and provide an on-site walk-thru to ensure that you have a complete understanding of the inspection findings.  We are available for follow-up telephone consultations at no extra cost to you.\r\n\r\nWhether you are buying your first home, listing a home, or adding to your real estate portfolio, it pays to have a professional inspect your investment.  Older homes require specialty inspections, as their sewer lines, electrical systems and/or heating and cooling systems can house costly deficiencies.\r\n\r\n<strong><em><span style="color: #f30a0a;">X</span><span style="color: #14668b;">stream</span><span style="color: #ee0d0d;"> Inspections</span></em></strong> has a Professional Team of Specialists available to ensure that you are completely protected when purchasing one of the largest investments of your life.', 'Home', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-02-28 16:43:44', '2014-02-28 22:43:44', '', 4, 'http://nick.bronsonrocktx.com/4-revision-v1/', 0, 'revision', '', 0),
(149, 1, '2014-02-28 16:44:19', '2014-02-28 22:44:19', '<h1>Header 1</h1>\r\n<h2>Header 2</h2>\r\n<h3>Header 3</h3>\r\n<h4>Header 4</h4>\r\n<h5>Header 5</h5>\r\n<h6>Header 6</h6>\r\n\r\n<p>\r\n  <button type="button" class="btn btn-primary btn-lg">Large button</button>\r\n</p>\r\n<p>\r\n  <button type="button" class="btn btn-primary">Default button</button>\r\n</p>\r\n<p>\r\n  <button type="button" class="btn btn-primary btn-sm">Small button</button>\r\n</p>\r\n<p>\r\n  <button type="button" class="btn btn-primary btn-xs">Extra small button</button>\r\n</p>\r\n\r\n<blockquote>"This is a quote. Our 34 years of construction/industry experience and Professionally Licensed Team of Specialists gives us the upper hand on the competition."</blockquote>\r\n<ul>\r\n	<li>List Item</li>\r\n	<li>List Item</li>\r\n	<li>List Item</li>\r\n	<li>List Item</li>\r\n	<li>List Item</li>\r\n</ul>\r\n<ol>\r\n	<li>List Item</li>\r\n	<li>List Item</li>\r\n	<li>List Item</li>\r\n	<li>List Item</li>\r\n	<li>List Item</li>\r\n</ol>\r\n<strong><em><span style="color: #f00c0c;">X</span><span style="color: #0a72b4;">stream </span><span style="color: #f00909;">Inspections </span></em></strong>is a <strong>“Woman Owned Business”</strong> that offers a comprehensive, in-depth detailed inspection that goes <strong>beyond</strong> what is required by the minimum standards required by the Texas Real Estate Commission.  <strong>Our 200 point, 50-100 digitally documented inspection</strong> gives you the comfort of knowing that your real estate purchase, sale or lease is being tested, inspected and analyzed by the best in the business.  Our Team of <strong>Licensed Specialists </strong>is available for telephone consultation during your structural and mechanical inspection and if needed an appointment can be made for a specialty inspection if discovery is needed.\r\n\r\n&nbsp;\r\n\r\nOur 34 years of construction/industry experience and Professionally Licensed Team of Specialists gives us the upper hand on the competition. We have performed over 6000 inspections and take pride our ability to multi-task, accompanied with our detailed skill set to ensure that your inspection needs are proficiently documented.\r\n\r\nOur <strong>duly licensed Inspectors</strong> can perform Structural and Mechanical Inspections, Wood Destroying Inspections’ (Termite/Carpenter Ants), Pool Inspections, Sprinkler System Inspections, and gas line tests.\r\n\r\nOur <strong>computer generated reports</strong> are <strong>completed on-site</strong> and are printed and emailed at the time of the inspection.  Our Inspectors take the time to verbally go over the written report and provide an on-site walk-thru to ensure that you have a complete understanding of the inspection findings.  We are available for follow-up telephone consultations at no extra cost to you.\r\n\r\nWhether you are buying your first home, listing a home, or adding to your real estate portfolio, it pays to have a professional inspect your investment.  Older homes require specialty inspections, as their sewer lines, electrical systems and/or heating and cooling systems can house costly deficiencies.\r\n\r\n<strong><em><span style="color: #f30a0a;">X</span><span style="color: #14668b;">stream</span><span style="color: #ee0d0d;"> Inspections</span></em></strong> has a Professional Team of Specialists available to ensure that you are completely protected when purchasing one of the largest investments of your life.', 'Home', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-02-28 16:44:19', '2014-02-28 22:44:19', '', 4, 'http://nick.bronsonrocktx.com/4-revision-v1/', 0, 'revision', '', 0),
(150, 1, '2014-02-28 17:10:56', '2014-02-28 23:10:56', '<h1>Commercial &amp; Residential Inspections</h1>\r\n<strong><em><span style="color: #f00c0c;">X</span><span style="color: #0a72b4;">stream </span><span style="color: #f00909;">Inspections </span></em></strong>is a <strong>“Woman Owned Business”</strong> that offers a comprehensive, in-depth detailed inspection that goes <strong>beyond</strong> what is required by the minimum standards required by the Texas Real Estate Commission.  <strong>Our 200 point, 50-100 digitally documented inspection</strong> gives you the comfort of knowing that your real estate purchase, sale or lease is being tested, inspected and analyzed by the best in the business.  Our Team of <strong>Licensed Specialists </strong>is available for telephone consultation during your structural and mechanical inspection and if needed an appointment can be made for a specialty inspection if discovery is needed.\r\n\r\n&nbsp;\r\n\r\nOur 34 years of construction/industry experience and Professionally Licensed Team of Specialists gives us the upper hand on the competition. We have performed over 6000 inspections and take pride our ability to multi-task, accompanied with our detailed skill set to ensure that your inspection needs are proficiently documented.\r\n\r\nOur <strong>duly licensed Inspectors</strong> can perform Structural and Mechanical Inspections, Wood Destroying Inspections’ (Termite/Carpenter Ants), Pool Inspections, Sprinkler System Inspections, and gas line tests.\r\n\r\nOur <strong>computer generated reports</strong> are <strong>completed on-site</strong> and are printed and emailed at the time of the inspection.  Our Inspectors take the time to verbally go over the written report and provide an on-site walk-thru to ensure that you have a complete understanding of the inspection findings.  We are available for follow-up telephone consultations at no extra cost to you.\r\n\r\nWhether you are buying your first home, listing a home, or adding to your real estate portfolio, it pays to have a professional inspect your investment.  Older homes require specialty inspections, as their sewer lines, electrical systems and/or heating and cooling systems can house costly deficiencies.\r\n\r\n<strong><em><span style="color: #f30a0a;">X</span><span style="color: #14668b;">stream</span><span style="color: #ee0d0d;"> Inspections</span></em></strong> has a Professional Team of Specialists available to ensure that you are completely protected when purchasing one of the largest investments of your life.', 'Home', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-02-28 17:10:56', '2014-02-28 23:10:56', '', 4, 'http://nick.bronsonrocktx.com/4-revision-v1/', 0, 'revision', '', 0),
(151, 1, '2014-02-28 17:11:16', '2014-02-28 23:11:16', '<h2>Commercial &amp; Residential Inspections</h2>\r\n<strong><em><span style="color: #f00c0c;">X</span><span style="color: #0a72b4;">stream </span><span style="color: #f00909;">Inspections </span></em></strong>is a <strong>“Woman Owned Business”</strong> that offers a comprehensive, in-depth detailed inspection that goes <strong>beyond</strong> what is required by the minimum standards required by the Texas Real Estate Commission.  <strong>Our 200 point, 50-100 digitally documented inspection</strong> gives you the comfort of knowing that your real estate purchase, sale or lease is being tested, inspected and analyzed by the best in the business.  Our Team of <strong>Licensed Specialists </strong>is available for telephone consultation during your structural and mechanical inspection and if needed an appointment can be made for a specialty inspection if discovery is needed.\r\n\r\n&nbsp;\r\n\r\nOur 34 years of construction/industry experience and Professionally Licensed Team of Specialists gives us the upper hand on the competition. We have performed over 6000 inspections and take pride our ability to multi-task, accompanied with our detailed skill set to ensure that your inspection needs are proficiently documented.\r\n\r\nOur <strong>duly licensed Inspectors</strong> can perform Structural and Mechanical Inspections, Wood Destroying Inspections’ (Termite/Carpenter Ants), Pool Inspections, Sprinkler System Inspections, and gas line tests.\r\n\r\nOur <strong>computer generated reports</strong> are <strong>completed on-site</strong> and are printed and emailed at the time of the inspection.  Our Inspectors take the time to verbally go over the written report and provide an on-site walk-thru to ensure that you have a complete understanding of the inspection findings.  We are available for follow-up telephone consultations at no extra cost to you.\r\n\r\nWhether you are buying your first home, listing a home, or adding to your real estate portfolio, it pays to have a professional inspect your investment.  Older homes require specialty inspections, as their sewer lines, electrical systems and/or heating and cooling systems can house costly deficiencies.\r\n\r\n<strong><em><span style="color: #f30a0a;">X</span><span style="color: #14668b;">stream</span><span style="color: #ee0d0d;"> Inspections</span></em></strong> has a Professional Team of Specialists available to ensure that you are completely protected when purchasing one of the largest investments of your life.', 'Home', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-02-28 17:11:16', '2014-02-28 23:11:16', '', 4, 'http://nick.bronsonrocktx.com/4-revision-v1/', 0, 'revision', '', 0),
(152, 1, '2014-03-01 00:37:02', '2014-03-01 06:37:02', '<h2>Commercial &amp; Residential Inspections</h2>\r\n<strong><em><span style="color: #f00c0c;">X</span><span style="color: #0a72b4;">stream </span><span style="color: #f00909;">Inspections </span></em></strong>is a <strong>“Woman Owned Business”</strong> that offers a comprehensive, in-depth detailed inspection that goes <strong>beyond</strong> what is required by the minimum standards required by the Texas Real Estate Commission.  <strong>Our 200 point, 50-100 digitally documented inspection</strong> gives you the comfort of knowing that your real estate purchase, sale or lease is being tested, inspected and analyzed by the best in the business.  Our Team of <strong>Licensed Specialists </strong>is available for telephone consultation during your structural and mechanical inspection and if needed an appointment can be made for a specialty inspection if discovery is needed.\r\n\r\nOur 34 years of construction/industry experience and Professionally Licensed Team of Specialists gives us the upper hand on the competition. We have performed over 6000 inspections and take pride our ability to multi-task, accompanied with our detailed skill set to ensure that your inspection needs are proficiently documented.\r\n\r\nOur <strong>duly licensed Inspectors</strong> can perform Structural and Mechanical Inspections, Wood Destroying Inspections’ (Termite/Carpenter Ants), Pool Inspections, Sprinkler System Inspections, and gas line tests.\r\n\r\nOur <strong>computer generated reports</strong> are <strong>completed on-site</strong> and are printed and emailed at the time of the inspection.  Our Inspectors take the time to verbally go over the written report and provide an on-site walk-thru to ensure that you have a complete understanding of the inspection findings.  We are available for follow-up telephone consultations at no extra cost to you.\r\n\r\nWhether you are buying your first home, listing a home, or adding to your real estate portfolio, it pays to have a professional inspect your investment.  Older homes require specialty inspections, as their sewer lines, electrical systems and/or heating and cooling systems can house costly deficiencies.\r\n\r\n<strong><em><span style="color: #f30a0a;">X</span><span style="color: #14668b;">stream</span><span style="color: #ee0d0d;"> Inspections</span></em></strong> has a Professional Team of Specialists available to ensure that you are completely protected when purchasing one of the largest investments of your life.', 'Home', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-03-01 00:37:02', '2014-03-01 06:37:02', '', 4, 'http://nick.bronsonrocktx.com/4-revision-v1/', 0, 'revision', '', 0),
(153, 1, '2014-03-03 15:54:30', '2014-03-03 21:54:30', '<h2>Commercial &amp; Residential Inspections</h2>\r\n<strong><em><span style="color: #f00c0c;">X</span><span style="color: #0a72b4;">stream </span><span style="color: #f00909;">Inspections </span></em></strong>is a <strong>“Woman Owned Business”</strong> that offers a comprehensive, in-depth detailed inspection that goes <strong>beyond</strong> what is required by the minimum standards required by the Texas Real Estate Commission.  <strong>Our 200 point, 50-100 digitally documented inspection</strong> gives you the comfort of knowing that your real estate purchase, sale or lease is being tested, inspected and analyzed by the best in the business.  Our Team of <strong>Licensed Specialists </strong>is available for telephone consultation during your structural and mechanical inspection and if needed an appointment can be made for a specialty inspection if discovery is needed.\r\n\r\nOur 34 years of construction/industry experience and Professionally Licensed Team of Specialists gives us the upper hand on the competition. We have performed over 6000 inspections and take pride our ability to multi-task, accompanied with our detailed skill set to ensure that your inspection needs are proficiently documented.\r\n\r\nOur <strong>duly licensed Inspectors</strong> can perform Structural and Mechanical Inspections, Wood Destroying Inspections’ (Termite/Carpenter Ants), Pool Inspections, Sprinkler System Inspections, and gas line tests.', 'Home', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-03-03 15:54:30', '2014-03-03 21:54:30', '', 4, 'http://nick.bronsonrocktx.com/4-revision-v1/', 0, 'revision', '', 0),
(155, 1, '2014-03-03 15:57:40', '2014-03-03 21:57:40', '<h2>Commercial &amp; Residential Inspections</h2>\r\n<strong><em><span style="color: #f00c0c;">X</span><span style="color: #0a72b4;">stream </span><span style="color: #f00909;">Inspections </span></em></strong>is a <strong>“Woman Owned Business”</strong> that offers a comprehensive, in-depth detailed inspection that goes <strong>beyond</strong> what is required by the minimum standards required by the Texas Real Estate Commission.  <strong>Our 200 point, 50-100 digitally documented inspection</strong> gives you the comfort of knowing that your real estate purchase, sale or lease is being tested, inspected and analyzed by the best in the business.  Our Team of <strong>Licensed Specialists </strong>is available for telephone consultation during your structural and mechanical inspection and if needed an appointment can be made for a specialty inspection if discovery is needed.\r\n\r\nOur 34 years of construction/industry experience and Professionally Licensed Team of Specialists gives us the upper hand on the competition. We have performed over 6000 inspections and take pride our ability to multi-task, accompanied with our detailed skill set to ensure that your inspection needs are proficiently documented.\r\n\r\nOur <strong>duly licensed Inspectors</strong> can perform Structural and Mechanical Inspections, Wood Destroying Inspections’ (Termite/Carpenter Ants), Pool Inspections, Sprinkler System Inspections, and gas line tests.\r\n\r\n<a class="btn btn-success" href="#">Call (972) 492-7920</a>\r\n<a class="btn btn-success" href="/contact-us">Email Us</a>', 'Home', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-03-03 15:57:40', '2014-03-03 21:57:40', '', 4, 'http://nick.bronsonrocktx.com/4-revision-v1/', 0, 'revision', '', 0),
(156, 1, '2014-03-03 15:58:21', '2014-03-03 21:58:21', '<h2>Commercial &amp; Residential Inspections</h2>\r\n<strong><em><span style="color: #f00c0c;">X</span><span style="color: #0a72b4;">stream </span><span style="color: #f00909;">Inspections </span></em></strong>is a <strong>“Woman Owned Business”</strong> that offers a comprehensive, in-depth detailed inspection that goes <strong>beyond</strong> what is required by the minimum standards required by the Texas Real Estate Commission.  <strong>Our 200 point, 50-100 digitally documented inspection</strong> gives you the comfort of knowing that your real estate purchase, sale or lease is being tested, inspected and analyzed by the best in the business.  Our Team of <strong>Licensed Specialists </strong>is available for telephone consultation during your structural and mechanical inspection and if needed an appointment can be made for a specialty inspection if discovery is needed.\r\n\r\nOur 34 years of construction/industry experience and Professionally Licensed Team of Specialists gives us the upper hand on the competition. We have performed over 6000 inspections and take pride our ability to multi-task, accompanied with our detailed skill set to ensure that your inspection needs are proficiently documented.\r\n\r\nOur <strong>duly licensed Inspectors</strong> can perform Structural and Mechanical Inspections, Wood Destroying Inspections’ (Termite/Carpenter Ants), Pool Inspections, Sprinkler System Inspections, and gas line tests.\r\n\r\n<a class="btn btn-danger" href="#">Call (972) 492-7920</a>\r\n<a class="btn btn-danger" href="/contact-us">Email Us</a>', 'Home', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-03-03 15:58:21', '2014-03-03 21:58:21', '', 4, 'http://nick.bronsonrocktx.com/4-revision-v1/', 0, 'revision', '', 0),
(157, 1, '2014-03-03 15:58:33', '2014-03-03 21:58:33', '<h2>Commercial &amp; Residential Inspections</h2>\r\n<strong><em><span style="color: #f00c0c;">X</span><span style="color: #0a72b4;">stream </span><span style="color: #f00909;">Inspections </span></em></strong>is a <strong>“Woman Owned Business”</strong> that offers a comprehensive, in-depth detailed inspection that goes <strong>beyond</strong> what is required by the minimum standards required by the Texas Real Estate Commission.  <strong>Our 200 point, 50-100 digitally documented inspection</strong> gives you the comfort of knowing that your real estate purchase, sale or lease is being tested, inspected and analyzed by the best in the business.  Our Team of <strong>Licensed Specialists </strong>is available for telephone consultation during your structural and mechanical inspection and if needed an appointment can be made for a specialty inspection if discovery is needed.\r\n\r\nOur 34 years of construction/industry experience and Professionally Licensed Team of Specialists gives us the upper hand on the competition. We have performed over 6000 inspections and take pride our ability to multi-task, accompanied with our detailed skill set to ensure that your inspection needs are proficiently documented.\r\n\r\nOur <strong>duly licensed Inspectors</strong> can perform Structural and Mechanical Inspections, Wood Destroying Inspections’ (Termite/Carpenter Ants), Pool Inspections, Sprinkler System Inspections, and gas line tests.\r\n\r\n<a class="btn btn-danger" href="#">Call (972) 492-7920</a><a class="btn btn-danger" href="/contact-us">Email Us</a>', 'Home', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-03-03 15:58:33', '2014-03-03 21:58:33', '', 4, 'http://nick.bronsonrocktx.com/4-revision-v1/', 0, 'revision', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(158, 1, '2014-03-03 15:58:46', '2014-03-03 21:58:46', '<h2>Commercial &amp; Residential Inspections</h2>\r\n<strong><em><span style="color: #f00c0c;">X</span><span style="color: #0a72b4;">stream </span><span style="color: #f00909;">Inspections </span></em></strong>is a <strong>“Woman Owned Business”</strong> that offers a comprehensive, in-depth detailed inspection that goes <strong>beyond</strong> what is required by the minimum standards required by the Texas Real Estate Commission.  <strong>Our 200 point, 50-100 digitally documented inspection</strong> gives you the comfort of knowing that your real estate purchase, sale or lease is being tested, inspected and analyzed by the best in the business.  Our Team of <strong>Licensed Specialists </strong>is available for telephone consultation during your structural and mechanical inspection and if needed an appointment can be made for a specialty inspection if discovery is needed.\r\n\r\nOur 34 years of construction/industry experience and Professionally Licensed Team of Specialists gives us the upper hand on the competition. We have performed over 6000 inspections and take pride our ability to multi-task, accompanied with our detailed skill set to ensure that your inspection needs are proficiently documented.\r\n\r\nOur <strong>duly licensed Inspectors</strong> can perform Structural and Mechanical Inspections, Wood Destroying Inspections’ (Termite/Carpenter Ants), Pool Inspections, Sprinkler System Inspections, and gas line tests.\r\n\r\n<a class="btn btn-danger" href="#">Call (972) 492-7920</a> <a class="btn btn-danger" href="/contact-us">Email Us</a>', 'Home', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-03-03 15:58:46', '2014-03-03 21:58:46', '', 4, 'http://nick.bronsonrocktx.com/4-revision-v1/', 0, 'revision', '', 0),
(159, 1, '2014-03-03 15:59:41', '2014-03-03 21:59:41', '<h2>Commercial &amp; Residential Inspections</h2>\r\n<strong><em><span style="color: #f00c0c;">X</span><span style="color: #0a72b4;">stream </span><span style="color: #f00909;">Inspections </span></em></strong>is a <strong>“Woman Owned Business”</strong> that offers a comprehensive, in-depth detailed inspection that goes <strong>beyond</strong> what is required by the minimum standards required by the Texas Real Estate Commission.  <strong>Our 200 point, 50-100 digitally documented inspection</strong> gives you the comfort of knowing that your real estate purchase, sale or lease is being tested, inspected and analyzed by the best in the business.  Our Team of <strong>Licensed Specialists </strong>is available for telephone consultation during your structural and mechanical inspection and if needed an appointment can be made for a specialty inspection if discovery is needed.\r\n\r\nOur 34 years of construction/industry experience and Professionally Licensed Team of Specialists gives us the upper hand on the competition. We have performed over 6000 inspections and take pride our ability to multi-task, accompanied with our detailed skill set to ensure that your inspection needs are proficiently documented.\r\n\r\nOur <strong>duly licensed Inspectors</strong> can perform Structural and Mechanical Inspections, Wood Destroying Inspections’ (Termite/Carpenter Ants), Pool Inspections, Sprinkler System Inspections, and gas line tests.', 'Home', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-03-03 15:59:41', '2014-03-03 21:59:41', '', 4, 'http://nick.bronsonrocktx.com/4-revision-v1/', 0, 'revision', '', 0),
(160, 1, '2014-03-03 16:47:27', '2014-03-03 22:47:27', '<h2>Commercial &amp; Residential Property Inspections</h2>\r\n<strong><em><span style="color: #f00c0c;">X</span><span style="color: #0a72b4;">stream </span><span style="color: #f00909;">Inspections </span></em></strong>is a <strong>“Woman Owned Business”</strong> that offers a comprehensive, in-depth detailed inspection that goes <strong>beyond</strong> what is required by the minimum standards required by the Texas Real Estate Commission.  <strong>Our 200 point, 50-100 digitally documented inspection</strong> gives you the comfort of knowing that your real estate purchase, sale or lease is being tested, inspected and analyzed by the best in the business.  Our Team of <strong>Licensed Specialists </strong>is available for telephone consultation during your structural and mechanical inspection and if needed an appointment can be made for a specialty inspection if discovery is needed.\r\n\r\nOur 34 years of construction/industry experience and Professionally Licensed Team of Specialists gives us the upper hand on the competition. We have performed over 6000 inspections and take pride our ability to multi-task, accompanied with our detailed skill set to ensure that your inspection needs are proficiently documented.\r\n\r\nOur <strong>duly licensed Inspectors</strong> can perform Structural and Mechanical Inspections, Wood Destroying Inspections’ (Termite/Carpenter Ants), Pool Inspections, Sprinkler System Inspections, and gas line tests.', 'Home', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-03-03 16:47:27', '2014-03-03 22:47:27', '', 4, 'http://nick.bronsonrocktx.com/4-revision-v1/', 0, 'revision', '', 0),
(183, 1, '2014-03-20 12:32:26', '2014-03-20 18:32:26', '<h2>Commercial &amp; Residential Property Inspections</h2>\r\n<strong><em><span style="color: #f00c0c;">X</span><span style="color: #0a72b4;">stream </span><span style="color: #f00909;">Inspections </span></em></strong>is a <strong>“Woman Owned Business”</strong> that offers a comprehensive, in-depth detailed inspection that goes <strong>beyond</strong> what is required by the minimum standards required by the Texas Real Estate Commission.  <strong>Our 200 point, 50-100 digitally documented inspection</strong> gives you the comfort of knowing that your real estate purchase, sale or lease is being tested, inspected and analyzed by the best in the business.  Our Team of <strong>Licensed Specialists </strong>is available for telephone consultation during your structural and mechanical inspection and if needed an appointment can be made for a specialty inspection if discovery is needed.\r\n\r\nOur 34 years of construction/industry experience and Professionally Licensed Team of Specialists gives us the upper hand on the competition. We have performed over 6000 inspections and take pride our ability to multi-task, accompanied with our detailed skill set to ensure that your inspection needs are proficiently documented.\r\n\r\nOur <strong>duly licensed Inspectors</strong> can perform Structural and Mechanical Inspections, Wood Destroying Inspections’ (Termite/Carpenter Ants), Pool Inspections, Sprinkler System Inspections, and gas line tests.\r\n\r\nOur <strong>computer generated reports</strong> are <strong>completed on-site</strong> and are printed and emailed at the time of the inspection.  Our Inspectors take the time to verbally go over the written report and provide an on-site walk-thru to ensure that you have a complete understanding of the inspection findings.  We are available for follow-up telephone consultations at no extra cost to you.\r\n\r\nWhether you are buying your first home, listing a home, or adding to your real estate portfolio, it pays to have a professional inspect your investment.  Older homes require specialty inspections, as their sewer lines, electrical systems and/or heating and cooling systems can house costly deficiencies.\r\n\r\n<strong><em>Xstream Inspections</em></strong> has a Professional Team of Specialists available to ensure that you are completely protected when purchasing one of the largest investments of your life.', 'Home', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-03-20 12:32:26', '2014-03-20 18:32:26', '', 4, 'http://nick.bronsonrocktx.com/4-revision-v1/', 0, 'revision', '', 0),
(207, 1, '2014-03-20 17:05:38', '2014-03-20 23:05:38', ' ', '', '', 'publish', 'open', 'open', '', '207', '', '', '2014-03-24 20:51:09', '2014-03-25 02:51:09', '', 0, 'http://nick.bronsonrocktx.com/?p=207', 3, 'nav_menu_item', '', 0),
(209, 1, '2014-03-20 17:08:59', '2014-03-20 23:08:59', '[gravityform id="1" name="Contact Us" title="false" ajax="true"]', ' Contact Us', '', 'inherit', 'open', 'open', '', '17-revision-v1', '', '', '2014-03-20 17:08:59', '2014-03-20 23:08:59', '', 17, 'http://nick.bronsonrocktx.com/17-revision-v1/', 0, 'revision', '', 0),
(210, 1, '2014-03-20 17:09:44', '2014-03-20 23:09:44', '<h1>Contact Us</h1>\r\n<hr />\r\n[gravityform id="1" name="Contact Us" title="false" ajax="true"]', ' Contact Us', '', 'inherit', 'open', 'open', '', '17-revision-v1', '', '', '2014-03-20 17:09:44', '2014-03-20 23:09:44', '', 17, 'http://nick.bronsonrocktx.com/17-revision-v1/', 0, 'revision', '', 0),
(211, 1, '2014-03-20 17:10:00', '2014-03-20 23:10:00', '<h1 style="text-align: center;">Contact Us</h1>\r\n\r\n<hr />\r\n\r\n[gravityform id="1" name="Contact Us" title="false" ajax="true"]', ' Contact Us', '', 'inherit', 'open', 'open', '', '17-revision-v1', '', '', '2014-03-20 17:10:00', '2014-03-20 23:10:00', '', 17, 'http://nick.bronsonrocktx.com/17-revision-v1/', 0, 'revision', '', 0),
(216, 1, '2014-03-21 08:30:06', '2014-03-21 14:30:06', '<h2>Commercial &amp; Residential Property Inspections</h2>\r\n<strong><em><span style="color: #f00c0c;">X</span><span style="color: #0a72b4;">stream </span><span style="color: #f00909;">Inspections </span></em></strong>is a <strong>“Woman Owned Business”</strong> that offers a comprehensive, in-depth detailed inspection that goes <strong>beyond</strong> what is required by the minimum standards required by the Texas Real Estate Commission.  <strong>Our 200 point, 50-100 digitally documented inspection</strong> gives you the comfort of knowing that your real estate purchase, sale or lease is being tested, inspected and analyzed by the best in the business.  Our Team of <strong>Licensed Specialists </strong>is available for telephone consultation during your structural and mechanical inspection and if needed an appointment can be made for a specialty inspection if discovery is needed.\r\n\r\nOur 34 years of construction/industry experience and Professionally Licensed Team of Specialists gives us the upper hand on the competition. We have performed over 6000 inspections and take pride our ability to multi-task, accompanied with our detailed skill set to ensure that your inspection needs are proficiently documented.', 'Home', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-03-21 08:30:06', '2014-03-21 14:30:06', '', 4, 'http://nick.bronsonrocktx.com/4-revision-v1/', 0, 'revision', '', 0),
(217, 1, '2014-03-24 11:06:12', '2014-03-24 17:06:12', '<h1>Commercial &amp; Residential Property Inspections</h1>\r\n<strong><em><span style="color: #f00c0c;">X</span><span style="color: #0a72b4;">stream </span><span style="color: #f00909;">Inspections </span></em></strong>is a <strong>“Woman Owned Business”</strong> that offers a comprehensive, in-depth detailed inspection that goes <strong>beyond</strong> what is required by the minimum standards required by the Texas Real Estate Commission.  <strong>Our 200 point, 50-100 digitally documented inspection</strong> gives you the comfort of knowing that your real estate purchase, sale or lease is being tested, inspected and analyzed by the best in the business.  Our Team of <strong>Licensed Specialists </strong>is available for telephone consultation during your structural and mechanical inspection and if needed an appointment can be made for a specialty inspection if discovery is needed.\r\n\r\nOur 34 years of construction/industry experience and Professionally Licensed Team of Specialists gives us the upper hand on the competition. We have performed over 6000 inspections and take pride our ability to multi-task, accompanied with our detailed skill set to ensure that your inspection needs are proficiently documented.\r\n<h1>Header 1</h1>\r\n<h2>Header 2</h2>\r\n<h3>Header 3</h3>\r\n<h4>Header 4</h4>\r\n<h5>Header 5</h5>\r\n<h6>Header 6</h6>', 'Home', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-03-24 11:06:12', '2014-03-24 17:06:12', '', 4, 'http://nick.bronsonrocktx.com/4-revision-v1/', 0, 'revision', '', 0),
(218, 1, '2014-03-24 11:31:43', '2014-03-24 17:31:43', '<h1>Commercial &amp; Residential Property Inspections</h1>\r\n<strong><em><span style="color: #f00c0c;">X</span><span style="color: #0a72b4;">stream </span><span style="color: #f00909;">Inspections </span></em></strong>is a <strong>“Woman Owned Business”</strong> that offers a comprehensive, in-depth detailed inspection that goes <strong>beyond</strong> what is required by the minimum standards required by the Texas Real Estate Commission.  <strong>Our 200 point, 50-100 digitally documented inspection</strong> gives you the comfort of knowing that your real estate purchase, sale or lease is being tested, inspected and analyzed by the best in the business.  Our Team of <strong>Licensed Specialists </strong>is available for telephone consultation during your structural and mechanical inspection and if needed an appointment can be made for a specialty inspection if discovery is needed.\r\n\r\nOur 34 years of construction/industry experience and Professionally Licensed Team of Specialists gives us the upper hand on the competition. We have performed over 6000 inspections and take pride our ability to multi-task, accompanied with our detailed skill set to ensure that your inspection needs are proficiently documented.', 'Home', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-03-24 11:31:43', '2014-03-24 17:31:43', '', 4, 'http://nick.bronsonrocktx.com/4-revision-v1/', 0, 'revision', '', 0),
(236, 1, '2014-03-24 19:43:38', '2014-03-25 01:43:38', '<h1>Contact Us</h1>\r\n\r\n<hr />\r\n\r\n[gravityform id="1" name="Contact Us" title="false" ajax="true"]', ' Contact Us', '', 'inherit', 'open', 'open', '', '17-revision-v1', '', '', '2014-03-24 19:43:38', '2014-03-25 01:43:38', '', 17, 'http://nick.bronsonrocktx.com/17-revision-v1/', 0, 'revision', '', 0),
(237, 1, '2014-03-24 19:45:16', '2014-03-25 01:45:16', '<h1>Contact Us</h1>\r\n\r\n<hr />\r\n\r\n<a class="btn btn-danger" href="#">\r\n<i class="fa fa-phone fa-1x"></i>\r\nCall (972) 492-7920\r\n</a>\r\n<a class="btn btn-danger" href="/contact-us">\r\n<i class="fa fa-envelope fa-1x"></i>\r\nEmail Us\r\n</a>\r\n\r\n[gravityform id="1" name="Contact Us" title="false" ajax="true"]', ' Contact Us', '', 'inherit', 'open', 'open', '', '17-revision-v1', '', '', '2014-03-24 19:45:16', '2014-03-25 01:45:16', '', 17, 'http://nick.bronsonrocktx.com/17-revision-v1/', 0, 'revision', '', 0),
(238, 1, '2014-03-24 19:45:46', '2014-03-25 01:45:46', '<h1>Contact Us</h1>\r\n\r\n<hr />\r\n\r\n<a class="btn btn-danger" href="#"><i class="fa fa-phone fa-1x"></i>Call (972) 492-7920</a>\r\n<a class="btn btn-danger" href="/contact-us"><i class="fa fa-envelope fa-1x"></i>Email Us</a>\r\n\r\n[gravityform id="1" name="Contact Us" title="false" ajax="true"]', ' Contact Us', '', 'inherit', 'open', 'open', '', '17-revision-v1', '', '', '2014-03-24 19:45:46', '2014-03-25 01:45:46', '', 17, 'http://nick.bronsonrocktx.com/17-revision-v1/', 0, 'revision', '', 0),
(239, 1, '2014-03-24 19:46:05', '2014-03-25 01:46:05', '<h1>Contact Us</h1>\r\n\r\n<hr />\r\n<a class="btn btn-danger" href="#"><i class="fa fa-phone fa-1x"></i>Call (972) 492-7920</a><a class="btn btn-danger" href="/contact-us"><i class="fa fa-envelope fa-1x"></i>Email Us</a>\r\n[gravityform id="1" name="Contact Us" title="false" ajax="true"]', ' Contact Us', '', 'inherit', 'open', 'open', '', '17-revision-v1', '', '', '2014-03-24 19:46:05', '2014-03-25 01:46:05', '', 17, 'http://nick.bronsonrocktx.com/17-revision-v1/', 0, 'revision', '', 0),
(240, 1, '2014-03-24 19:50:46', '2014-03-25 01:50:46', '<h1>Contact Us</h1>\n\n<hr />\n\n<h2>Send a Message</h2>', ' Contact Us', '', 'inherit', 'open', 'open', '', '17-autosave-v1', '', '', '2014-03-24 19:50:46', '2014-03-25 01:50:46', '', 17, 'http://nick.bronsonrocktx.com/17-autosave-v1/', 0, 'revision', '', 0),
(241, 1, '2014-03-24 19:47:23', '2014-03-25 01:47:23', '<h1>Contact Us</h1>\r\n\r\n<hr />\r\n\r\n<a class="btn btn-danger" href="#"><i class="fa fa-phone fa-1x"></i>Call (972) 492-7920</a>   <a class="btn btn-danger" href="/contact-us"><i class="fa fa-envelope fa-1x"></i>Email Us</a>\r\n\r\n<h2>Send a Message</h2>\r\n[gravityform id="1" name="Contact Us" title="false" ajax="true"]', ' Contact Us', '', 'inherit', 'open', 'open', '', '17-revision-v1', '', '', '2014-03-24 19:47:23', '2014-03-25 01:47:23', '', 17, 'http://nick.bronsonrocktx.com/17-revision-v1/', 0, 'revision', '', 0),
(242, 1, '2014-03-24 19:48:41', '2014-03-25 01:48:41', '<h1>Contact Us</h1>\r\n\r\n<hr />\r\n\r\n<a class="btn btn-danger" href="#"><i class="fa fa-phone fa-1x"></i>Call (972) 492-7920</a>   <a class="btn btn-danger" href="mailto:shelly@dev.bronsonrocktx.com"><i class="fa fa-envelope fa-1x"></i>Email Us</a>\r\n\r\n<h2>Send a Message</h2>\r\n[gravityform id="1" name="Contact Us" title="false" ajax="true"]', ' Contact Us', '', 'inherit', 'open', 'open', '', '17-revision-v1', '', '', '2014-03-24 19:48:41', '2014-03-25 01:48:41', '', 17, 'http://nick.bronsonrocktx.com/17-revision-v1/', 0, 'revision', '', 0),
(243, 1, '2014-03-24 19:49:13', '2014-03-25 01:49:13', '<h1>Contact Us</h1>\r\n\r\n<hr />\r\n\r\n<a class="btn btn-danger" href="#"><i class="fa fa-phone fa-1x"></i>Call (972) 492-7920</a>   <a class="btn btn-danger" href="mailto:shelly@dev.bronsonrocktx.com"><i class="fa fa-envelope fa-1x"></i>Email Us</a>\r\n<h2>Send a Message</h2>\r\n&nbsp;\r\n\r\n[gravityform id="1" name="Contact Us" title="false" ajax="true"]', ' Contact Us', '', 'inherit', 'open', 'open', '', '17-revision-v1', '', '', '2014-03-24 19:49:13', '2014-03-25 01:49:13', '', 17, 'http://nick.bronsonrocktx.com/17-revision-v1/', 0, 'revision', '', 0),
(244, 1, '2014-03-24 19:49:45', '2014-03-25 01:49:45', '<h1>Contact Us</h1>\r\n\r\n<hr />\r\n<h2>Send a Message</h2>\r\n<a class="btn btn-danger" href="#"><i class="fa fa-phone fa-1x"></i>Call (972) 492-7920</a>   <a class="btn btn-danger" href="mailto:shelly@dev.bronsonrocktx.com"><i class="fa fa-envelope fa-1x"></i>Email Us</a>\r\n[gravityform id="1" name="Contact Us" title="false" ajax="true"]', ' Contact Us', '', 'inherit', 'open', 'open', '', '17-revision-v1', '', '', '2014-03-24 19:49:45', '2014-03-25 01:49:45', '', 17, 'http://nick.bronsonrocktx.com/17-revision-v1/', 0, 'revision', '', 0),
(245, 1, '2014-03-24 19:51:13', '2014-03-25 01:51:13', '<h1>Contact Us</h1>\r\n\r\n<hr />\r\n\r\n<h3>Send a Message</h3>\r\n<a class="btn btn-danger" href="#"><i class="fa fa-phone fa-1x"></i>Call (972) 492-7920</a>   <a class="btn btn-danger" href="mailto:shelly@dev.bronsonrocktx.com"><i class="fa fa-envelope fa-1x"></i>Email Us</a>\r\n[gravityform id="1" name="Contact Us" title="false" ajax="true"]', ' Contact Us', '', 'inherit', 'open', 'open', '', '17-revision-v1', '', '', '2014-03-24 19:51:13', '2014-03-25 01:51:13', '', 17, 'http://nick.bronsonrocktx.com/17-revision-v1/', 0, 'revision', '', 0),
(246, 1, '2014-03-24 19:51:58', '2014-03-25 01:51:58', '<h1>Contact Us</h1>\r\n\r\n<hr />\r\n<a class="btn btn-danger" href="#"><i class="fa fa-phone fa-1x"></i>Call (972) 492-7920</a>   <a class="btn btn-danger" href="mailto:shelly@dev.bronsonrocktx.com"><i class="fa fa-envelope fa-1x"></i>Email Us</a>\r\n<h3>Send a Message</h3>\r\n[gravityform id="1" name="Contact Us" title="false" ajax="true"]', ' Contact Us', '', 'inherit', 'open', 'open', '', '17-revision-v1', '', '', '2014-03-24 19:51:58', '2014-03-25 01:51:58', '', 17, 'http://nick.bronsonrocktx.com/17-revision-v1/', 0, 'revision', '', 0),
(255, 1, '2014-03-24 20:12:40', '2014-03-25 02:12:40', ' ', '', '', 'publish', 'open', 'open', '', '255', '', '', '2014-03-24 20:51:09', '2014-03-25 02:51:09', '', 0, 'http://nick.bronsonrocktx.com/?p=255', 1, 'nav_menu_item', '', 0),
(256, 1, '2014-03-24 20:13:04', '2014-03-25 02:13:04', ' ', '', '', 'publish', 'open', 'open', '', '256', '', '', '2014-03-24 20:50:56', '2014-03-25 02:50:56', '', 0, 'http://nick.bronsonrocktx.com/?p=256', 3, 'nav_menu_item', '', 0),
(263, 1, '2014-03-24 20:19:35', '2014-03-25 02:19:35', '<h3>What information do we collect?</h3>\r\n<div>\r\n\r\nWe collect information from you when you register on our site, place an order, subscribe to our newsletter, respond to a survey, fill out a form or send band information.\r\n\r\nWhen ordering or registering on our site, as appropriate, you may be asked to enter your: name, e-mail address, mailing address or phone number. You may, however, visit our site anonymously.\r\n<h3>What do we use your information for?</h3>\r\nAny of the information we collect from you may be used in one of the following ways:\r\n\r\n; To personalize your experience\r\n(your information helps us to better respond to your individual needs)\r\n\r\n; To improve our website\r\n(we continually strive to improve our website offerings based on the information and feedback we receive from you)\r\n\r\n; To improve customer service\r\n(your information helps us to more effectively respond to your customer service requests and support needs)\r\n\r\n; To administer a contest, promotion, survey or other site feature\r\n\r\n; To send periodic emails\r\n<blockquote>The email address you provide for order processing, may be used to send you information and updates pertaining to your order, in addition to receiving occasional company news, updates, related product or service information, etc.</blockquote>\r\nNote: If at any time you would like to unsubscribe from receiving future emails, we include detailed unsubscribe instructions at the bottom of each email.\r\n<h3>How do we protect your information?</h3>\r\nWe implement a variety of security measures to maintain the safety of your personal information when you place an order or enter, submit, or access your personal information.\r\n\r\nWe offer the use of a secure server. All supplied sensitive/credit information is transmitted via Secure Socket Layer (SSL) technology and then encrypted into our Payment gateway providers database only to be accessible by those authorized with special access rights to such systems, and are required to?keep the information confidential.\r\n\r\nAfter a transaction, your private information (credit cards, social security numbers, financials, etc.) will not be stored on our servers.\r\n<h3>Do we use cookies?</h3>\r\nYes (Cookies are small files that a site or its service provider transfers to your computers hard drive through your Web browser (if you allow) that enables the sites or service providers systems to recognize your browser and capture and remember certain information\r\n\r\nWe use cookies to understand and save your preferences for future visits, keep track of advertisements and compile aggregate data about site traffic and site interaction so that we can offer better site experiences and tools in the future. We may contract with third-party service providers to assist us in better understanding our site visitors. These service providers are not permitted to use the information collected on our behalf except to help us conduct and improve our business.\r\n\r\nIf you prefer, you can choose to have your computer warn you each time a cookie is being sent, or you can choose to turn off all cookies via your browser settings. Like most websites, if you turn your cookies off, some of our services may not function properly. However, you can still place orders over the telephone or by contacting customer service.\r\n<h3>Do we disclose any information to outside parties?</h3>\r\nWe do not sell, trade, or otherwise transfer to outside parties your personally identifiable information. This does not include trusted third parties who assist us in operating our website, conducting our business, or servicing you, so long as those parties agree to keep this information confidential. We may also release your information when we believe release is appropriate to comply with the law, enforce our site policies, or protect ours or others rights, property, or safety. However, non-personally identifiable visitor information may be provided to other parties for marketing, advertising, or other uses.\r\n<h3>Third party links</h3>\r\nOccasionally, at our discretion, we may include or offer third party products or services on our website. These third party sites have separate and independent privacy policies. We therefore have no responsibility or liability for the content and activities of these linked sites. Nonetheless, we seek to protect the integrity of our site and welcome any feedback about these sites.\r\n<h3>California Online Privacy Protection Act Compliance</h3>\r\nBecause we value your privacy we have taken the necessary precautions to be in compliance with the California Online Privacy Protection Act. We therefore will not distribute your personal information to outside parties without your consent.\r\n<h3>Childrens Online Privacy Protection Act Compliance</h3>\r\nWe are in compliance with the requirements of COPPA (Childrens Online Privacy Protection Act), we do not collect any information from anyone under 13 years of age. Our website, products and services are all directed to people who are at least 13 years old or older.\r\n<h3>Online Privacy Policy Only</h3>\r\nThis online privacy policy applies only to information collected through our website and not to information collected offline.\r\n<h3>Your Consent</h3>\r\nBy using our site, you consent to our web site privacy policy.\r\n<h3>Changes to our Privacy Policy</h3>\r\nIf we decide to change our privacy policy, we will post those changes on this page, and/or update the Privacy Policy modification date below.\r\n\r\nThis policy was last modified on 2/25/2014\r\n<h3>Contacting Us</h3>\r\nIf there are any questions regarding this privacy policy you may contact us using the information below.\r\n\r\nhttp://nick.bronsonrocktx.com\r\n\r\nXstream Inspections\r\nshelly@dev.bronsonrocktx.com\r\n\r\n</div>', ' Privacy Policy', '', 'inherit', 'open', 'open', '', '20-revision-v1', '', '', '2014-03-24 20:19:35', '2014-03-25 02:19:35', '', 20, 'http://nick.bronsonrocktx.com/20-revision-v1/', 0, 'revision', '', 0),
(349, 1, '2014-05-07 14:20:56', '2014-05-07 20:20:56', '', 'Live', '', 'publish', 'closed', 'closed', '', 'live', '', '', '2014-08-13 13:03:49', '2014-08-13 19:03:49', '', 0, 'http://nick.bronsonrocktx.com/live/', 14, 'page', '', 0),
(350, 1, '2014-05-07 14:20:56', '2014-05-07 20:20:56', 'Content coming soon. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam ac hendrerit massa, in lacinia tellus. Pellentesque volutpat enim bibendum nisl rutrum eleifend. Curabitur eleifend accumsan libero a hendrerit. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aliquam placerat quam ac turpis tempor interdum. Nam dignissim augue non malesuada bibendum. Donec vitae orci erat. Sed congue ligula sed quam hendrerit iaculis. Nulla fringilla est volutpat sem tempor, at sagittis dui fringilla. In hac habitasse platea dictumst. Donec porttitor iaculis sapien eu sagittis. Vivamus sem neque, porttitor eu enim in, lacinia porta lectus.\r\n\r\nAenean fermentum mauris a nunc consectetur, vitae viverra eros imperdiet. Etiam vulputate nisl sed elementum rhoncus. Vestibulum varius, tortor blandit feugiat porttitor, mauris diam lobortis arcu, ultricies consequat nisl massa eget purus. Sed nec massa eu orci consequat egestas. Sed nec fringilla diam. Nunc fringilla, nulla venenatis congue facilisis, nisl sapien pharetra magna, quis tempus arcu libero consectetur leo. Duis volutpat in purus id vehicula. Mauris sed dui ut elit fringilla mattis. Cras vel enim quam. Nullam dapibus blandit lorem, sit amet fermentum felis hendrerit at. Vivamus porttitor leo mauris, ut laoreet felis varius posuere. Donec pharetra risus ac felis feugiat, eget vulputate elit ullamcorper. Curabitur sodales suscipit sem nec varius. Pellentesque libero lectus, luctus at justo vel, laoreet ullamcorper lacus. Duis vestibulum hendrerit ipsum, in lacinia turpis venenatis sit amet.', 'Specials', '', 'publish', 'closed', 'open', '', 'specials', '', '', '2014-05-08 15:29:33', '2014-05-08 21:29:33', '', 0, 'http://nick.bronsonrocktx.com/specials/', 15, 'page', '', 0),
(351, 1, '2014-05-07 14:20:56', '2014-05-07 20:20:56', '<h2>Rockin\' Starters</h2>\r\n<h3>Potato Skins   $9.29</h3>\r\nFried skins topped with mixed cheese &amp; bacon. Served with sour cream.\r\n<h3>Flat Bread Margarita Pizza   $8.29</h3>\r\nWood fired flat bread, topped with marinara, roasted tomatoes, fresh basil, blended mozzarella cheese, drizzled with a sweet basalmic glaze.\r\n<h3>Loaded Nachos  $8.99</h3>\r\nChips, queso, beans, lettuce, tomato, onions, guacamole, sour cream &amp; pickled jalapenos.\r\nGround beef or grilled chicken can be added for $1.99\r\n<h3>Wings (one pound)   $8.99</h3>\r\nLemon Pepper, BBQ, Teriyaki, Garlic, Parmesan, Buffalo (mild, hot, extra hot), Sweet Chili\r\n<h3>Fried Mozzarella  $8.29</h3>\r\n<h3>Jalapeño Poppers  $7.99</h3>\r\n<h3>Basket of Fries  $3.99</h3>\r\n<h3>Beer-Battered Onion Rings  $6.99</h3>\r\n<h3>Tempura-Battered Mushrooms  $7.29</h3>\r\n<h3>Chips &amp; Fire-Roasted Salsa  $5.99</h3>\r\nAdd queso $2.49\r\n<h3>Locked &amp; Loaded Fries   $7.99</h3>\r\n<h3>Queso Cheese, Bacon Crumbles, &amp; Pickled Jalapenos</h3>\r\nServed with ranch dressing.\r\n<h2>Wood-Fired Burgers</h2>\r\nHandmade burgers seasoned &amp; grilled over a wood flame &amp; slapped on a toasted poppy seed bun. Served with a handful of fries (or upgrade to Onion Rings, Locked &amp; Loaded fries, or Salad)\r\n<h3>The Bronson  $9.99</h3>\r\nCheddar cheese, smoked bacon, grilled onions &amp; jalapenos. LTP w/house dressing\r\n<h3>Classic Rock Burger   $8.49</h3>\r\nLTOP with mustard\r\n<h3>Pig Sleeping on a Rock $9.99</h3>\r\nCheddar cheese &amp; smoked bacon, LTOP, w/mayo &amp; mustard\r\n<h3>The Hendrix  $8.99</h3>\r\nSwiss cheese, grilled mushrooms, LTO w/mayo\r\n<h3>The Duke  $9.99</h3>\r\nPepper Jack cheese, guacamole &amp; smoked bacon, LTO w/mayo\r\n<h3>Bleu’s Burger   $8.99</h3>\r\nBleu cheese crumbles, tangy BBQ sauce, LTOP w/mayo\r\n<h3>Hippie Hallow (Veggie Burger)  $8.29</h3>\r\nPepper Jack cheese, roasted peppers, sautéed mushrooms, LTOP w/chipotle mayo\r\n*we also offer a Portabello mushroom substitute\r\n<h3>Hawaiian Burger   $9.99</h3>\r\nSmoked bacon, grilled pineapple, LTO w/tangy chili sauce &amp; mayo\r\n<h3>The Barnyard Brawl  $9.99</h3>\r\nAmerican cheese, smoked bacon, hash browns and a fried egg, LTO w/mayo\r\n<h3>The Roadie  $9.99</h3>\r\nCheddar cheese, smoked bacon, fried onions, tangy BBQ sauce, LTO w/mayo\r\n<h2>Sandwiches</h2>\r\n<h3>The Yardbird  $8.99</h3>\r\nSeasoned &amp; grilled chicken, swiss cheese, LTOP w/chipotle mayo\r\n<h3>Rockin’ Reuben  $8.29</h3>\r\nPastrami, sour kraut, swiss, thousand island, all melted on marble rye\r\n<h3>Acoustic Act  $8.99</h3>\r\nTender sliced turkey, smoked bacon, swiss, lettuce, tomato, w/avocado mayo on marble rye.\r\n<h3>French Dip   $9.99</h3>\r\nThinly sliced Rib-eye steak, seasoned &amp; grilled. Topped with swiss cheese on a toasted poppy seed roll w/au jus dipping sauce\r\n<h3>Fish Sandwich   $8.99</h3>\r\nBlackened tilapia, LTOP w/chipotle mayo on poppy seed bun\r\n<h2>Salads</h2>\r\nServed w/Ranch, Bleu Cheese, Balsamic Vinaigrette, Honey Mustard, Thousand Island, Caesar, or Chipotle Ranch\r\nAdd grilled or crispy chicken $1.99    Add blackened Tilapia $2.99\r\n<h3>Dinner Salad  $6.99</h3>\r\nRomaine lettuce, mixed cheese, tomato, red onions &amp; croutons\r\n<h3>Caesar Salad   $7.29</h3>\r\nCrisp romaine lettuce, parmesan cheese, &amp; croutons, tossed in a creamy caesar dressing\r\n<h3>Buffalo Chicken Salad   $8.99</h3>\r\nRomaine lettuce, mixed cheese, tomato, red onions, bleu cheese crumbles, &amp; crispy buffalo chicken\r\n<h2>Dessert</h2>\r\n<h3>Brownie bottom Sunday $5.29</h3>\r\nWarm chocolate brownie covered with vanilla ice cream, whipped cream, caramel &amp; raspberry sauce\r\n<h2>Draft Beers</h2>\r\n<h3>Miller Lite</h3>\r\n<h3>Coors Light</h3>\r\n<h3>Bud Light</h3>\r\n<h3>Michelob Ultra</h3>\r\n<h3>Dos XX’s Lager</h3>\r\n<h3>Sam Adams</h3>\r\n<h3>Blue Moon</h3>\r\n<h2>Bottled Beers</h2>\r\n<h3>Budweiser</h3>\r\n<h3>Bud Light</h3>\r\n<h3>Miller Lite</h3>\r\n<h3>Coors Light</h3>\r\n<h3>Michelob Ultra</h3>\r\n<h3>Corona</h3>\r\n<h3>--</h3>\r\n<h3>Corona Light</h3>\r\n<h3>Red Bridge (Gluten Free)</h3>\r\n<h3>Dos XX’s</h3>\r\n<h3>Heineken</h3>\r\n<h3>Guinness</h3>\r\n<h3>Red’s Apple Ale</h3>\r\n&nbsp;\r\n<h2>Signature Cocktails</h2>\r\n<h3>Love Junk</h3>\r\nAbsolut Vodka, peach schnapps, melon liquor, pineapple juice\r\n<h3>B*#CH ON WHEELS</h3>\r\nAmaretto, Malibu Rum, Sprite &amp; pineapple juice\r\n<h3>Rock Hard Rita (Top Shelf)</h3>\r\nPatron Tequila, Gran Marnier, topped off with fresh lime juice\r\n<h3>Grape Ape</h3>\r\nBlue Curacao, grape vodka, cranberry juice &amp; Sprite\r\n<h3>Bronson Bloody Mary</h3>\r\nPerfect blend of  vodka, spices, and our signature mix\r\n<h3>Mimosa (Sundays only)</h3>\r\nChampagne &amp; orange juice\r\n<h2>Frozen Margaritas</h2>\r\n<h3>Bronson Frozen Margarita</h3>\r\n<h3>Italian Margarita (Amaretto)</h3>\r\n<h3>Blue Bayou Margarita (Curacao)</h3>\r\n<h3>Peachy Keen Margarita (Peach Schnapps)</h3>\r\n<h3>Orange Blossom Margarita (Gran Marnier)</h3>\r\n<h3>Spanish Margarita (Sangria)</h3>\r\n<h3>Melon Margarita (Melon Liquor)</h3>\r\n<h3>Suicide Margarita\r\n(All of the Above!)</h3>\r\n<h2>Wine</h2>\r\n<h3>White (Glass)</h3>\r\nHouse Chardonnay\r\n\r\nHouse Moscato\r\n\r\nHouse Pinot Grigio\r\n\r\nHouse White Zinfandel\r\n\r\nPremium Chardonnay\r\n<h3>Red (Glass)</h3>\r\nHouse Cabernet\r\n\r\nHouse Merlot\r\n\r\nPremium Cabernet\r\n\r\nPremium Merlot\r\n<h3>Bottle</h3>\r\nJ. Lohr Merlot\r\n\r\nCasillero Del Diablo\r\n\r\nCabernet\r\n\r\nJosh Chardonnay\r\n\r\n* ask your server for details on wine\r\n\r\n&nbsp;\r\n<h2>Carry-Out Available</h2>\r\nCall 817-431-5543\r\n\r\n&nbsp;', 'Menu', '', 'publish', 'closed', 'open', '', 'menu', '', '', '2014-05-23 09:15:22', '2014-05-23 15:15:22', '', 0, 'http://nick.bronsonrocktx.com/menu/', 16, 'page', '', 0),
(352, 1, '2014-05-07 14:20:56', '2014-05-07 20:20:56', 'Content coming soon. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam ac hendrerit massa, in lacinia tellus. Pellentesque volutpat enim bibendum nisl rutrum eleifend. Curabitur eleifend accumsan libero a hendrerit. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aliquam placerat quam ac turpis tempor interdum. Nam dignissim augue non malesuada bibendum. Donec vitae orci erat. Sed congue ligula sed quam hendrerit iaculis. Nulla fringilla est volutpat sem tempor, at sagittis dui fringilla. In hac habitasse platea dictumst. Donec porttitor iaculis sapien eu sagittis. Vivamus sem neque, porttitor eu enim in, lacinia porta lectus.\r\n\r\nAenean fermentum mauris a nunc consectetur, vitae viverra eros imperdiet. Etiam vulputate nisl sed elementum rhoncus. Vestibulum varius, tortor blandit feugiat porttitor, mauris diam lobortis arcu, ultricies consequat nisl massa eget purus. Sed nec massa eu orci consequat egestas. Sed nec fringilla diam. Nunc fringilla, nulla venenatis congue facilisis, nisl sapien pharetra magna, quis tempus arcu libero consectetur leo. Duis volutpat in purus id vehicula. Mauris sed dui ut elit fringilla mattis. Cras vel enim quam. Nullam dapibus blandit lorem, sit amet fermentum felis hendrerit at. Vivamus porttitor leo mauris, ut laoreet felis varius posuere. Donec pharetra risus ac felis feugiat, eget vulputate elit ullamcorper. Curabitur sodales suscipit sem nec varius. Pellentesque libero lectus, luctus at justo vel, laoreet ullamcorper lacus. Duis vestibulum hendrerit ipsum, in lacinia turpis venenatis sit amet.', 'Pics', '', 'publish', 'closed', 'open', '', 'pics', '', '', '2014-05-08 15:29:33', '2014-05-08 21:29:33', '', 0, 'http://nick.bronsonrocktx.com/pics/', 17, 'page', '', 0),
(353, 1, '2014-05-07 14:20:56', '2014-05-07 20:20:56', 'Content coming soon. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam ac hendrerit massa, in lacinia tellus. Pellentesque volutpat enim bibendum nisl rutrum eleifend. Curabitur eleifend accumsan libero a hendrerit. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aliquam placerat quam ac turpis tempor interdum. Nam dignissim augue non malesuada bibendum. Donec vitae orci erat. Sed congue ligula sed quam hendrerit iaculis. Nulla fringilla est volutpat sem tempor, at sagittis dui fringilla. In hac habitasse platea dictumst. Donec porttitor iaculis sapien eu sagittis. Vivamus sem neque, porttitor eu enim in, lacinia porta lectus.\r\n\r\nAenean fermentum mauris a nunc consectetur, vitae viverra eros imperdiet. Etiam vulputate nisl sed elementum rhoncus. Vestibulum varius, tortor blandit feugiat porttitor, mauris diam lobortis arcu, ultricies consequat nisl massa eget purus. Sed nec massa eu orci consequat egestas. Sed nec fringilla diam. Nunc fringilla, nulla venenatis congue facilisis, nisl sapien pharetra magna, quis tempus arcu libero consectetur leo. Duis volutpat in purus id vehicula. Mauris sed dui ut elit fringilla mattis. Cras vel enim quam. Nullam dapibus blandit lorem, sit amet fermentum felis hendrerit at. Vivamus porttitor leo mauris, ut laoreet felis varius posuere. Donec pharetra risus ac felis feugiat, eget vulputate elit ullamcorper. Curabitur sodales suscipit sem nec varius. Pellentesque libero lectus, luctus at justo vel, laoreet ullamcorper lacus. Duis vestibulum hendrerit ipsum, in lacinia turpis venenatis sit amet.', 'Location', '', 'publish', 'closed', 'open', '', 'location', '', '', '2014-05-08 15:29:33', '2014-05-08 21:29:33', '', 0, 'http://nick.bronsonrocktx.com/location/', 18, 'page', '', 0),
(354, 1, '2014-05-07 14:20:56', '2014-05-07 20:20:56', 'Content coming soon. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam ac hendrerit massa, in lacinia tellus. Pellentesque volutpat enim bibendum nisl rutrum eleifend. Curabitur eleifend accumsan libero a hendrerit. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aliquam placerat quam ac turpis tempor interdum. Nam dignissim augue non malesuada bibendum. Donec vitae orci erat. Sed congue ligula sed quam hendrerit iaculis. Nulla fringilla est volutpat sem tempor, at sagittis dui fringilla. In hac habitasse platea dictumst. Donec porttitor iaculis sapien eu sagittis. Vivamus sem neque, porttitor eu enim in, lacinia porta lectus.\r\n\r\nAenean fermentum mauris a nunc consectetur, vitae viverra eros imperdiet. Etiam vulputate nisl sed elementum rhoncus. Vestibulum varius, tortor blandit feugiat porttitor, mauris diam lobortis arcu, ultricies consequat nisl massa eget purus. Sed nec massa eu orci consequat egestas. Sed nec fringilla diam. Nunc fringilla, nulla venenatis congue facilisis, nisl sapien pharetra magna, quis tempus arcu libero consectetur leo. Duis volutpat in purus id vehicula. Mauris sed dui ut elit fringilla mattis. Cras vel enim quam. Nullam dapibus blandit lorem, sit amet fermentum felis hendrerit at. Vivamus porttitor leo mauris, ut laoreet felis varius posuere. Donec pharetra risus ac felis feugiat, eget vulputate elit ullamcorper. Curabitur sodales suscipit sem nec varius. Pellentesque libero lectus, luctus at justo vel, laoreet ullamcorper lacus. Duis vestibulum hendrerit ipsum, in lacinia turpis venenatis sit amet.', 'Hours', '', 'publish', 'closed', 'open', '', 'hours', '', '', '2014-05-08 15:29:33', '2014-05-08 21:29:33', '', 0, 'http://nick.bronsonrocktx.com/hours/', 19, 'page', '', 0),
(355, 1, '2014-05-07 14:24:26', '2014-05-07 20:24:26', ' ', '', '', 'publish', 'open', 'open', '', '355', '', '', '2014-05-08 09:32:56', '2014-05-08 15:32:56', '', 0, 'http://nick.bronsonrocktx.com/?p=355', 2, 'nav_menu_item', '', 0),
(356, 1, '2014-05-07 14:23:56', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-05-07 14:23:56', '0000-00-00 00:00:00', '', 0, 'http://nick.bronsonrocktx.com/?p=356', 1, 'nav_menu_item', '', 0),
(357, 1, '2014-05-07 14:24:26', '2014-05-07 20:24:26', ' ', '', '', 'publish', 'open', 'open', '', '357', '', '', '2014-05-08 09:32:56', '2014-05-08 15:32:56', '', 0, 'http://nick.bronsonrocktx.com/?p=357', 8, 'nav_menu_item', '', 0),
(360, 1, '2014-05-07 14:24:26', '2014-05-07 20:24:26', '', 'Live!', '', 'publish', 'open', 'open', '', '360', '', '', '2014-05-08 09:32:56', '2014-05-08 15:32:56', '', 0, 'http://nick.bronsonrocktx.com/?p=360', 1, 'nav_menu_item', '', 0),
(361, 1, '2014-05-07 14:24:26', '2014-05-07 20:24:26', ' ', '', '', 'publish', 'open', 'open', '', '361', '', '', '2014-05-08 09:32:56', '2014-05-08 15:32:56', '', 0, 'http://nick.bronsonrocktx.com/?p=361', 4, 'nav_menu_item', '', 0),
(362, 1, '2014-05-07 14:24:26', '2014-05-07 20:24:26', ' ', '', '', 'publish', 'open', 'open', '', '362', '', '', '2014-05-08 09:32:56', '2014-05-08 15:32:56', '', 0, 'http://nick.bronsonrocktx.com/?p=362', 3, 'nav_menu_item', '', 0),
(363, 1, '2014-05-07 14:24:26', '2014-05-07 20:24:26', ' ', '', '', 'publish', 'open', 'open', '', '363', '', '', '2014-05-08 09:32:56', '2014-05-08 15:32:56', '', 0, 'http://nick.bronsonrocktx.com/?p=363', 5, 'nav_menu_item', '', 0),
(364, 1, '2014-05-07 14:24:26', '2014-05-07 20:24:26', ' ', '', '', 'publish', 'open', 'open', '', '364', '', '', '2014-05-08 09:32:56', '2014-05-08 15:32:56', '', 0, 'http://nick.bronsonrocktx.com/?p=364', 6, 'nav_menu_item', '', 0),
(365, 1, '2014-05-07 14:24:26', '2014-05-07 20:24:26', ' ', '', '', 'publish', 'open', 'open', '', '365', '', '', '2014-05-08 09:32:56', '2014-05-08 15:32:56', '', 0, 'http://nick.bronsonrocktx.com/?p=365', 7, 'nav_menu_item', '', 0),
(366, 1, '2014-05-08 15:29:33', '2014-05-08 21:29:33', 'Content coming soon. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam ac hendrerit massa, in lacinia tellus. Pellentesque volutpat enim bibendum nisl rutrum eleifend. Curabitur eleifend accumsan libero a hendrerit. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aliquam placerat quam ac turpis tempor interdum. Nam dignissim augue non malesuada bibendum. Donec vitae orci erat. Sed congue ligula sed quam hendrerit iaculis. Nulla fringilla est volutpat sem tempor, at sagittis dui fringilla. In hac habitasse platea dictumst. Donec porttitor iaculis sapien eu sagittis. Vivamus sem neque, porttitor eu enim in, lacinia porta lectus.\r\n\r\nAenean fermentum mauris a nunc consectetur, vitae viverra eros imperdiet. Etiam vulputate nisl sed elementum rhoncus. Vestibulum varius, tortor blandit feugiat porttitor, mauris diam lobortis arcu, ultricies consequat nisl massa eget purus. Sed nec massa eu orci consequat egestas. Sed nec fringilla diam. Nunc fringilla, nulla venenatis congue facilisis, nisl sapien pharetra magna, quis tempus arcu libero consectetur leo. Duis volutpat in purus id vehicula. Mauris sed dui ut elit fringilla mattis. Cras vel enim quam. Nullam dapibus blandit lorem, sit amet fermentum felis hendrerit at. Vivamus porttitor leo mauris, ut laoreet felis varius posuere. Donec pharetra risus ac felis feugiat, eget vulputate elit ullamcorper. Curabitur sodales suscipit sem nec varius. Pellentesque libero lectus, luctus at justo vel, laoreet ullamcorper lacus. Duis vestibulum hendrerit ipsum, in lacinia turpis venenatis sit amet.', 'Live', '', 'inherit', 'open', 'open', '', '349-revision-v1', '', '', '2014-05-08 15:29:33', '2014-05-08 21:29:33', '', 349, 'http://nick.bronsonrocktx.com/349-revision-v1/', 0, 'revision', '', 0),
(367, 1, '2014-05-08 15:29:33', '2014-05-08 21:29:33', 'Content coming soon. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam ac hendrerit massa, in lacinia tellus. Pellentesque volutpat enim bibendum nisl rutrum eleifend. Curabitur eleifend accumsan libero a hendrerit. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aliquam placerat quam ac turpis tempor interdum. Nam dignissim augue non malesuada bibendum. Donec vitae orci erat. Sed congue ligula sed quam hendrerit iaculis. Nulla fringilla est volutpat sem tempor, at sagittis dui fringilla. In hac habitasse platea dictumst. Donec porttitor iaculis sapien eu sagittis. Vivamus sem neque, porttitor eu enim in, lacinia porta lectus.\r\n\r\nAenean fermentum mauris a nunc consectetur, vitae viverra eros imperdiet. Etiam vulputate nisl sed elementum rhoncus. Vestibulum varius, tortor blandit feugiat porttitor, mauris diam lobortis arcu, ultricies consequat nisl massa eget purus. Sed nec massa eu orci consequat egestas. Sed nec fringilla diam. Nunc fringilla, nulla venenatis congue facilisis, nisl sapien pharetra magna, quis tempus arcu libero consectetur leo. Duis volutpat in purus id vehicula. Mauris sed dui ut elit fringilla mattis. Cras vel enim quam. Nullam dapibus blandit lorem, sit amet fermentum felis hendrerit at. Vivamus porttitor leo mauris, ut laoreet felis varius posuere. Donec pharetra risus ac felis feugiat, eget vulputate elit ullamcorper. Curabitur sodales suscipit sem nec varius. Pellentesque libero lectus, luctus at justo vel, laoreet ullamcorper lacus. Duis vestibulum hendrerit ipsum, in lacinia turpis venenatis sit amet.', 'Specials', '', 'inherit', 'open', 'open', '', '350-revision-v1', '', '', '2014-05-08 15:29:33', '2014-05-08 21:29:33', '', 350, 'http://nick.bronsonrocktx.com/350-revision-v1/', 0, 'revision', '', 0),
(368, 1, '2014-05-08 15:29:33', '2014-05-08 21:29:33', 'Content coming soon. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam ac hendrerit massa, in lacinia tellus. Pellentesque volutpat enim bibendum nisl rutrum eleifend. Curabitur eleifend accumsan libero a hendrerit. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aliquam placerat quam ac turpis tempor interdum. Nam dignissim augue non malesuada bibendum. Donec vitae orci erat. Sed congue ligula sed quam hendrerit iaculis. Nulla fringilla est volutpat sem tempor, at sagittis dui fringilla. In hac habitasse platea dictumst. Donec porttitor iaculis sapien eu sagittis. Vivamus sem neque, porttitor eu enim in, lacinia porta lectus.\r\n\r\nAenean fermentum mauris a nunc consectetur, vitae viverra eros imperdiet. Etiam vulputate nisl sed elementum rhoncus. Vestibulum varius, tortor blandit feugiat porttitor, mauris diam lobortis arcu, ultricies consequat nisl massa eget purus. Sed nec massa eu orci consequat egestas. Sed nec fringilla diam. Nunc fringilla, nulla venenatis congue facilisis, nisl sapien pharetra magna, quis tempus arcu libero consectetur leo. Duis volutpat in purus id vehicula. Mauris sed dui ut elit fringilla mattis. Cras vel enim quam. Nullam dapibus blandit lorem, sit amet fermentum felis hendrerit at. Vivamus porttitor leo mauris, ut laoreet felis varius posuere. Donec pharetra risus ac felis feugiat, eget vulputate elit ullamcorper. Curabitur sodales suscipit sem nec varius. Pellentesque libero lectus, luctus at justo vel, laoreet ullamcorper lacus. Duis vestibulum hendrerit ipsum, in lacinia turpis venenatis sit amet.', 'Menu', '', 'inherit', 'open', 'open', '', '351-revision-v1', '', '', '2014-05-08 15:29:33', '2014-05-08 21:29:33', '', 351, 'http://nick.bronsonrocktx.com/351-revision-v1/', 0, 'revision', '', 0),
(369, 1, '2014-05-08 15:29:33', '2014-05-08 21:29:33', 'Content coming soon. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam ac hendrerit massa, in lacinia tellus. Pellentesque volutpat enim bibendum nisl rutrum eleifend. Curabitur eleifend accumsan libero a hendrerit. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aliquam placerat quam ac turpis tempor interdum. Nam dignissim augue non malesuada bibendum. Donec vitae orci erat. Sed congue ligula sed quam hendrerit iaculis. Nulla fringilla est volutpat sem tempor, at sagittis dui fringilla. In hac habitasse platea dictumst. Donec porttitor iaculis sapien eu sagittis. Vivamus sem neque, porttitor eu enim in, lacinia porta lectus.\r\n\r\nAenean fermentum mauris a nunc consectetur, vitae viverra eros imperdiet. Etiam vulputate nisl sed elementum rhoncus. Vestibulum varius, tortor blandit feugiat porttitor, mauris diam lobortis arcu, ultricies consequat nisl massa eget purus. Sed nec massa eu orci consequat egestas. Sed nec fringilla diam. Nunc fringilla, nulla venenatis congue facilisis, nisl sapien pharetra magna, quis tempus arcu libero consectetur leo. Duis volutpat in purus id vehicula. Mauris sed dui ut elit fringilla mattis. Cras vel enim quam. Nullam dapibus blandit lorem, sit amet fermentum felis hendrerit at. Vivamus porttitor leo mauris, ut laoreet felis varius posuere. Donec pharetra risus ac felis feugiat, eget vulputate elit ullamcorper. Curabitur sodales suscipit sem nec varius. Pellentesque libero lectus, luctus at justo vel, laoreet ullamcorper lacus. Duis vestibulum hendrerit ipsum, in lacinia turpis venenatis sit amet.', 'Pics', '', 'inherit', 'open', 'open', '', '352-revision-v1', '', '', '2014-05-08 15:29:33', '2014-05-08 21:29:33', '', 352, 'http://nick.bronsonrocktx.com/352-revision-v1/', 0, 'revision', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(370, 1, '2014-05-08 15:29:33', '2014-05-08 21:29:33', 'Content coming soon. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam ac hendrerit massa, in lacinia tellus. Pellentesque volutpat enim bibendum nisl rutrum eleifend. Curabitur eleifend accumsan libero a hendrerit. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aliquam placerat quam ac turpis tempor interdum. Nam dignissim augue non malesuada bibendum. Donec vitae orci erat. Sed congue ligula sed quam hendrerit iaculis. Nulla fringilla est volutpat sem tempor, at sagittis dui fringilla. In hac habitasse platea dictumst. Donec porttitor iaculis sapien eu sagittis. Vivamus sem neque, porttitor eu enim in, lacinia porta lectus.\r\n\r\nAenean fermentum mauris a nunc consectetur, vitae viverra eros imperdiet. Etiam vulputate nisl sed elementum rhoncus. Vestibulum varius, tortor blandit feugiat porttitor, mauris diam lobortis arcu, ultricies consequat nisl massa eget purus. Sed nec massa eu orci consequat egestas. Sed nec fringilla diam. Nunc fringilla, nulla venenatis congue facilisis, nisl sapien pharetra magna, quis tempus arcu libero consectetur leo. Duis volutpat in purus id vehicula. Mauris sed dui ut elit fringilla mattis. Cras vel enim quam. Nullam dapibus blandit lorem, sit amet fermentum felis hendrerit at. Vivamus porttitor leo mauris, ut laoreet felis varius posuere. Donec pharetra risus ac felis feugiat, eget vulputate elit ullamcorper. Curabitur sodales suscipit sem nec varius. Pellentesque libero lectus, luctus at justo vel, laoreet ullamcorper lacus. Duis vestibulum hendrerit ipsum, in lacinia turpis venenatis sit amet.', 'Location', '', 'inherit', 'open', 'open', '', '353-revision-v1', '', '', '2014-05-08 15:29:33', '2014-05-08 21:29:33', '', 353, 'http://nick.bronsonrocktx.com/353-revision-v1/', 0, 'revision', '', 0),
(371, 1, '2014-05-08 15:29:33', '2014-05-08 21:29:33', 'Content coming soon. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam ac hendrerit massa, in lacinia tellus. Pellentesque volutpat enim bibendum nisl rutrum eleifend. Curabitur eleifend accumsan libero a hendrerit. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aliquam placerat quam ac turpis tempor interdum. Nam dignissim augue non malesuada bibendum. Donec vitae orci erat. Sed congue ligula sed quam hendrerit iaculis. Nulla fringilla est volutpat sem tempor, at sagittis dui fringilla. In hac habitasse platea dictumst. Donec porttitor iaculis sapien eu sagittis. Vivamus sem neque, porttitor eu enim in, lacinia porta lectus.\r\n\r\nAenean fermentum mauris a nunc consectetur, vitae viverra eros imperdiet. Etiam vulputate nisl sed elementum rhoncus. Vestibulum varius, tortor blandit feugiat porttitor, mauris diam lobortis arcu, ultricies consequat nisl massa eget purus. Sed nec massa eu orci consequat egestas. Sed nec fringilla diam. Nunc fringilla, nulla venenatis congue facilisis, nisl sapien pharetra magna, quis tempus arcu libero consectetur leo. Duis volutpat in purus id vehicula. Mauris sed dui ut elit fringilla mattis. Cras vel enim quam. Nullam dapibus blandit lorem, sit amet fermentum felis hendrerit at. Vivamus porttitor leo mauris, ut laoreet felis varius posuere. Donec pharetra risus ac felis feugiat, eget vulputate elit ullamcorper. Curabitur sodales suscipit sem nec varius. Pellentesque libero lectus, luctus at justo vel, laoreet ullamcorper lacus. Duis vestibulum hendrerit ipsum, in lacinia turpis venenatis sit amet.', 'Hours', '', 'inherit', 'open', 'open', '', '354-revision-v1', '', '', '2014-05-08 15:29:33', '2014-05-08 21:29:33', '', 354, 'http://nick.bronsonrocktx.com/354-revision-v1/', 0, 'revision', '', 0),
(372, 1, '2014-05-08 15:31:33', '2014-05-08 21:31:33', '', ' Contact Us', '', 'inherit', 'open', 'open', '', '17-revision-v1', '', '', '2014-05-08 15:31:33', '2014-05-08 21:31:33', '', 17, 'http://nick.bronsonrocktx.com/17-revision-v1/', 0, 'revision', '', 0),
(373, 1, '2014-05-08 15:32:03', '2014-05-08 21:32:03', '<h3>What information do we collect?</h3>\r\n<div>\r\n\r\nWe collect information from you when you register on our site, place an order, subscribe to our newsletter, respond to a survey, fill out a form or send band information.\r\n\r\nWhen ordering or registering on our site, as appropriate, you may be asked to enter your: name, e-mail address, mailing address or phone number. You may, however, visit our site anonymously.\r\n<h3>What do we use your information for?</h3>\r\nAny of the information we collect from you may be used in one of the following ways:\r\n\r\n; To personalize your experience\r\n(your information helps us to better respond to your individual needs)\r\n\r\n; To improve our website\r\n(we continually strive to improve our website offerings based on the information and feedback we receive from you)\r\n\r\n; To improve customer service\r\n(your information helps us to more effectively respond to your customer service requests and support needs)\r\n\r\n; To administer a contest, promotion, survey or other site feature\r\n\r\n; To send periodic emails\r\n<blockquote>The email address you provide for order processing, may be used to send you information and updates pertaining to your order, in addition to receiving occasional company news, updates, related product or service information, etc.</blockquote>\r\nNote: If at any time you would like to unsubscribe from receiving future emails, we include detailed unsubscribe instructions at the bottom of each email.\r\n<h3>How do we protect your information?</h3>\r\nWe implement a variety of security measures to maintain the safety of your personal information when you place an order or enter, submit, or access your personal information.\r\n\r\nWe offer the use of a secure server. All supplied sensitive/credit information is transmitted via Secure Socket Layer (SSL) technology and then encrypted into our Payment gateway providers database only to be accessible by those authorized with special access rights to such systems, and are required to?keep the information confidential.\r\n\r\nAfter a transaction, your private information (credit cards, social security numbers, financials, etc.) will not be stored on our servers.\r\n<h3>Do we use cookies?</h3>\r\nYes (Cookies are small files that a site or its service provider transfers to your computers hard drive through your Web browser (if you allow) that enables the sites or service providers systems to recognize your browser and capture and remember certain information\r\n\r\nWe use cookies to understand and save your preferences for future visits, keep track of advertisements and compile aggregate data about site traffic and site interaction so that we can offer better site experiences and tools in the future. We may contract with third-party service providers to assist us in better understanding our site visitors. These service providers are not permitted to use the information collected on our behalf except to help us conduct and improve our business.\r\n\r\nIf you prefer, you can choose to have your computer warn you each time a cookie is being sent, or you can choose to turn off all cookies via your browser settings. Like most websites, if you turn your cookies off, some of our services may not function properly. However, you can still place orders over the telephone or by contacting customer service.\r\n<h3>Do we disclose any information to outside parties?</h3>\r\nWe do not sell, trade, or otherwise transfer to outside parties your personally identifiable information. This does not include trusted third parties who assist us in operating our website, conducting our business, or servicing you, so long as those parties agree to keep this information confidential. We may also release your information when we believe release is appropriate to comply with the law, enforce our site policies, or protect ours or others rights, property, or safety. However, non-personally identifiable visitor information may be provided to other parties for marketing, advertising, or other uses.\r\n<h3>Third party links</h3>\r\nOccasionally, at our discretion, we may include or offer third party products or services on our website. These third party sites have separate and independent privacy policies. We therefore have no responsibility or liability for the content and activities of these linked sites. Nonetheless, we seek to protect the integrity of our site and welcome any feedback about these sites.\r\n<h3>California Online Privacy Protection Act Compliance</h3>\r\nBecause we value your privacy we have taken the necessary precautions to be in compliance with the California Online Privacy Protection Act. We therefore will not distribute your personal information to outside parties without your consent.\r\n<h3>Childrens Online Privacy Protection Act Compliance</h3>\r\nWe are in compliance with the requirements of COPPA (Childrens Online Privacy Protection Act), we do not collect any information from anyone under 13 years of age. Our website, products and services are all directed to people who are at least 13 years old or older.\r\n<h3>Online Privacy Policy Only</h3>\r\nThis online privacy policy applies only to information collected through our website and not to information collected offline.\r\n<h3>Your Consent</h3>\r\nBy using our site, you consent to our web site privacy policy.\r\n<h3>Changes to our Privacy Policy</h3>\r\nIf we decide to change our privacy policy, we will post those changes on this page, and/or update the Privacy Policy modification date below.\r\n\r\nThis policy was last modified on 2/25/2014\r\n<h3>Contacting Us</h3>\r\nIf there are any questions regarding this privacy policy you may contact us using the information below.\r\n\r\nhttp://nick.bronsonrocktx.com\r\n\r\nBronson Rock\r\ninfo@dev.bronsonrocktx.com\r\n\r\n</div>', ' Privacy Policy', '', 'inherit', 'open', 'open', '', '20-revision-v1', '', '', '2014-05-08 15:32:03', '2014-05-08 21:32:03', '', 20, 'http://nick.bronsonrocktx.com/20-revision-v1/', 0, 'revision', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(374, 1, '2014-05-08 15:32:34', '2014-05-08 21:32:34', 'Content coming soon. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam ac hendrerit massa, in lacinia tellus. Pellentesque volutpat enim bibendum nisl rutrum eleifend. Curabitur eleifend accumsan libero a hendrerit. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aliquam placerat quam ac turpis tempor interdum. Nam dignissim augue non malesuada bibendum. Donec vitae orci erat. Sed congue ligula sed quam hendrerit iaculis. Nulla fringilla est volutpat sem tempor, at sagittis dui fringilla. In hac habitasse platea dictumst. Donec porttitor iaculis sapien eu sagittis. Vivamus sem neque, porttitor eu enim in, lacinia porta lectus.\r\n\r\nAenean fermentum mauris a nunc consectetur, vitae viverra eros imperdiet. Etiam vulputate nisl sed elementum rhoncus. Vestibulum varius, tortor blandit feugiat porttitor, mauris diam lobortis arcu, ultricies consequat nisl massa eget purus. Sed nec massa eu orci consequat egestas. Sed nec fringilla diam. Nunc fringilla, nulla venenatis congue facilisis, nisl sapien pharetra magna, quis tempus arcu libero consectetur leo. Duis volutpat in purus id vehicula. Mauris sed dui ut elit fringilla mattis. Cras vel enim quam. Nullam dapibus blandit lorem, sit amet fermentum felis hendrerit at. Vivamus porttitor leo mauris, ut laoreet felis varius posuere. Donec pharetra risus ac felis feugiat, eget vulputate elit ullamcorper. Curabitur sodales suscipit sem nec varius. Pellentesque libero lectus, luctus at justo vel, laoreet ullamcorper lacus. Duis vestibulum hendrerit ipsum, in lacinia turpis venenatis sit amet.', ' Contact Us', '', 'inherit', 'open', 'open', '', '17-revision-v1', '', '', '2014-05-08 15:32:34', '2014-05-08 21:32:34', '', 17, 'http://nick.bronsonrocktx.com/17-revision-v1/', 0, 'revision', '', 0),
(375, 1, '2014-05-08 15:32:43', '2014-05-08 21:32:43', 'Content coming soon. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam ac hendrerit massa, in lacinia tellus. Pellentesque volutpat enim bibendum nisl rutrum eleifend. Curabitur eleifend accumsan libero a hendrerit. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aliquam placerat quam ac turpis tempor interdum. Nam dignissim augue non malesuada bibendum. Donec vitae orci erat. Sed congue ligula sed quam hendrerit iaculis. Nulla fringilla est volutpat sem tempor, at sagittis dui fringilla. In hac habitasse platea dictumst. Donec porttitor iaculis sapien eu sagittis. Vivamus sem neque, porttitor eu enim in, lacinia porta lectus.\r\n\r\nAenean fermentum mauris a nunc consectetur, vitae viverra eros imperdiet. Etiam vulputate nisl sed elementum rhoncus. Vestibulum varius, tortor blandit feugiat porttitor, mauris diam lobortis arcu, ultricies consequat nisl massa eget purus. Sed nec massa eu orci consequat egestas. Sed nec fringilla diam. Nunc fringilla, nulla venenatis congue facilisis, nisl sapien pharetra magna, quis tempus arcu libero consectetur leo. Duis volutpat in purus id vehicula. Mauris sed dui ut elit fringilla mattis. Cras vel enim quam. Nullam dapibus blandit lorem, sit amet fermentum felis hendrerit at. Vivamus porttitor leo mauris, ut laoreet felis varius posuere. Donec pharetra risus ac felis feugiat, eget vulputate elit ullamcorper. Curabitur sodales suscipit sem nec varius. Pellentesque libero lectus, luctus at justo vel, laoreet ullamcorper lacus. Duis vestibulum hendrerit ipsum, in lacinia turpis venenatis sit amet.', ' Sitemap', '', 'inherit', 'open', 'open', '', '21-revision-v1', '', '', '2014-05-08 15:32:43', '2014-05-08 21:32:43', '', 21, 'http://nick.bronsonrocktx.com/21-revision-v1/', 0, 'revision', '', 0),
(377, 1, '2014-05-23 08:52:07', '2014-05-23 14:52:07', '<h2>Rockin\' Starters</h2>\n<h3>Potato Skins   $9.29</h3>\nFried skins topped with mixed cheese &amp; bacon. Served with sour cream.\n<h3>Flat Bread Margarita Pizza   $8.29</h3>\nWood fired flat bread, topped with marinara, roasted tomatoes, fresh basil, blended mozzarella cheese, drizzled with a sweet basalmic glaze.\n<h3>Loaded Nachos  $8.99</h3>\nChips, queso, beans, lettuce, tomato, onions, guacamole, sour cream &amp; pickled jalapenos.\nGround beef or grilled chicken can be added for $1.99\n<h3>Wings (one pound)   $8.99</h3>\nLemon Pepper, BBQ, Teriyaki, Garlic, Parmesan, Buffalo (mild, hot, extra hot), Sweet Chili\n<h3>Fried Mozzarella  $8.29</h3>\n<h3>Jalapeño Poppers  $7.99</h3>\n<h3>Basket of Fries  $3.99</h3>\n<h3>Beer-Battered Onion Rings  $6.99</h3>\n<h3>Tempura-Battered Mushrooms  $7.29</h3>\n<h3>Chips &amp; Fire-Roasted Salsa  $5.99</h3>\nAdd queso $2.49\n<h3>Locked &amp; Loaded Fries   $7.99</h3>\n<h3>Queso Cheese, Bacon Crumbles, &amp; Pickled Jalapenos</h3>\nServed with ranch dressing.\n<h2>Wood-Fired Burgers</h2>\nHandmade burgers seasoned &amp; grilled over a wood flame &amp; slapped on a toasted poppy seed bun. Served with a handful of fries (or upgrade to Onion Rings, Locked &amp; Loaded fries, or Salad)\n<h3>The Bronson  $9.99</h3>\nCheddar cheese, smoked bacon, grilled onions &amp; jalapenos. LTP w/house dressing\n<h3>Classic Rock Burger   $8.49</h3>\nLTOP with mustard\n<h3>Pig Sleeping on a Rock $9.99</h3>\nCheddar cheese &amp; smoked bacon, LTOP, w/mayo &amp; mustard\n<h3>The Hendrix  $8.99</h3>\nSwiss cheese, grilled mushrooms, LTO w/mayo\n<h3>The Duke  $9.99</h3>\nPepper Jack cheese, guacamole &amp; smoked bacon, LTO w/mayo\n<h3>Bleu’s Burger   $8.99</h3>\nBleu cheese crumbles, tangy BBQ sauce, LTOP w/mayo\n<h3>Hippie Hallow (Veggie Burger)  $8.29</h3>\nPepper Jack cheese, roasted peppers, sautéed mushrooms, LTOP w/chipotle mayo\n*we also offer a Portabello mushroom substitute\n<h3>Hawaiian Burger   $9.99</h3>\nSmoked bacon, grilled pineapple, LTO w/tangy chili sauce &amp; mayo\n<h3>The Barnyard Brawl  $9.99</h3>\nAmerican cheese, smoked bacon, hash browns and a fried egg, LTO w/mayo\n<h3>The Roadie  $9.99</h3>\nCheddar cheese, smoked bacon, fried onions, tangy BBQ sauce, LTO w/mayo\n<h2>Sandwiches</h2>\n<h3>The Yardbird  $8.99</h3>\nSeasoned &amp; grilled chicken, swiss cheese, LTOP w/chipotle mayo\n<h3>Rockin’ Reuben  $8.29</h3>\nPastrami, sour kraut, swiss, thousand island, all melted on marble rye\n<h3>Acoustic Act  $8.99</h3>\nTender sliced turkey, smoked bacon, swiss, lettuce, tomato, w/avocado mayo on marble rye.\n<h3>French Dip   $9.99</h3>\nThinly sliced Rib-eye steak, seasoned &amp; grilled. Topped with swiss cheese on a toasted poppy seed roll w/au jus dipping sauce\n<h3>Fish Sandwich   $8.99</h3>\nBlackened tilapia, LTOP w/chipotle mayo on poppy seed bun\n<h2>Salads</h2>\nServed w/Ranch, Bleu Cheese, Balsamic Vinaigrette, Honey Mustard, Thousand Island, Caesar, or Chipotle Ranch\nAdd grilled or crispy chicken $1.99    Add blackened Tilapia $2.99\n<h3>Dinner Salad  $6.99</h3>\nRomaine lettuce, mixed cheese, tomato, red onions &amp; croutons\n<h3>Caesar Salad   $7.29</h3>\nCrisp romaine lettuce, parmesan cheese, &amp; croutons, tossed in a creamy caesar dressing\n<h3>Buffalo Chicken Salad   $8.99</h3>\nRomaine lettuce, mixed cheese, tomato, red onions, bleu cheese crumbles, &amp; crispy buffalo chicken\n<h2>Dessert</h2>\n<h3>Brownie bottom Sunday $5.29</h3>\nWarm chocolate brownie covered with vanilla ice cream, whipped cream, caramel &amp; raspberry sauce\n<h2>Draft Beers</h2>\n<h3>Miller Lite</h3>\n<h3>Coors Light</h3>\n<h3>Bud Light</h3>\n<h3>Michelob Ultra</h3>\n<h3>Dos XX’s Lager</h3>\n<h3>Sam Adams</h3>\n<h3>Blue Moon</h3>\n<h2>Bottled Beers</h2>\n<h3>Budweiser</h3>\n<h3>Bud Light</h3>\n<h3>Miller Lite</h3>\n<h3>Coors Light</h3>\n<h3>Michelob Ultra</h3>\n<h3>Corona</h3>\n<h3>--</h3>\n<h3>Corona Light</h3>\n<h3>Red Bridge (Gluten Free)</h3>\n<h3>Dos XX’s</h3>\n<h3>Heineken</h3>\n<h3>Guinness</h3>\n<h3>Red’s Apple Ale</h3>\n&nbsp;\n<h2>Signature Cocktails</h2>\n<h3>Love Junk</h3>\nAbsolut Vodka, peach schnapps, melon liquor, pineapple juice\n<h3>B*#CH ON WHEELS</h3>\nAmaretto, Malibu Rum, Sprite &amp; pineapple juice\n<h3>Rock Hard Rita (Top Shelf)</h3>\nPatron Tequila, Gran Marnier, topped off with fresh lime juice\n<h3>Grape Ape</h3>\nBlue Curacao, grape vodka, cranberry juice &amp; Sprite\n<h3>Bronson Bloody Mary</h3>\nPerfect blend of  vodka, spices, and our signature mix\n<h3>Mimosa (Sundays only)</h3>\nChampagne &amp; orange juice\n<h2>Frozen Margaritas</h2>\n<h3>Bronson Frozen Margarita</h3>\n<h3>Italian Margarita (Amaretto)</h3>\n<h3>Blue Bayou Margarita (Curacao)</h3>\n<h3>Peachy Keen Margarita (Peach Schnapps)</h3>\n<h3>Orange Blossom Margarita (Gran Marnier)</h3>\n<h3>Spanish Margarita (Sangria)</h3>\n<h3>Melon Margarita (Melon Liquor)</h3>\n<h3>Suicide Margarita\n(All of the Above!)</h3>\n<h2>Wine</h2>\n<h3>White (Glass)</h3>\nHouse Chardonnay\n\nHouse Moscato\n\nHouse Pinot Grigio\n\nHouse White Zinfandel\n\nPremium Chardonnay\n<h3>Red (Glass)</h3>\nHouse Cabernet\n\nHouse Merlot\n\nPremium Cabernet\n\nPremium Merlot\n<h3>Bottle</h3>\nJ. Lohr Merlot\n\nCasillero Del Diablo\n\nCabernet\n\nJosh Chardonnay\n\n&nbsp;\n\n* ask your server for details on wine\n\n&nbsp;\n<h2>Carry-Out Available</h2>\nCall 817-431-5543\n\n&nbsp;', 'Menu', '', 'inherit', 'open', 'open', '', '351-autosave-v1', '', '', '2014-05-23 08:52:07', '2014-05-23 14:52:07', '', 351, 'http://nick.bronsonrocktx.com/351-autosave-v1/', 0, 'revision', '', 0),
(378, 1, '2014-05-23 08:28:45', '2014-05-23 14:28:45', '<h2>Rockin\' Starters</h2>\r\nPOTATO SKINS   $9.29\r\n\r\nFried skins topped with mixed cheese, bacon\r\n\r\nServed with sour cream\r\n\r\nFlat Bread Margarita Pizza   $8.29\r\n\r\nWood fired flat bread, topped with marinara, roasted tomatoes, fresh basil, blended mozzarella cheese, drizzled with a sweet basalmic glaze.\r\n\r\nloaded nachos  $8.99\r\n\r\nChips, queso, beans, lettuce, tomato, onions, guacamole, sour cream &amp; pickled jalapenos.\r\n\r\nGround beef or grilled chicken can be added for $1.99\r\n\r\nWings (one pound)   $8.99\r\n\r\nLemon Pepper, BBQ, Teriyaki,\r\nGarlic, Parmesan, Buffalo (mild,\r\n\r\nhot, extra hot), Sweet Chili\r\n\r\n&nbsp;\r\n\r\n&nbsp;\r\n\r\nfried mozzarella  $8.29\r\n\r\njalapeño poppers  $7.99\r\n\r\nbasket of fries  $3.99\r\n\r\nbeer battered onion rings  $6.99\r\n\r\ntempura battered mushrooms  $7.29\r\n\r\nChips &amp; fire roasted salsa  $5.99\r\n\r\nAdd queso $2.49\r\n\r\nlocked &amp; loaded fries   $7.99\r\n\r\nQueso cheese, bacon crumbles, &amp; pickled jalapenos\r\n\r\nServed with ranch dressing.\r\n\r\n—————————————————————————————————————————————\r\n<h2>Wood-Fired Burgers</h2>\r\nthe bronson  $9.99\r\n\r\nCheddar cheese, smoked bacon, grilled onions &amp; jalapenos. LTP w/house dressing\r\n\r\n&nbsp;\r\n\r\nclassic rock burger   $8.49\r\n\r\nLTOP with mustard\r\n\r\n&nbsp;\r\n\r\npig sleeping\r\non a rock   $9.99\r\n\r\nCheddar cheese &amp;\r\nsmoked bacon, LTOP\r\nw/mayo &amp; mustard\r\n\r\n&nbsp;\r\n\r\nthe hendrix  $8.99\r\n\r\nSwiss cheese, grilled mushrooms, LTO w/mayo\r\n\r\n&nbsp;\r\n\r\nthe duke  $9.99\r\n\r\nPepper Jack cheese, guacamole &amp; smoked bacon,\r\nLTO w/mayo\r\n\r\nbleu’s burger   $8.99\r\n\r\nBleu cheese crumbles, tangy BBQ sauce, LTOP w/mayo\r\n\r\n&nbsp;\r\n\r\nhippie hallow (veggie burger)  $8.29\r\n\r\nPepper Jack cheese, roasted peppers, sautéed mushrooms, LTOP w/chipotle mayo\r\n*we also offer a Portabello\r\nmushroom substitute\r\n\r\n&nbsp;\r\n\r\nhawaiian burger   $9.99\r\n\r\nSmoked bacon, grilled pineapple, LTO w/tangy chili sauce &amp; mayo\r\n\r\n&nbsp;\r\n\r\nthe barnyard brawl  $9.99\r\n\r\nAmerican cheese, smoked bacon, hash browns &amp;\r\na fried egg, LTO w/mayo\r\n\r\n&nbsp;\r\n\r\nthe roadie  $9.99\r\n\r\nCheddar cheese, smoked bacon, fried onions, tangy BBQ sauce, LTO w/mayo\r\n\r\n&nbsp;\r\n\r\nhandmade burgers SEASONED &amp; GRILLED OVER A WOOD FLAME &amp; SLAPPED on a toasted poppy seed bun. Served with a handful of fries (or upgrade to onion rings, LOCKED &amp; LOADED FRIES or salad)\r\n<h2>Sandwiches</h2>\r\nthe yardbird  $8.99\r\n\r\nSeasoned &amp; grilled chicken, swiss cheese,\r\nLTOP w/chipotle mayo\r\n\r\n&nbsp;\r\n\r\nRockin’ Reuben  $8.29\r\n\r\nPastrami, sour kraut, swiss, thousand island, all melted on marble rye\r\n\r\n&nbsp;\r\n\r\nacoustic act  $8.99\r\n\r\nTender sliced turkey, smoked bacon, swiss, lettuce, tomato, w/avocado mayo on marble rye.\r\n\r\n&nbsp;\r\n\r\nfrench dip   $9.99\r\n\r\nThinly sliced Rib-eye steak, seasoned &amp; grilled. Topped with swiss cheese on a toasted poppy seed roll\r\nw/au jus dipping sauce\r\n\r\nfish sandwich   $8.99\r\n\r\nBlackened tilapia, LTOP w/chipotle mayo on poppy seed bun\r\n\r\n&nbsp;\r\n<h2>Salads</h2>\r\nserved w/Ranch, Bleu Cheese, Balsamic Vinaigrette,\r\n\r\nHoney Mustard, Thousand Island, Caesar, or Chipotle Ranch\r\n\r\n&nbsp;\r\n\r\nAdd grilled or crispy chicken $1.99    Add blackened Tilapia $2.99\r\n\r\n&nbsp;\r\n\r\ndinner salad  $6.99\r\n\r\nRomaine lettuce, mixed cheese, tomato,\r\nred onions &amp; croutons\r\n\r\n&nbsp;\r\n\r\ncaesar salad   $7.29\r\n\r\nCrisp romaine lettuce, parmesan cheese, &amp; croutons, tossed in a creamy caesar dressing\r\n\r\n&nbsp;\r\n\r\nbuffalo chicken salad   $8.99\r\n\r\nRomaine lettuce, mixed cheese, tomato, red onions, bleu cheese crumbles, &amp; crispy buffalo chicken\r\n\r\n&nbsp;\r\n<h2>Dessert</h2>\r\nBrownie bottom Sunday $5.29\r\n\r\nWarm chocolate brownie covered with vanilla ice cream, whipped cream, caramel &amp; raspberry sauce\r\n\r\n&nbsp;\r\n<h2>Draft Beers</h2>\r\nmiller lite\r\n\r\ncoors light\r\n\r\nbud light\r\n\r\nmichelob ultra\r\n\r\ndos xx’s lager\r\n\r\nsam adams\r\n\r\nblue moon\r\n<h2>Bottled Beers</h2>\r\nbudweiser\r\n\r\nbud light\r\n\r\nmiller lite\r\n\r\ncoors light\r\n\r\nmichelob ultra\r\n\r\ncorona\r\n\r\n--\r\n\r\ncorona light\r\n\r\nred bridge (gluten free)\r\n\r\ndos xx’s\r\n\r\nheineken\r\n\r\nGuinness\r\n\r\nred’s apple ale\r\n\r\n&nbsp;\r\n<h2>Signature Cocktails</h2>\r\nlove junk\r\n\r\nAbsolut Vodka, peach schnapps, melon liquor, pineapple juice\r\n\r\n&nbsp;\r\n\r\nB*#CH ON WHEELS\r\n\r\nAmaretto, Malibu Rum, Sprite &amp; pineapple juice\r\n\r\n&nbsp;\r\n\r\nRock Hard Rita (Top Shelf)\r\n\r\nPatron Tequila, Gran Marnier, topped off with fresh lime juice\r\n\r\n&nbsp;\r\n\r\n&nbsp;\r\n\r\ngrape ape\r\n\r\nBlue Curacao, grape vodka, cranberry juice &amp; Sprite\r\n\r\n&nbsp;\r\n\r\nbronson\r\n\r\nbloody mary\r\n\r\nPerfect blend of  vodka, spices, and our signature mix\r\n\r\n&nbsp;\r\n\r\nmimosa\r\n\r\n(Sundays only)\r\n\r\nChampagne &amp; orange juice\r\n<h2>Frozen Margaritas</h2>\r\nbronson frozen margarita\r\n\r\nitalian margarita (amaretto)\r\n\r\nblue bayou margarita (curacao)\r\n\r\npeachy keen margarita (peach schnapps)\r\n\r\norange blossom margarita (Gran Marnier)\r\n\r\nspanish margarita (sangria)\r\n\r\nmelon margarita (melon liquor)\r\n\r\nsuicide margarita\r\n(all of the above!)\r\n\r\n&nbsp;\r\n<h2>Wine</h2>\r\n<h3>White (Glass)</h3>\r\nHouse Chardonnay\r\n\r\nHouse Moscato\r\n\r\nHouse Pinot Grigio\r\n\r\nHouse White Zinfandel\r\n\r\nPremium Chardonnay\r\n\r\n&nbsp;\r\n\r\nRed (Glass)\r\n\r\nHouse Cabernet\r\n\r\nHouse Merlot\r\n\r\nPremium Cabernet\r\n\r\nPremium Merlot\r\n\r\n&nbsp;\r\n<h3>Bottle</h3>\r\nJ. Lohr Merlot\r\n\r\nCasillero Del Diablo\r\n\r\nCabernet\r\n\r\nJosh Chardonnay\r\n\r\n&nbsp;\r\n\r\n* ask your server for details on wine\r\n\r\n&nbsp;\r\n<h2>Carry-Out Available</h2>\r\nCall 817-431-5543\r\n\r\n&nbsp;', 'Menu', '', 'inherit', 'open', 'open', '', '351-revision-v1', '', '', '2014-05-23 08:28:45', '2014-05-23 14:28:45', '', 351, 'http://nick.bronsonrocktx.com/351-revision-v1/', 0, 'revision', '', 0),
(379, 1, '2014-05-23 08:29:46', '2014-05-23 14:29:46', '<h2>Rockin\' Starters</h2>\r\n<h3>POTATO SKINS   $9.29</h3>\r\nFried skins topped with mixed cheese, bacon\r\n\r\nServed with sour cream\r\n\r\nFlat Bread Margarita Pizza   $8.29\r\n\r\nWood fired flat bread, topped with marinara, roasted tomatoes, fresh basil, blended mozzarella cheese, drizzled with a sweet basalmic glaze.\r\n\r\nloaded nachos  $8.99\r\n\r\nChips, queso, beans, lettuce, tomato, onions, guacamole, sour cream &amp; pickled jalapenos.\r\n\r\nGround beef or grilled chicken can be added for $1.99\r\n\r\nWings (one pound)   $8.99\r\n\r\nLemon Pepper, BBQ, Teriyaki,\r\nGarlic, Parmesan, Buffalo (mild,\r\n\r\nhot, extra hot), Sweet Chili\r\n\r\n&nbsp;\r\n\r\n&nbsp;\r\n\r\nfried mozzarella  $8.29\r\n\r\njalapeño poppers  $7.99\r\n\r\nbasket of fries  $3.99\r\n\r\nbeer battered onion rings  $6.99\r\n\r\ntempura battered mushrooms  $7.29\r\n\r\nChips &amp; fire roasted salsa  $5.99\r\n\r\nAdd queso $2.49\r\n\r\nlocked &amp; loaded fries   $7.99\r\n\r\nQueso cheese, bacon crumbles, &amp; pickled jalapenos\r\n\r\nServed with ranch dressing.\r\n\r\n—————————————————————————————————————————————\r\n<h2>Wood-Fired Burgers</h2>\r\nthe bronson  $9.99\r\n\r\nCheddar cheese, smoked bacon, grilled onions &amp; jalapenos. LTP w/house dressing\r\n\r\n&nbsp;\r\n\r\nclassic rock burger   $8.49\r\n\r\nLTOP with mustard\r\n\r\n&nbsp;\r\n\r\npig sleeping\r\non a rock   $9.99\r\n\r\nCheddar cheese &amp;\r\nsmoked bacon, LTOP\r\nw/mayo &amp; mustard\r\n\r\n&nbsp;\r\n\r\nthe hendrix  $8.99\r\n\r\nSwiss cheese, grilled mushrooms, LTO w/mayo\r\n\r\n&nbsp;\r\n\r\nthe duke  $9.99\r\n\r\nPepper Jack cheese, guacamole &amp; smoked bacon,\r\nLTO w/mayo\r\n\r\nbleu’s burger   $8.99\r\n\r\nBleu cheese crumbles, tangy BBQ sauce, LTOP w/mayo\r\n\r\n&nbsp;\r\n\r\nhippie hallow (veggie burger)  $8.29\r\n\r\nPepper Jack cheese, roasted peppers, sautéed mushrooms, LTOP w/chipotle mayo\r\n*we also offer a Portabello\r\nmushroom substitute\r\n\r\n&nbsp;\r\n\r\nhawaiian burger   $9.99\r\n\r\nSmoked bacon, grilled pineapple, LTO w/tangy chili sauce &amp; mayo\r\n\r\n&nbsp;\r\n\r\nthe barnyard brawl  $9.99\r\n\r\nAmerican cheese, smoked bacon, hash browns &amp;\r\na fried egg, LTO w/mayo\r\n\r\n&nbsp;\r\n\r\nthe roadie  $9.99\r\n\r\nCheddar cheese, smoked bacon, fried onions, tangy BBQ sauce, LTO w/mayo\r\n\r\n&nbsp;\r\n\r\nhandmade burgers SEASONED &amp; GRILLED OVER A WOOD FLAME &amp; SLAPPED on a toasted poppy seed bun. Served with a handful of fries (or upgrade to onion rings, LOCKED &amp; LOADED FRIES or salad)\r\n<h2>Sandwiches</h2>\r\nthe yardbird  $8.99\r\n\r\nSeasoned &amp; grilled chicken, swiss cheese,\r\nLTOP w/chipotle mayo\r\n\r\n&nbsp;\r\n\r\nRockin’ Reuben  $8.29\r\n\r\nPastrami, sour kraut, swiss, thousand island, all melted on marble rye\r\n\r\n&nbsp;\r\n\r\nacoustic act  $8.99\r\n\r\nTender sliced turkey, smoked bacon, swiss, lettuce, tomato, w/avocado mayo on marble rye.\r\n\r\n&nbsp;\r\n\r\nfrench dip   $9.99\r\n\r\nThinly sliced Rib-eye steak, seasoned &amp; grilled. Topped with swiss cheese on a toasted poppy seed roll\r\nw/au jus dipping sauce\r\n\r\nfish sandwich   $8.99\r\n\r\nBlackened tilapia, LTOP w/chipotle mayo on poppy seed bun\r\n\r\n&nbsp;\r\n<h2>Salads</h2>\r\nserved w/Ranch, Bleu Cheese, Balsamic Vinaigrette,\r\n\r\nHoney Mustard, Thousand Island, Caesar, or Chipotle Ranch\r\n\r\n&nbsp;\r\n\r\nAdd grilled or crispy chicken $1.99    Add blackened Tilapia $2.99\r\n\r\n&nbsp;\r\n\r\ndinner salad  $6.99\r\n\r\nRomaine lettuce, mixed cheese, tomato,\r\nred onions &amp; croutons\r\n\r\n&nbsp;\r\n\r\ncaesar salad   $7.29\r\n\r\nCrisp romaine lettuce, parmesan cheese, &amp; croutons, tossed in a creamy caesar dressing\r\n\r\n&nbsp;\r\n\r\nbuffalo chicken salad   $8.99\r\n\r\nRomaine lettuce, mixed cheese, tomato, red onions, bleu cheese crumbles, &amp; crispy buffalo chicken\r\n\r\n&nbsp;\r\n<h2>Dessert</h2>\r\nBrownie bottom Sunday $5.29\r\n\r\nWarm chocolate brownie covered with vanilla ice cream, whipped cream, caramel &amp; raspberry sauce\r\n\r\n&nbsp;\r\n<h2>Draft Beers</h2>\r\nmiller lite\r\n\r\ncoors light\r\n\r\nbud light\r\n\r\nmichelob ultra\r\n\r\ndos xx’s lager\r\n\r\nsam adams\r\n\r\nblue moon\r\n<h2>Bottled Beers</h2>\r\nbudweiser\r\n\r\nbud light\r\n\r\nmiller lite\r\n\r\ncoors light\r\n\r\nmichelob ultra\r\n\r\ncorona\r\n\r\n--\r\n\r\ncorona light\r\n\r\nred bridge (gluten free)\r\n\r\ndos xx’s\r\n\r\nheineken\r\n\r\nGuinness\r\n\r\nred’s apple ale\r\n\r\n&nbsp;\r\n<h2>Signature Cocktails</h2>\r\nlove junk\r\n\r\nAbsolut Vodka, peach schnapps, melon liquor, pineapple juice\r\n\r\n&nbsp;\r\n\r\nB*#CH ON WHEELS\r\n\r\nAmaretto, Malibu Rum, Sprite &amp; pineapple juice\r\n\r\n&nbsp;\r\n\r\nRock Hard Rita (Top Shelf)\r\n\r\nPatron Tequila, Gran Marnier, topped off with fresh lime juice\r\n\r\n&nbsp;\r\n\r\n&nbsp;\r\n\r\ngrape ape\r\n\r\nBlue Curacao, grape vodka, cranberry juice &amp; Sprite\r\n\r\n&nbsp;\r\n\r\nbronson\r\n\r\nbloody mary\r\n\r\nPerfect blend of  vodka, spices, and our signature mix\r\n\r\n&nbsp;\r\n\r\nmimosa\r\n\r\n(Sundays only)\r\n\r\nChampagne &amp; orange juice\r\n<h2>Frozen Margaritas</h2>\r\nbronson frozen margarita\r\n\r\nitalian margarita (amaretto)\r\n\r\nblue bayou margarita (curacao)\r\n\r\npeachy keen margarita (peach schnapps)\r\n\r\norange blossom margarita (Gran Marnier)\r\n\r\nspanish margarita (sangria)\r\n\r\nmelon margarita (melon liquor)\r\n\r\nsuicide margarita\r\n(all of the above!)\r\n\r\n&nbsp;\r\n<h2>Wine</h2>\r\n<h3>White (Glass)</h3>\r\nHouse Chardonnay\r\n\r\nHouse Moscato\r\n\r\nHouse Pinot Grigio\r\n\r\nHouse White Zinfandel\r\n\r\nPremium Chardonnay\r\n\r\n&nbsp;\r\n\r\nRed (Glass)\r\n\r\nHouse Cabernet\r\n\r\nHouse Merlot\r\n\r\nPremium Cabernet\r\n\r\nPremium Merlot\r\n\r\n&nbsp;\r\n<h3>Bottle</h3>\r\nJ. Lohr Merlot\r\n\r\nCasillero Del Diablo\r\n\r\nCabernet\r\n\r\nJosh Chardonnay\r\n\r\n&nbsp;\r\n\r\n* ask your server for details on wine\r\n\r\n&nbsp;\r\n<h2>Carry-Out Available</h2>\r\nCall 817-431-5543\r\n\r\n&nbsp;', 'Menu', '', 'inherit', 'open', 'open', '', '351-revision-v1', '', '', '2014-05-23 08:29:46', '2014-05-23 14:29:46', '', 351, 'http://nick.bronsonrocktx.com/351-revision-v1/', 0, 'revision', '', 0),
(380, 1, '2014-05-23 08:31:06', '2014-05-23 14:31:06', '<h2>Rockin\' Starters</h2>\r\n<h3>POTATO SKINS   $9.29</h3>\r\nFried skins topped with mixed cheese &amp; bacon. Served with sour cream.\r\n<h3>Flat Bread Margarita Pizza   $8.29</h3>\r\nWood fired flat bread, topped with marinara, roasted tomatoes, fresh basil, blended mozzarella cheese, drizzled with a sweet basalmic glaze.\r\n\r\nloaded nachos  $8.99\r\n\r\nChips, queso, beans, lettuce, tomato, onions, guacamole, sour cream &amp; pickled jalapenos.\r\n\r\nGround beef or grilled chicken can be added for $1.99\r\n\r\nWings (one pound)   $8.99\r\n\r\nLemon Pepper, BBQ, Teriyaki,\r\nGarlic, Parmesan, Buffalo (mild,\r\n\r\nhot, extra hot), Sweet Chili\r\n\r\n&nbsp;\r\n\r\n&nbsp;\r\n\r\nfried mozzarella  $8.29\r\n\r\njalapeño poppers  $7.99\r\n\r\nbasket of fries  $3.99\r\n\r\nbeer battered onion rings  $6.99\r\n\r\ntempura battered mushrooms  $7.29\r\n\r\nChips &amp; fire roasted salsa  $5.99\r\n\r\nAdd queso $2.49\r\n\r\nlocked &amp; loaded fries   $7.99\r\n\r\nQueso cheese, bacon crumbles, &amp; pickled jalapenos\r\n\r\nServed with ranch dressing.\r\n\r\n—————————————————————————————————————————————\r\n<h2>Wood-Fired Burgers</h2>\r\nthe bronson  $9.99\r\n\r\nCheddar cheese, smoked bacon, grilled onions &amp; jalapenos. LTP w/house dressing\r\n\r\n&nbsp;\r\n\r\nclassic rock burger   $8.49\r\n\r\nLTOP with mustard\r\n\r\n&nbsp;\r\n\r\npig sleeping\r\non a rock   $9.99\r\n\r\nCheddar cheese &amp;\r\nsmoked bacon, LTOP\r\nw/mayo &amp; mustard\r\n\r\n&nbsp;\r\n\r\nthe hendrix  $8.99\r\n\r\nSwiss cheese, grilled mushrooms, LTO w/mayo\r\n\r\n&nbsp;\r\n\r\nthe duke  $9.99\r\n\r\nPepper Jack cheese, guacamole &amp; smoked bacon,\r\nLTO w/mayo\r\n\r\nbleu’s burger   $8.99\r\n\r\nBleu cheese crumbles, tangy BBQ sauce, LTOP w/mayo\r\n\r\n&nbsp;\r\n\r\nhippie hallow (veggie burger)  $8.29\r\n\r\nPepper Jack cheese, roasted peppers, sautéed mushrooms, LTOP w/chipotle mayo\r\n*we also offer a Portabello\r\nmushroom substitute\r\n\r\n&nbsp;\r\n\r\nhawaiian burger   $9.99\r\n\r\nSmoked bacon, grilled pineapple, LTO w/tangy chili sauce &amp; mayo\r\n\r\n&nbsp;\r\n\r\nthe barnyard brawl  $9.99\r\n\r\nAmerican cheese, smoked bacon, hash browns &amp;\r\na fried egg, LTO w/mayo\r\n\r\n&nbsp;\r\n\r\nthe roadie  $9.99\r\n\r\nCheddar cheese, smoked bacon, fried onions, tangy BBQ sauce, LTO w/mayo\r\n\r\n&nbsp;\r\n\r\nhandmade burgers SEASONED &amp; GRILLED OVER A WOOD FLAME &amp; SLAPPED on a toasted poppy seed bun. Served with a handful of fries (or upgrade to onion rings, LOCKED &amp; LOADED FRIES or salad)\r\n<h2>Sandwiches</h2>\r\nthe yardbird  $8.99\r\n\r\nSeasoned &amp; grilled chicken, swiss cheese,\r\nLTOP w/chipotle mayo\r\n\r\n&nbsp;\r\n\r\nRockin’ Reuben  $8.29\r\n\r\nPastrami, sour kraut, swiss, thousand island, all melted on marble rye\r\n\r\n&nbsp;\r\n\r\nacoustic act  $8.99\r\n\r\nTender sliced turkey, smoked bacon, swiss, lettuce, tomato, w/avocado mayo on marble rye.\r\n\r\n&nbsp;\r\n\r\nfrench dip   $9.99\r\n\r\nThinly sliced Rib-eye steak, seasoned &amp; grilled. Topped with swiss cheese on a toasted poppy seed roll\r\nw/au jus dipping sauce\r\n\r\nfish sandwich   $8.99\r\n\r\nBlackened tilapia, LTOP w/chipotle mayo on poppy seed bun\r\n\r\n&nbsp;\r\n<h2>Salads</h2>\r\nserved w/Ranch, Bleu Cheese, Balsamic Vinaigrette,\r\n\r\nHoney Mustard, Thousand Island, Caesar, or Chipotle Ranch\r\n\r\n&nbsp;\r\n\r\nAdd grilled or crispy chicken $1.99    Add blackened Tilapia $2.99\r\n\r\n&nbsp;\r\n\r\ndinner salad  $6.99\r\n\r\nRomaine lettuce, mixed cheese, tomato,\r\nred onions &amp; croutons\r\n\r\n&nbsp;\r\n\r\ncaesar salad   $7.29\r\n\r\nCrisp romaine lettuce, parmesan cheese, &amp; croutons, tossed in a creamy caesar dressing\r\n\r\n&nbsp;\r\n\r\nbuffalo chicken salad   $8.99\r\n\r\nRomaine lettuce, mixed cheese, tomato, red onions, bleu cheese crumbles, &amp; crispy buffalo chicken\r\n\r\n&nbsp;\r\n<h2>Dessert</h2>\r\nBrownie bottom Sunday $5.29\r\n\r\nWarm chocolate brownie covered with vanilla ice cream, whipped cream, caramel &amp; raspberry sauce\r\n\r\n&nbsp;\r\n<h2>Draft Beers</h2>\r\nmiller lite\r\n\r\ncoors light\r\n\r\nbud light\r\n\r\nmichelob ultra\r\n\r\ndos xx’s lager\r\n\r\nsam adams\r\n\r\nblue moon\r\n<h2>Bottled Beers</h2>\r\nbudweiser\r\n\r\nbud light\r\n\r\nmiller lite\r\n\r\ncoors light\r\n\r\nmichelob ultra\r\n\r\ncorona\r\n\r\n--\r\n\r\ncorona light\r\n\r\nred bridge (gluten free)\r\n\r\ndos xx’s\r\n\r\nheineken\r\n\r\nGuinness\r\n\r\nred’s apple ale\r\n\r\n&nbsp;\r\n<h2>Signature Cocktails</h2>\r\nlove junk\r\n\r\nAbsolut Vodka, peach schnapps, melon liquor, pineapple juice\r\n\r\n&nbsp;\r\n\r\nB*#CH ON WHEELS\r\n\r\nAmaretto, Malibu Rum, Sprite &amp; pineapple juice\r\n\r\n&nbsp;\r\n\r\nRock Hard Rita (Top Shelf)\r\n\r\nPatron Tequila, Gran Marnier, topped off with fresh lime juice\r\n\r\n&nbsp;\r\n\r\n&nbsp;\r\n\r\ngrape ape\r\n\r\nBlue Curacao, grape vodka, cranberry juice &amp; Sprite\r\n\r\n&nbsp;\r\n\r\nbronson\r\n\r\nbloody mary\r\n\r\nPerfect blend of  vodka, spices, and our signature mix\r\n\r\n&nbsp;\r\n\r\nmimosa\r\n\r\n(Sundays only)\r\n\r\nChampagne &amp; orange juice\r\n<h2>Frozen Margaritas</h2>\r\nbronson frozen margarita\r\n\r\nitalian margarita (amaretto)\r\n\r\nblue bayou margarita (curacao)\r\n\r\npeachy keen margarita (peach schnapps)\r\n\r\norange blossom margarita (Gran Marnier)\r\n\r\nspanish margarita (sangria)\r\n\r\nmelon margarita (melon liquor)\r\n\r\nsuicide margarita\r\n(all of the above!)\r\n\r\n&nbsp;\r\n<h2>Wine</h2>\r\n<h3>White (Glass)</h3>\r\nHouse Chardonnay\r\n\r\nHouse Moscato\r\n\r\nHouse Pinot Grigio\r\n\r\nHouse White Zinfandel\r\n\r\nPremium Chardonnay\r\n\r\n&nbsp;\r\n\r\nRed (Glass)\r\n\r\nHouse Cabernet\r\n\r\nHouse Merlot\r\n\r\nPremium Cabernet\r\n\r\nPremium Merlot\r\n\r\n&nbsp;\r\n<h3>Bottle</h3>\r\nJ. Lohr Merlot\r\n\r\nCasillero Del Diablo\r\n\r\nCabernet\r\n\r\nJosh Chardonnay\r\n\r\n&nbsp;\r\n\r\n* ask your server for details on wine\r\n\r\n&nbsp;\r\n<h2>Carry-Out Available</h2>\r\nCall 817-431-5543\r\n\r\n&nbsp;', 'Menu', '', 'inherit', 'open', 'open', '', '351-revision-v1', '', '', '2014-05-23 08:31:06', '2014-05-23 14:31:06', '', 351, 'http://nick.bronsonrocktx.com/351-revision-v1/', 0, 'revision', '', 0),
(381, 1, '2014-05-23 08:52:27', '2014-05-23 14:52:27', '<h2>Rockin\' Starters</h2>\r\n<h3>Potato Skins   $9.29</h3>\r\nFried skins topped with mixed cheese &amp; bacon. Served with sour cream.\r\n<h3>Flat Bread Margarita Pizza   $8.29</h3>\r\nWood fired flat bread, topped with marinara, roasted tomatoes, fresh basil, blended mozzarella cheese, drizzled with a sweet basalmic glaze.\r\n<h3>Loaded Nachos  $8.99</h3>\r\nChips, queso, beans, lettuce, tomato, onions, guacamole, sour cream &amp; pickled jalapenos.\r\nGround beef or grilled chicken can be added for $1.99\r\n<h3>Wings (one pound)   $8.99</h3>\r\nLemon Pepper, BBQ, Teriyaki, Garlic, Parmesan, Buffalo (mild, hot, extra hot), Sweet Chili\r\n<h3>Fried Mozzarella  $8.29</h3>\r\n<h3>Jalapeño Poppers  $7.99</h3>\r\n<h3>Basket of Fries  $3.99</h3>\r\n<h3>Beer-Battered Onion Rings  $6.99</h3>\r\n<h3>Tempura-Battered Mushrooms  $7.29</h3>\r\n<h3>Chips &amp; Fire-Roasted Salsa  $5.99</h3>\r\nAdd queso $2.49\r\n<h3>Locked &amp; Loaded Fries   $7.99</h3>\r\n<h3>Queso Cheese, Bacon Crumbles, &amp; Pickled Jalapenos</h3>\r\nServed with ranch dressing.\r\n<h2>Wood-Fired Burgers</h2>\r\nHandmade burgers seasoned &amp; grilled over a wood flame &amp; slapped on a toasted poppy seed bun. Served with a handful of fries (or upgrade to Onion Rings, Locked &amp; Loaded fries, or Salad)\r\n<h3>The Bronson  $9.99</h3>\r\nCheddar cheese, smoked bacon, grilled onions &amp; jalapenos. LTP w/house dressing\r\n<h3>Classic Rock Burger   $8.49</h3>\r\nLTOP with mustard\r\n<h3>Pig Sleeping on a Rock $9.99</h3>\r\nCheddar cheese &amp; smoked bacon, LTOP, w/mayo &amp; mustard\r\n<h3>The Hendrix  $8.99</h3>\r\nSwiss cheese, grilled mushrooms, LTO w/mayo\r\n<h3>The Duke  $9.99</h3>\r\nPepper Jack cheese, guacamole &amp; smoked bacon, LTO w/mayo\r\n<h3>Bleu’s Burger   $8.99</h3>\r\nBleu cheese crumbles, tangy BBQ sauce, LTOP w/mayo\r\n<h3>Hippie Hallow (Veggie Burger)  $8.29</h3>\r\nPepper Jack cheese, roasted peppers, sautéed mushrooms, LTOP w/chipotle mayo\r\n*we also offer a Portabello mushroom substitute\r\n<h3>Hawaiian Burger   $9.99</h3>\r\nSmoked bacon, grilled pineapple, LTO w/tangy chili sauce &amp; mayo\r\n<h3>The Barnyard Brawl  $9.99</h3>\r\nAmerican cheese, smoked bacon, hash browns and a fried egg, LTO w/mayo\r\n<h3>The Roadie  $9.99</h3>\r\nCheddar cheese, smoked bacon, fried onions, tangy BBQ sauce, LTO w/mayo\r\n<h2>Sandwiches</h2>\r\n<h3>The Yardbird  $8.99</h3>\r\nSeasoned &amp; grilled chicken, swiss cheese, LTOP w/chipotle mayo\r\n<h3>Rockin’ Reuben  $8.29</h3>\r\nPastrami, sour kraut, swiss, thousand island, all melted on marble rye\r\n<h3>Acoustic Act  $8.99</h3>\r\nTender sliced turkey, smoked bacon, swiss, lettuce, tomato, w/avocado mayo on marble rye.\r\n<h3>French Dip   $9.99</h3>\r\nThinly sliced Rib-eye steak, seasoned &amp; grilled. Topped with swiss cheese on a toasted poppy seed roll w/au jus dipping sauce\r\n<h3>Fish Sandwich   $8.99</h3>\r\nBlackened tilapia, LTOP w/chipotle mayo on poppy seed bun\r\n<h2>Salads</h2>\r\nServed w/Ranch, Bleu Cheese, Balsamic Vinaigrette, Honey Mustard, Thousand Island, Caesar, or Chipotle Ranch\r\nAdd grilled or crispy chicken $1.99    Add blackened Tilapia $2.99\r\n<h3>Dinner Salad  $6.99</h3>\r\nRomaine lettuce, mixed cheese, tomato, red onions &amp; croutons\r\n<h3>Caesar Salad   $7.29</h3>\r\nCrisp romaine lettuce, parmesan cheese, &amp; croutons, tossed in a creamy caesar dressing\r\n<h3>Buffalo Chicken Salad   $8.99</h3>\r\nRomaine lettuce, mixed cheese, tomato, red onions, bleu cheese crumbles, &amp; crispy buffalo chicken\r\n<h2>Dessert</h2>\r\n<h3>Brownie bottom Sunday $5.29</h3>\r\nWarm chocolate brownie covered with vanilla ice cream, whipped cream, caramel &amp; raspberry sauce\r\n<h2>Draft Beers</h2>\r\n<h3>Miller Lite</h3>\r\n<h3>Coors Light</h3>\r\n<h3>Bud Light</h3>\r\n<h3>Michelob Ultra</h3>\r\n<h3>Dos XX’s Lager</h3>\r\n<h3>Sam Adams</h3>\r\n<h3>Blue Moon</h3>\r\n<h2>Bottled Beers</h2>\r\n<h3>Budweiser</h3>\r\n<h3>Bud Light</h3>\r\n<h3>Miller Lite</h3>\r\n<h3>Coors Light</h3>\r\n<h3>Michelob Ultra</h3>\r\n<h3>Corona</h3>\r\n<h3>--</h3>\r\n<h3>Corona Light</h3>\r\n<h3>Red Bridge (Gluten Free)</h3>\r\n<h3>Dos XX’s</h3>\r\n<h3>Heineken</h3>\r\n<h3>Guinness</h3>\r\n<h3>Red’s Apple Ale</h3>\r\n&nbsp;\r\n<h2>Signature Cocktails</h2>\r\n<h3>Love Junk</h3>\r\nAbsolut Vodka, peach schnapps, melon liquor, pineapple juice\r\n<h3>B*#CH ON WHEELS</h3>\r\nAmaretto, Malibu Rum, Sprite &amp; pineapple juice\r\n<h3>Rock Hard Rita (Top Shelf)</h3>\r\nPatron Tequila, Gran Marnier, topped off with fresh lime juice\r\n<h3>Grape Ape</h3>\r\nBlue Curacao, grape vodka, cranberry juice &amp; Sprite\r\n<h3>Bronson Bloody Mary</h3>\r\nPerfect blend of  vodka, spices, and our signature mix\r\n<h3>Mimosa (Sundays only)</h3>\r\nChampagne &amp; orange juice\r\n<h2>Frozen Margaritas</h2>\r\n<h3>Bronson Frozen Margarita</h3>\r\n<h3>Italian Margarita (Amaretto)</h3>\r\n<h3>Blue Bayou Margarita (Curacao)</h3>\r\n<h3>Peachy Keen Margarita (Peach Schnapps)</h3>\r\n<h3>Orange Blossom Margarita (Gran Marnier)</h3>\r\n<h3>Spanish Margarita (Sangria)</h3>\r\n<h3>Melon Margarita (Melon Liquor)</h3>\r\n<h3>Suicide Margarita\r\n(All of the Above!)</h3>\r\n<h2>Wine</h2>\r\n<h3>White (Glass)</h3>\r\nHouse Chardonnay\r\n\r\nHouse Moscato\r\n\r\nHouse Pinot Grigio\r\n\r\nHouse White Zinfandel\r\n\r\nPremium Chardonnay\r\n<h3>Red (Glass)</h3>\r\nHouse Cabernet\r\n\r\nHouse Merlot\r\n\r\nPremium Cabernet\r\n\r\nPremium Merlot\r\n<h3>Bottle</h3>\r\nJ. Lohr Merlot\r\n\r\nCasillero Del Diablo\r\n\r\nCabernet\r\n\r\nJosh Chardonnay\r\n\r\n* ask your server for details on wine\r\n\r\n&nbsp;\r\n<h2>Carry-Out Available</h2>\r\nCall 817-431-5543\r\n\r\n&nbsp;', 'Menu', '', 'inherit', 'open', 'open', '', '351-revision-v1', '', '', '2014-05-23 08:52:27', '2014-05-23 14:52:27', '', 351, 'http://nick.bronsonrocktx.com/351-revision-v1/', 0, 'revision', '', 0),
(383, 1, '2014-08-13 13:03:49', '2014-08-13 19:03:49', '', 'Live', '', 'inherit', 'open', 'open', '', '349-revision-v1', '', '', '2014-08-13 13:03:49', '2014-08-13 19:03:49', '', 349, 'http://nick.bronsonrocktx.com/349-revision-v1/', 0, 'revision', '', 0),
(385, 2, '2014-08-17 12:58:50', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-08-17 12:58:50', '0000-00-00 00:00:00', '', 0, 'http://nick.bronsonrocktx.com/?p=385', 0, 'post', '', 0),
(386, 2, '2014-08-17 13:15:27', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-08-17 13:15:27', '0000-00-00 00:00:00', '', 0, 'http://nick.bronsonrocktx.com/?post_type=event&p=386', 0, 'event', '', 0),
(387, 2, '2014-08-17 13:21:27', '2014-08-17 19:21:27', '', 'Event Info', '', 'publish', 'closed', 'closed', '', 'acf_event-info', '', '', '2014-08-17 14:02:56', '2014-08-17 20:02:56', '', 0, 'http://nick.bronsonrocktx.com/?post_type=acf&#038;p=387', 0, 'acf', '', 0),
(388, 2, '2014-08-17 13:22:13', '2014-08-17 19:22:13', '', 'Metal Band', '', 'publish', 'closed', 'closed', '', 'metal-band', '', '', '2014-08-17 13:23:31', '2014-08-17 19:23:31', '', 0, 'http://nick.bronsonrocktx.com/?post_type=event&#038;p=388', 0, 'event', '', 0),
(389, 2, '2014-08-17 13:22:13', '2014-08-17 19:22:13', '', 'Metal Band', '', 'inherit', 'open', 'open', '', '388-revision-v1', '', '', '2014-08-17 13:22:13', '2014-08-17 19:22:13', '', 388, 'http://nick.bronsonrocktx.com/388-revision-v1/', 0, 'revision', '', 0),
(390, 2, '2014-08-17 13:23:57', '2014-08-17 19:23:57', '', 'Punk Band', '', 'publish', 'closed', 'closed', '', 'punk-band', '', '', '2014-08-17 13:23:57', '2014-08-17 19:23:57', '', 0, 'http://nick.bronsonrocktx.com/?post_type=event&#038;p=390', 0, 'event', '', 0),
(391, 2, '2014-08-17 13:23:57', '2014-08-17 19:23:57', '', 'Punk Band', '', 'inherit', 'open', 'open', '', '390-revision-v1', '', '', '2014-08-17 13:23:57', '2014-08-17 19:23:57', '', 390, 'http://nick.bronsonrocktx.com/390-revision-v1/', 0, 'revision', '', 0),
(392, 2, '2014-08-17 13:39:35', '2014-08-17 19:39:35', '', 'Jazz Band', '', 'publish', 'closed', 'closed', '', 'jazz-band', '', '', '2014-08-17 13:39:52', '2014-08-17 19:39:52', '', 0, 'http://nick.bronsonrocktx.com/?post_type=event&#038;p=392', 0, 'event', '', 0),
(393, 2, '2014-08-17 13:39:35', '2014-08-17 19:39:35', '', 'Jazz Band', '', 'inherit', 'open', 'open', '', '392-revision-v1', '', '', '2014-08-17 13:39:35', '2014-08-17 19:39:35', '', 392, 'http://nick.bronsonrocktx.com/392-revision-v1/', 0, 'revision', '', 0),
(394, 2, '2014-08-17 13:40:37', '2014-08-17 19:40:37', '', 'Rock Band', '', 'publish', 'closed', 'closed', '', 'rock-band', '', '', '2014-08-17 13:40:37', '2014-08-17 19:40:37', '', 0, 'http://nick.bronsonrocktx.com/?post_type=event&#038;p=394', 0, 'event', '', 0),
(395, 2, '2014-08-17 13:40:37', '2014-08-17 19:40:37', '', 'Rock Band', '', 'inherit', 'open', 'open', '', '394-revision-v1', '', '', '2014-08-17 13:40:37', '2014-08-17 19:40:37', '', 394, 'http://nick.bronsonrocktx.com/394-revision-v1/', 0, 'revision', '', 0),
(396, 2, '2014-08-17 13:41:30', '2014-08-17 19:41:30', '', 'Techno Band', '', 'publish', 'closed', 'closed', '', 'techno-band', '', '', '2014-08-17 13:41:30', '2014-08-17 19:41:30', '', 0, 'http://nick.bronsonrocktx.com/?post_type=event&#038;p=396', 0, 'event', '', 0),
(397, 2, '2014-08-17 13:41:30', '2014-08-17 19:41:30', '', 'Techno Band', '', 'inherit', 'open', 'open', '', '396-revision-v1', '', '', '2014-08-17 13:41:30', '2014-08-17 19:41:30', '', 396, 'http://nick.bronsonrocktx.com/396-revision-v1/', 0, 'revision', '', 0),
(398, 2, '2014-08-17 14:55:36', '2014-08-17 20:55:36', '', 'Fake Band', '', 'publish', 'closed', 'closed', '', 'fake-band', '', '', '2014-08-20 12:45:18', '2014-08-20 18:45:18', '', 0, 'http://nick.bronsonrocktx.com/?post_type=event&#038;p=398', 0, 'event', '', 0),
(399, 2, '2014-08-17 14:55:36', '2014-08-17 20:55:36', '', 'Fake Band', '', 'inherit', 'open', 'open', '', '398-revision-v1', '', '', '2014-08-17 14:55:36', '2014-08-17 20:55:36', '', 398, 'http://nick.bronsonrocktx.com/398-revision-v1/', 0, 'revision', '', 0),
(400, 2, '2014-08-17 14:56:03', '2014-08-17 20:56:03', '', 'Fake Band #2', '', 'publish', 'closed', 'closed', '', 'fake-band-2', '', '', '2014-08-17 14:56:03', '2014-08-17 20:56:03', '', 0, 'http://nick.bronsonrocktx.com/?post_type=event&#038;p=400', 0, 'event', '', 0),
(401, 2, '2014-08-17 14:56:03', '2014-08-17 20:56:03', '', 'Fake Band #2', '', 'inherit', 'open', 'open', '', '400-revision-v1', '', '', '2014-08-17 14:56:03', '2014-08-17 20:56:03', '', 400, 'http://nick.bronsonrocktx.com/400-revision-v1/', 0, 'revision', '', 0),
(402, 1, '2014-08-20 12:42:02', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-08-20 12:42:02', '0000-00-00 00:00:00', '', 0, 'http://dev.bronsonrocktx.com/?p=402', 0, 'post', '', 0),
(403, 1, '2014-08-20 12:44:06', '2014-08-20 18:44:06', '', 'Fake Band', '', 'inherit', 'open', 'open', '', '398-revision-v1', '', '', '2014-08-20 12:44:06', '2014-08-20 18:44:06', '', 398, 'http://dev.bronsonrocktx.com/398-revision-v1/', 0, 'revision', '', 0),
(404, 1, '2014-08-20 12:45:18', '2014-08-20 18:45:18', '', 'Fake Band', '', 'inherit', 'open', 'open', '', '398-revision-v1', '', '', '2014-08-20 12:45:18', '2014-08-20 18:45:18', '', 398, 'http://dev.bronsonrocktx.com/398-revision-v1/', 0, 'revision', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form`
#

DROP TABLE IF EXISTS `wp_rg_form`;


#
# Table structure of table `wp_rg_form`
#

CREATE TABLE `wp_rg_form` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL,
  `date_created` datetime NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_trash` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_rg_form`
#
INSERT INTO `wp_rg_form` ( `id`, `title`, `date_created`, `is_active`, `is_trash`) VALUES
(1, 'Contact Us', '2014-02-25 18:14:50', 1, 0),
(4, 'Stay In The Loop', '2014-05-07 21:40:36', 1, 0) ;

#
# End of data contents of table `wp_rg_form`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form_meta`
#

DROP TABLE IF EXISTS `wp_rg_form_meta`;


#
# Table structure of table `wp_rg_form_meta`
#

CREATE TABLE `wp_rg_form_meta` (
  `form_id` mediumint(8) unsigned NOT NULL,
  `display_meta` longtext,
  `entries_grid_meta` longtext,
  `confirmations` longtext,
  `notifications` longtext,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_rg_form_meta`
#
INSERT INTO `wp_rg_form_meta` ( `form_id`, `display_meta`, `entries_grid_meta`, `confirmations`, `notifications`) VALUES
(1, '{"title":"Contact Us","description":"For general questions or to request more information, fill out the form below. We look forward to hearing from you.","labelPlacement":"top_label","descriptionPlacement":"below","button":{"type":"text","text":"Send","imageUrl":""},"fields":[{"id":1,"label":"Name","adminLabel":"","type":"name","isRequired":true,"size":"medium","errorMessage":"","inputs":[{"id":1.3,"label":"First","name":""},{"id":1.6,"label":"Last","name":""}],"multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"inputMask":false,"inputMaskValue":"","allowsPrepopulate":false,"formId":1,"pageNumber":1,"descriptionPlacement":"below"},{"id":2,"label":"Email","adminLabel":"","type":"email","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"inputMask":false,"inputMaskValue":"","allowsPrepopulate":false,"formId":1,"pageNumber":1,"descriptionPlacement":"below"},{"id":3,"label":"Phone","adminLabel":"","type":"phone","isRequired":false,"size":"medium","errorMessage":"","inputs":null,"phoneFormat":"standard","formId":1,"pageNumber":1,"descriptionPlacement":"below"},{"id":4,"label":"Subject","adminLabel":"","type":"text","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"inputMask":false,"inputMaskValue":"","allowsPrepopulate":false,"formId":1,"pageNumber":1,"descriptionPlacement":"below"},{"id":5,"label":"Message","adminLabel":"","type":"textarea","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"inputMask":false,"inputMaskValue":"","allowsPrepopulate":false,"formId":1,"pageNumber":1,"descriptionPlacement":"below"}],"id":1,"useCurrentUserAsAuthor":true,"postContentTemplateEnabled":false,"postTitleTemplateEnabled":false,"postTitleTemplate":"","postContentTemplate":"","lastPageButton":null,"pagination":null,"firstPageCssClass":null,"notifications":{"530cdd9a7248c":{"id":"530cdd9a7248c","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}},"confirmations":{"530cdd9a72748":{"id":"530cdd9a72748","name":"Default Confirmation","isDefault":true,"type":"message","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":"","queryString":""}},"cssClass":"","enableHoneypot":"","enableAnimation":"","limitEntries":"","limitEntriesCount":"","limitEntriesPeriod":"","limitEntriesMessage":"","scheduleForm":"","scheduleStart":"","scheduleStartHour":"","scheduleStartMinute":"","scheduleStartAmpm":"","scheduleEnd":"","scheduleEndHour":"","scheduleEndMinute":"","scheduleEndAmpm":"","schedulePendingMessage":"","scheduleMessage":"","requireLogin":"","requireLoginMessage":""}', NULL, '{"530cdd9a72748":{"id":"530cdd9a72748","name":"Default Confirmation","isDefault":true,"type":"message","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":"","queryString":""}}', '{"530cdd9a7248c":{"id":"530cdd9a7248c","to":"shelly@dev.bronsonrocktx.com","name":"Admin Notification","event":"form_submission","toType":"email","subject":"{Subject:4}","message":"{all_fields}\\r\\n\\r\\nSent via Paradox form on your website","bcc":"ty@paradoxsites.com","from":"{Email:2}","fromName":"{Name (First):1.3} {Name (Last):1.6}","replyTo":"{Email:2}","routing":null,"conditionalLogic":null,"disableAutoformat":""}}'),
(4, '{"title":"Stay In The Loop","description":"","labelPlacement":"top_label","descriptionPlacement":"below","button":{"type":"text","text":"\\u25b8","imageUrl":""},"fields":[{"adminLabel":"","adminOnly":"","allowsPrepopulate":false,"defaultValue":"","description":"","content":"","cssClass":"","errorMessage":"Please enter your email","id":1,"inputName":"","isRequired":true,"label":"Email Address","noDuplicates":true,"size":"medium","type":"email","postCustomFieldName":"","displayAllCategories":false,"displayCaption":"","displayDescription":"","displayTitle":"","inputType":"","rangeMin":"","rangeMax":"","calendarIconType":"","calendarIconUrl":"","dateType":"","dateFormat":"","phoneFormat":"","addressType":"","defaultCountry":"","defaultProvince":"","defaultState":"","hideAddress2":"","hideCountry":"","hideState":"","inputs":null,"nameFormat":"","allowedExtensions":"","captchaType":"","pageNumber":1,"captchaTheme":"","simpleCaptchaSize":"","simpleCaptchaFontColor":"","simpleCaptchaBackgroundColor":"","failed_validation":"","productField":"","enablePasswordInput":"","maxLength":"","enablePrice":"","basePrice":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"inputMask":false,"inputMaskValue":"","emailConfirmEnabled":false,"formId":4,"descriptionPlacement":"below"}],"id":4,"useCurrentUserAsAuthor":true,"postContentTemplateEnabled":false,"postTitleTemplateEnabled":false,"postTitleTemplate":"","postContentTemplate":"","lastPageButton":null,"pagination":null,"firstPageCssClass":null,"cssClass":"gplaceholder","enableHoneypot":"","enableAnimation":"","limitEntries":"","limitEntriesCount":"","limitEntriesPeriod":"","limitEntriesMessage":"","scheduleForm":"","scheduleStart":"","scheduleStartHour":"","scheduleStartMinute":"","scheduleStartAmpm":"","scheduleEnd":"","scheduleEndHour":"","scheduleEndMinute":"","scheduleEndAmpm":"","schedulePendingMessage":"","scheduleMessage":"","requireLogin":"","requireLoginMessage":""}', NULL, '{"536aa854dd34a":{"id":"536aa854dd34a","name":"Default Confirmation","isDefault":true,"type":"message","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":"","queryString":""}}', '{"536aa854dd037":{"id":"536aa854dd037","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}","bcc":"","from":"{admin_email}","fromName":"","replyTo":"","routing":null,"conditionalLogic":null,"disableAutoformat":""}}') ;

#
# End of data contents of table `wp_rg_form_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form_view`
#

DROP TABLE IF EXISTS `wp_rg_form_view`;


#
# Table structure of table `wp_rg_form_view`
#

CREATE TABLE `wp_rg_form_view` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` char(15) DEFAULT NULL,
  `count` mediumint(8) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_rg_form_view`
#
INSERT INTO `wp_rg_form_view` ( `id`, `form_id`, `date_created`, `ip`, `count`) VALUES
(2, 1, '2014-03-20 21:59:13', '127.0.0.1', 1),
(3, 1, '2014-03-20 22:15:20', '127.0.0.1', 1),
(5, 1, '2014-03-20 23:07:50', '127.0.0.1', 8),
(8, 1, '2014-03-21 03:49:02', '64.125.188.26', 1),
(9, 1, '2014-03-21 14:19:21', '70.196.8.247', 1),
(10, 1, '2014-03-24 20:12:15', '127.0.0.1', 8),
(12, 1, '2014-03-25 01:33:02', '127.0.0.1', 12),
(13, 1, '2014-03-25 02:00:04', '127.0.0.1', 2),
(16, 1, '2014-03-25 05:29:03', '127.0.0.1', 2),
(17, 1, '2014-03-25 06:05:12', '127.0.0.1', 7),
(18, 1, '2014-03-25 07:04:18', '127.0.0.1', 15),
(19, 4, '2014-05-07 21:45:17', '127.0.0.1', 21),
(20, 4, '2014-05-07 22:55:27', '127.0.0.1', 1),
(21, 4, '2014-05-08 01:57:39', '127.0.0.1', 9),
(22, 4, '2014-05-08 13:22:40', '127.0.0.1', 26),
(23, 4, '2014-05-08 14:01:19', '127.0.0.1', 98),
(24, 4, '2014-05-08 15:06:40', '127.0.0.1', 94),
(25, 4, '2014-05-08 16:01:40', '127.0.0.1', 99),
(26, 4, '2014-05-08 17:02:37', '127.0.0.1', 97),
(27, 4, '2014-05-08 18:21:50', '127.0.0.1', 65),
(28, 4, '2014-05-08 19:00:06', '127.0.0.1', 89),
(29, 4, '2014-05-08 20:02:12', '127.0.0.1', 16),
(30, 4, '2014-05-08 21:07:07', '127.0.0.1', 29),
(31, 1, '2014-05-08 21:31:09', '127.0.0.1', 1),
(32, 4, '2014-05-23 14:15:05', '127.0.0.1', 2),
(33, 4, '2014-05-23 15:16:33', '127.0.0.1', 13),
(34, 4, '2014-05-23 16:00:15', '127.0.0.1', 20),
(35, 4, '2014-05-23 17:11:16', '127.0.0.1', 18),
(36, 4, '2014-05-23 19:28:00', '127.0.0.1', 4),
(37, 4, '2014-05-23 20:29:15', '127.0.0.1', 5),
(38, 4, '2014-05-23 21:02:34', '127.0.0.1', 16),
(39, 4, '2014-05-23 22:11:44', '127.0.0.1', 9),
(40, 4, '2014-05-23 23:56:49', '127.0.0.1', 4),
(41, 4, '2014-05-24 00:55:06', '127.0.0.1', 3),
(42, 4, '2014-05-24 00:55:06', '127.0.0.1', 1),
(43, 4, '2014-06-05 16:17:44', '127.0.0.1', 1),
(44, 4, '2014-08-13 16:21:05', '127.0.0.1', 7),
(45, 4, '2014-08-15 15:07:51', '127.0.0.1', 1),
(46, 4, '2014-08-17 18:58:12', '127.0.0.1', 1),
(47, 4, '2014-08-20 18:40:35', '127.0.0.1', 5) ;

#
# End of data contents of table `wp_rg_form_view`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead`
#

DROP TABLE IF EXISTS `wp_rg_lead`;


#
# Table structure of table `wp_rg_lead`
#

CREATE TABLE `wp_rg_lead` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `is_starred` tinyint(1) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `ip` varchar(39) NOT NULL,
  `source_url` varchar(200) NOT NULL DEFAULT '',
  `user_agent` varchar(250) NOT NULL DEFAULT '',
  `currency` varchar(5) DEFAULT NULL,
  `payment_status` varchar(15) DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `payment_amount` decimal(19,2) DEFAULT NULL,
  `payment_method` varchar(30) DEFAULT NULL,
  `transaction_id` varchar(50) DEFAULT NULL,
  `is_fulfilled` tinyint(1) DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `transaction_type` tinyint(1) DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_rg_lead`
#

#
# End of data contents of table `wp_rg_lead`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_detail`
#

DROP TABLE IF EXISTS `wp_rg_lead_detail`;


#
# Table structure of table `wp_rg_lead_detail`
#

CREATE TABLE `wp_rg_lead_detail` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `field_number` float NOT NULL,
  `value` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `lead_id` (`lead_id`),
  KEY `lead_field_number` (`lead_id`,`field_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_rg_lead_detail`
#

#
# End of data contents of table `wp_rg_lead_detail`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_detail_long`
#

DROP TABLE IF EXISTS `wp_rg_lead_detail_long`;


#
# Table structure of table `wp_rg_lead_detail_long`
#

CREATE TABLE `wp_rg_lead_detail_long` (
  `lead_detail_id` bigint(20) unsigned NOT NULL,
  `value` longtext,
  PRIMARY KEY (`lead_detail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_rg_lead_detail_long`
#

#
# End of data contents of table `wp_rg_lead_detail_long`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_meta`
#

DROP TABLE IF EXISTS `wp_rg_lead_meta`;


#
# Table structure of table `wp_rg_lead_meta`
#

CREATE TABLE `wp_rg_lead_meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `lead_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`id`),
  KEY `meta_key` (`meta_key`),
  KEY `lead_id` (`lead_id`),
  KEY `form_id_meta_key` (`form_id`,`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_rg_lead_meta`
#

#
# End of data contents of table `wp_rg_lead_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_notes`
#

DROP TABLE IF EXISTS `wp_rg_lead_notes`;


#
# Table structure of table `wp_rg_lead_notes`
#

CREATE TABLE `wp_rg_lead_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `user_name` varchar(250) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `value` longtext,
  `note_type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`),
  KEY `lead_user_key` (`lead_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_rg_lead_notes`
#

#
# End of data contents of table `wp_rg_lead_notes`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(54, 3, 0),
(58, 3, 0),
(60, 3, 0),
(61, 3, 0),
(62, 3, 0),
(63, 3, 0),
(65, 3, 0),
(67, 3, 0),
(68, 3, 0),
(69, 3, 0),
(112, 5, 0),
(118, 5, 0),
(119, 5, 0),
(120, 5, 0),
(139, 6, 0),
(141, 6, 0),
(144, 7, 0),
(145, 7, 0),
(207, 6, 0),
(255, 6, 0),
(256, 5, 0),
(355, 2, 0),
(357, 2, 0),
(360, 2, 0),
(361, 2, 0),
(362, 2, 0),
(363, 2, 0),
(364, 2, 0),
(365, 2, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'nav_menu', '', 0, 8),
(3, 3, 'nav_menu', '', 0, 10),
(4, 4, 'nav_menu', '', 0, 0),
(5, 5, 'nav_menu', '', 0, 5),
(6, 6, 'nav_menu', '', 0, 4),
(7, 7, 'nav_menu', '', 0, 2) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Main Menu', 'main-menu', 0),
(3, 'Footer Menu', 'footer-menu', 0),
(4, 'Nav Call-To-Action', 'nav-call-to-action', 0),
(5, 'Footer Menu Column 2', 'footer-menu-column-2', 0),
(6, 'Footer Menu Column 3', 'footer-menu-column-3', 0),
(7, 'Footer Credits Menu', 'footer-credits-menu', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'first_name', ''),
(2, 1, 'last_name', ''),
(3, 1, 'nickname', 'Ty Richards'),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'false'),
(10, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(11, 1, 'wp_user_level', '10'),
(12, 1, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media,wp360_revisions,wp360_locks,wp390_widgets'),
(13, 1, 'show_welcome_panel', '1'),
(14, 1, 'wp_dashboard_quick_press_last_post_id', '402'),
(15, 1, 'managenav-menuscolumnshidden', 'a:3:{i:0;s:11:"link-target";i:1;s:3:"xfn";i:2;s:11:"description";}'),
(16, 1, 'metaboxhidden_nav-menus', 'a:4:{i:0;s:8:"add-post";i:1;s:11:"add-project";i:2;s:12:"add-post_tag";i:3;s:16:"add-tagportfolio";}'),
(17, 1, 'nav_menu_recently_edited', '2'),
(18, 1, 'wp_user-settings', 'editor=html&hidetb=1&libraryContent=browse&urlbutton=custom&mfold=o&imgsize=thumbnail'),
(19, 1, 'wp_user-settings-time', '1400856960'),
(20, 2, 'first_name', 'Nick'),
(21, 2, 'last_name', 'Meagher'),
(22, 2, 'nickname', 'Nick Meagher'),
(23, 2, 'description', ''),
(24, 2, 'rich_editing', 'true'),
(25, 2, 'comment_shortcuts', 'false'),
(26, 2, 'admin_color', 'fresh'),
(27, 2, 'use_ssl', '0'),
(28, 2, 'show_admin_bar_front', 'true'),
(29, 2, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(30, 2, 'wp_user_level', '10'),
(31, 2, 'dismissed_wp_pointers', 'wp350_media,wp360_revisions,wp360_locks,wp390_widgets'),
(32, 2, 'wp_dashboard_quick_press_last_post_id', '385'),
(33, 2, 'closedpostboxes_acf', 'a:0:{}'),
(34, 2, 'metaboxhidden_acf', 'a:1:{i:0;s:7:"slugdiv";}') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'Ty Richards', '$P$BxN/XP7T.ZmeawoCgf/rokRWBikGUP1', 'ty-richards', 'ty@paradoxsites.com', '', '2014-02-24 13:54:52', '', 0, 'Ty Richards'),
(2, 'Nick Meagher', '$P$BwFLK8SNu3xry6W8xRI0ELRthM/rdW.', 'nick-meagher', 'nickme@gher.com', '', '2014-08-15 15:57:28', '', 0, 'Nick Meagher') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in
#

